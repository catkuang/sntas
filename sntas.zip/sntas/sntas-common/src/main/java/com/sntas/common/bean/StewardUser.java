package com.sntas.common.bean;

/**
 * Created With IntelliJ IDEA
 * User: luoshuifang
 * Date: 2017/3/15.
 * Time:13:48
 */
public class StewardUser {

    private Integer userId;//用户ID

    private String userName;//用户姓名

    private String phone;//用户手机

    private String email;//用户邮箱

    private String token;//用户令牌

    private Integer parentId;//父账户id

    private int org_id;//公司id

    public int getOrg_id() {
        return org_id;
    }

    public void setOrg_id(int org_id) {
        this.org_id = org_id;
    }


    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }
}
