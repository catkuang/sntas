package com.sntas.common.consts;

/**
 * Created by xin.fei on 2016/7/22.
 */
public class CacheConstant {

    // page
    public static final String PAGE_COUNT = "15"; // 每页展示数量
    public static final String PAGE_HOTS_COUNT = "10"; // 每页展示数量

    // 缓存时间

    public static final int CACHE_SMS_TIME = 30 * 60;
    public static final int CACHE_TIME = 2 * 60 * 60;
    public static final int TOKEN_CACHE_TIME = 4 * 60 * 60;
}
