package com.sntas.common.consts;

/**
 * 缓存主键
 * Created by LWD on 16/7/23.
 */
public enum CacheKey {

    SNTAS_MEMBER_, //用户缓存  格式为（ANTAS_MEMBER_member_Id）

}
