package com.sntas.common.consts;

/**
 * Created by luoshuifang on 2016/5/11.
 */
public class ErrorCodeConst {

    public static final String RESULT_SUCCESS="0";
    /**
     * 参数不全,或者参数为空
     */
    public static final String RESULT_PARMTER_ERROR="500";
    /**
     * 异常处理
     */
    public static final String RESULT_EXCEPTION_ERROR="600";

    /**
     * 查询次数超出
     */
    public static final String RESULT_cishu="99";

    /**
     * 姓名打分商标名称长度大于4
     */
    public static final String RESULT_TRADEMARKNAME_ERROR="100";
}
