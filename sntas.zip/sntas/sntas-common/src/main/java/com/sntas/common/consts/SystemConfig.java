package com.sntas.common.consts;

import java.util.List;

public class SystemConfig {
	public static String BLACK_LIST="blacklist";
	public static String WHITE_LIST="whitelist";
	public static int BLACK_RESTRICT=5;//超范围频率次数
	public static int IP_TIME=600;//时间范围
	public static int IP_RESTRICT=50;//固定时间内 商标查询次数
	public static boolean AUTH_ON; // 是否开启权限验证过程，开发阶段可关闭，不进行验证
	public static boolean DEVELOP_MODE;// 开启开发调试模式
	public static String ERROR_PAGE;// 错误导向页面
	public static String DEFAULT_ROW_SIZE; // 默认分页时，每页的条数
	public static int SESSION_AVAILABLE_TIME; // session过期时间
	public static int CIRCLE_INSTITUTION_CAPACITY; // 教育机构圈容量
	public static int CIRCLE_SCHOOL_CAPACITY; // 学校圈容量
	public static int CIRCLE_CLASS_CAPACITY; // 班级圈容量
	public static int GROUP_CLASS_CAPACITY; // 班级群容量
	public static int GROUP_CAPACITY; // 群容量
	public static int CIRCLE_CAPACITY; // 圈容量
	public static String DEFAULT_PORTRAIT; // 默认头像url
	public static List<String> SERVER_LIST;// 集群服务器列表
	public static List<String> TRANS_SERVER_LIST;// 转码服务器列表

	public static int SCHOOL_ALBUM_SIZE; // 学校相册大小MB
	public static int PIC_SIZE; // 上传图片大小限制MB
	
	public static int THREAD_NUM = 10; //线程数

	public static boolean isDEVELOP_MODE() {
		return DEVELOP_MODE;
	}

	public static void setDEVELOP_MODE(boolean dEVELOP_MODE) {
		DEVELOP_MODE = dEVELOP_MODE;
	}

	public static String getERROR_PAGE() {
		return ERROR_PAGE;
	}

	public static void setERROR_PAGE(String eRROR_PAGE) {
		ERROR_PAGE = eRROR_PAGE;
	}

	public static int getCIRCLE_INSTITUTION_CAPACITY() {
		return CIRCLE_INSTITUTION_CAPACITY;
	}

	public static void setCIRCLE_INSTITUTION_CAPACITY(int cIRCLE_INSTITUTION_CAPACITY) {
		CIRCLE_INSTITUTION_CAPACITY = cIRCLE_INSTITUTION_CAPACITY;
	}

	public static int getSCHOOL_ALBUM_SIZE() {
		return SCHOOL_ALBUM_SIZE;
	}

	public static void setSCHOOL_ALBUM_SIZE(int sCHOOL_ALBUM_SIZE) {
		SCHOOL_ALBUM_SIZE = sCHOOL_ALBUM_SIZE;
	}

	public static String getDEFAULT_ROW_SIZE() {
		return DEFAULT_ROW_SIZE;
	}

	public static void setDEFAULT_ROW_SIZE(String dEFAULT_ROW_SIZE) {
		DEFAULT_ROW_SIZE = dEFAULT_ROW_SIZE;
	}

	public static int getSESSION_AVAILABLE_TIME() {
		return SESSION_AVAILABLE_TIME;
	}

	public static void setSESSION_AVAILABLE_TIME(int sESSION_AVAILABLE_TIME) {
		SESSION_AVAILABLE_TIME = sESSION_AVAILABLE_TIME;
	}

	public static int getCIRCLE_SCHOOL_CAPACITY() {
		return CIRCLE_SCHOOL_CAPACITY;
	}

	public static void setCIRCLE_SCHOOL_CAPACITY(int cIRCLE_SCHOOL_CAPACITY) {
		CIRCLE_SCHOOL_CAPACITY = cIRCLE_SCHOOL_CAPACITY;
	}

	public static int getCIRCLE_CLASS_CAPACITY() {
		return CIRCLE_CLASS_CAPACITY;
	}

	public static int getPIC_SIZE() {
		return PIC_SIZE;
	}

	public static void setPIC_SIZE(int pIC_SIZE) {
		PIC_SIZE = pIC_SIZE;
	}

	public static void setCIRCLE_CLASS_CAPACITY(int cIRCLE_CLASS_CAPACITY) {
		CIRCLE_CLASS_CAPACITY = cIRCLE_CLASS_CAPACITY;
	}

	public static int getGROUP_CLASS_CAPACITY() {
		return GROUP_CLASS_CAPACITY;
	}

	public static void setGROUP_CLASS_CAPACITY(int gROUP_CLASS_CAPACITY) {
		GROUP_CLASS_CAPACITY = gROUP_CLASS_CAPACITY;
	}

	public static String getDEFAULT_PORTRAIT() {
		return DEFAULT_PORTRAIT;
	}

	public static int getGROUP_CAPACITY() {
		return GROUP_CAPACITY;
	}

	public static void setGROUP_CAPACITY(int gROUP_CAPACITY) {
		GROUP_CAPACITY = gROUP_CAPACITY;
	}

	public static int getCIRCLE_CAPACITY() {
		return CIRCLE_CAPACITY;
	}

	public static void setCIRCLE_CAPACITY(int cIRCLE_CAPACITY) {
		CIRCLE_CAPACITY = cIRCLE_CAPACITY;
	}

	public static void setDEFAULT_PORTRAIT(String dEFAULT_PORTRAIT) {
		DEFAULT_PORTRAIT = dEFAULT_PORTRAIT;
	}

	public static boolean isAUTH_ON() {
		return AUTH_ON;
	}

	public static void setAUTH_ON(boolean aUTH_ON) {
		AUTH_ON = aUTH_ON;
	}

	public static List<String> getSERVER_LIST() {
		return SERVER_LIST;
	}

	public static void setSERVER_LIST(List<String> sERVER_LIST) {
		SERVER_LIST = sERVER_LIST;
	}

	public static List<String> getTRANS_SERVER_LIST() {
		return TRANS_SERVER_LIST;
	}

	public static void setTRANS_SERVER_LIST(List<String> tRANS_SERVER_LIST) {
		TRANS_SERVER_LIST = tRANS_SERVER_LIST;
	}

}
