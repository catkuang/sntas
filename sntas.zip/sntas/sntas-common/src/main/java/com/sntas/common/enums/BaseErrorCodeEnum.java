package com.sntas.common.enums;

/**
 * 统一错误编码配置类，前两位代表不同的业务系统。后五位由各业务系统自行维护
 *
 */
public enum BaseErrorCodeEnum implements CodeEnumInterface {
    //01 app端 异常
    FILE_IO_READ_EXCEPTION("0100001", "文件操作异常", "deal the message info"),
    REFLEX_CREATED_OPERTION("0100003", "反射对象异常", "reflex object exception"),
    COPYPROPERTIES_EXCEPTION("0100002", "对象转换异常", "copyproperties error"),
    CONVERT_DATE_EXCEPTION("0100004", "日期转换错误", "convert date error"),
    CONVERT_SERVER_EXCEPTION("0100005", "服务器异常", "server exception"),
    CONVERT_IP_EXCEPTION("0100006", "查询次数受限!怀疑恶意查询操作！查询频率太快！请稍后再操作！", "convert date error"),
    USER_NOTLOGIN_EXCEPTION("0100008", "用户未登录", "user not login"),
    USER_VALIDATE_EXCEPTION("0100009", "请输入正确验证码", "true validate"),
    GET_VALIDATE_EXCEPTION("0100010", "重新获取验证码", "get validate"),
    USER_NOT_EXIST_EXCEPTION("0100011", "用户信息不存在", "user not exist"),
    USER_PASSWORD_EXCEPTION("0100012", "请输入正确密码", "true password"),
    USER_REGISTER_EXCEPTION("0100013", "用户已注册", "user register"),
    USER_VALIDATEOVERDUE_EXTST_ERROR_MSG("0100014", "验证码已过期", "user validateoverdue"),


    //02 web端 异常
    ADMIN_NOTLOGIN_EXCEPTION("0200008", "用户未登录", "admin not login")


    ;

    private String code;
    private String desc;
    private String message;


    private BaseErrorCodeEnum(String code, String desc, String message) {
        this.desc = desc;
        this.code = code;
        this.message = message;
    }

    /**
     * 中文描述
     *
     * @return
     */
    public String getDesc() {
        return desc;
    }

    /**
     * 英文信息
     *
     * @return
     */
    public String getMessage() {
        return message;
    }

    /**
     * 业务代码
     *
     * @return
     */
    public String getCode() {
        return code;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
