package com.sntas.common.enums;

/**
 * 业务代码接口 Created by luoshuifang on 2016/8/16.
 */
public interface CodeEnumInterface {

	public final static String SUCCESS = "0";
	public final static String ERROR = "-1";
	/**
	 * 基础底层错误
	 */
	public final static String BASE_CODE_EXCEPTION = "10";
	/**
	 * 数据库操作异常
	 */
	public final static String DATA_BASE_CODE_EXCEPTION = "20";

	/**
	 * 参数异常
	 */
	public final static String PARAMTER_CODE_EXCEPTION = "30";

	/**
	 * 流程异常
	 */
	public final static String FLOW_CODE_EXCEPTION = "40";


	/**
	 * 中文描述
	 *
	 * @return
	 */
	public String getDesc();

	/**
	 * 英文信息
	 *
	 * @return
	 */
	public String getMessage();

	/**
	 * 业务代码
	 *
	 * @return
	 */
	public String getCode();
}
