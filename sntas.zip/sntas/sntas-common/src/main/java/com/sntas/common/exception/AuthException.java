package com.sntas.common.exception;

import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by luoshuifang on 2016/6/22.
 */
public class AuthException extends BaseException {

    public AuthException(CodeEnumInterface enumInterface, String preCode) {
        super(enumInterface, CodeEnumInterface.FLOW_CODE_EXCEPTION);
    }

    public AuthException(CodeEnumInterface enumInterface) {
        super(enumInterface, CodeEnumInterface.FLOW_CODE_EXCEPTION);
    }
}
