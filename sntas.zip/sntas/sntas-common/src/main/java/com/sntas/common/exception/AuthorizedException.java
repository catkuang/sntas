package com.sntas.common.exception;


import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by bjcwq on 14-9-29.
 */
public class AuthorizedException extends BaseException {
    public AuthorizedException(){
        super("401","token错误");
    }

    public AuthorizedException(String code, String msg){
        super(code,msg);
    }

    public AuthorizedException(CodeEnumInterface enumInterface) {
        super(enumInterface.getCode(), enumInterface.getDesc());
    }

    public AuthorizedException(CodeEnumInterface enumInterface, Throwable e) {
        super(enumInterface,CodeEnumInterface.DATA_BASE_CODE_EXCEPTION, e);
    }
}
