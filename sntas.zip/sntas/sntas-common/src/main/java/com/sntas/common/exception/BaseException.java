package com.sntas.common.exception;


import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by luoshuifang on 2016/8/18.
 */
public class BaseException extends RuntimeException {
    private String code;
    private String desc;
    private String message;

    public BaseException() {
        this.code = "99999";
        this.message = "未知错误";
    }

    public BaseException(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public BaseException(CodeEnumInterface enumInterface, String preCode) {
        super("code:" + (preCode + enumInterface.getCode()) + enumInterface.getMessage());
        this.message = enumInterface.getMessage();
        this.desc = enumInterface.getDesc();
        this.code = preCode + enumInterface.getCode();
    }

    public BaseException(CodeEnumInterface enumInterface, String preCode, Throwable e) {
        super("code:" + (preCode + enumInterface.getCode()) + enumInterface.getMessage(), e);
        this.message = enumInterface.getMessage();
        this.desc = enumInterface.getDesc();
        this.code = preCode + enumInterface.getCode();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
