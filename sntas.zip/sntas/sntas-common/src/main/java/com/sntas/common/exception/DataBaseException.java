package com.sntas.common.exception;


import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by luoshuifang on 2016/8/16.
 */
public class DataBaseException extends BaseException {

    public DataBaseException(CodeEnumInterface enumInterface) {
        super(enumInterface, CodeEnumInterface.DATA_BASE_CODE_EXCEPTION);

    }

    public DataBaseException(CodeEnumInterface enumInterface, Throwable e) {
        super(enumInterface,CodeEnumInterface.DATA_BASE_CODE_EXCEPTION, e);

    }
}
