package com.sntas.common.exception;

import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by bjcwq on 14-10-9.
 */
public class NotFountException extends BaseException {

    public NotFountException(){
        super("404","您要请求的资源不存在");
    }
    public NotFountException(String code, String msg){
        super(code,msg);
    }

    public NotFountException(CodeEnumInterface enumInterface) {
        super(enumInterface, CodeEnumInterface.BASE_CODE_EXCEPTION);
    }

    public NotFountException(CodeEnumInterface enumInterface, Throwable e) {
        super(enumInterface, CodeEnumInterface.BASE_CODE_EXCEPTION, e);
    }
}
