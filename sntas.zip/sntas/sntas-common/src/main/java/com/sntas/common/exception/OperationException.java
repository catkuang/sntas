package com.sntas.common.exception;


import com.sntas.common.enums.CodeEnumInterface;

/**
 * Created by luoshuifang on 2016/8/17.
 */
public class OperationException extends BaseException {

    public OperationException(CodeEnumInterface enumInterface) {
        super(enumInterface, CodeEnumInterface.BASE_CODE_EXCEPTION);
    }

    public OperationException(CodeEnumInterface enumInterface, Throwable e) {
        super(enumInterface, CodeEnumInterface.BASE_CODE_EXCEPTION, e);

    }

}
