package com.sntas.common.exception;


import com.sntas.common.enums.CodeEnumInterface;

/**
 * @author luoshuifang on 2016/8/25.
 */
public class ParamterException extends BaseException {
	public ParamterException() {
		super("400","参数错误");
	}

	public ParamterException(CodeEnumInterface enumInterface) {
		super(enumInterface, CodeEnumInterface.PARAMTER_CODE_EXCEPTION);
	}

	public ParamterException(CodeEnumInterface enumInterface, Throwable e) {
		super(enumInterface, CodeEnumInterface.PARAMTER_CODE_EXCEPTION, e);
	}
}
