package com.sntas.common.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by luoshuifang on 2016/5/4.
 */
public class DateUtils {
	/**
	 * 取下一天
	 *
	 * @param date
	 * @return
	 */
	public static Date nextDays(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		return calendar.getTime();
	}

	/**
	 * 截取毫秒部分是之位0
	 *
	 * @param date
	 * @return
	 */
	public static Date excludeMsec(Date date) {
		Long timeLong = date.getTime();
		timeLong = timeLong - timeLong % 1000;
		return new Date(timeLong);
	}

	/**
	 * 获取当前时间的年份
	 *
	 * @param date
	 * @return
	 */
	public static Integer getDateYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.YEAR);
	}

	/**
	 * 获取当前时间的月份
	 *
	 * @param date
	 * @return
	 */
	public static Integer getDateMonth(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.MONTH) + 1;
	}

	/**
	 * 根据年月获取月份的最早时间
	 *
	 * @param year
	 * @param month
	 * @return
	 */
	public static Date getMonthStart(Integer year, Integer month) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, month - 1);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return excludeMsec(calendar.getTime());
	}

	/**
	 * 根据最初时间获取下个月最初时间
	 *
	 * @param startMonthDate
	 * @return
	 */
	public static Date getMonthEnd(Date startMonthDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startMonthDate);
		calendar.add(Calendar.MONTH, 1);
		return excludeMsec(calendar.getTime());
	}


	/**
	 * 前一年的时间
	 *
	 * @param date
	 * @return
	 */
	public static Date preYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -12);
		return calendar.getTime();
	}

	/**
	 * 获取两个日期间的所有日期
	 *
	 * @param startDate
	 * @param endDate
	 * @return List<Date>
	 */
	public static List<Date> getEveryDay(Date startDate, Date endDate) {
		Calendar startCalendar = Calendar.getInstance();
		Calendar endCalendar = Calendar.getInstance();
		startCalendar.setTime(startDate);
		endCalendar.setTime(endDate);
		List<Date> list = new ArrayList<Date>();
		while (true) {
			if (startCalendar.getTimeInMillis() <= endCalendar.getTimeInMillis()) {
				list.add(startCalendar.getTime());
				startCalendar.add(Calendar.DAY_OF_MONTH, 1);
			} else {
				break;
			}
		}
		return list;
	}

	public static int getDay(Date startDate, Date endDate) {
		int result = (int) (startDate.getTime() - endDate.getTime()) / 1000 / 3600 / 24;
		return result;
	}

	/**
	 * 获取日期前month个月份
	 *
	 * @param date
	 *            比对日期，没有取当前日期
	 * @param month
	 *            月份个数
	 */
	public static Date preMonth(Date date, int month) {
		Calendar calendar = Calendar.getInstance();
		if (date != null)
			calendar.setTime(date);
		calendar.add(Calendar.MONTH, -month);
		return calendar.getTime();
	}

	/**
	 * 获取当前日期
	 */
	public static Date getCurrentDate() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}

	/**
	 * 获取月初日期
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static Date getFirstDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		if (date != null)
			calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
	}

	/**
	 * 获取月末日期
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static Date getLastDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		if (date != null)
			calendar.setTime(date);
		calendar.add(Calendar.MONTH, 1); // 加一个月
		calendar.set(Calendar.DATE, 1); // 设置为该月第一天
		calendar.add(Calendar.DATE, -1); // 再减一天即为上个月最后一天
		return calendar.getTime();
	}

	/**
	 * 获取日期的年月
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static String getYearMon(Date date) {
		Calendar calendar = Calendar.getInstance();
		if (date != null)
			calendar.setTime(date);
		int year = calendar.get(Calendar.YEAR);
		int month = (calendar.get(Calendar.MONTH) + 1);
		String zero = "";
		if (month < 10)// 月份小于10补零
			zero = "0";
		return year + zero + month;
	}

	/**
	 * 获取日期的日
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static int getDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		if (date != null)
			calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 获取日期的日
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static Integer getDate(Date date) {
		if (date == null) {
			return null;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 获取某天的开始时间
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static Date getStartTime(Date date) {
		Calendar todayStart = Calendar.getInstance();
		if (date != null)
			todayStart.setTime(date);
		todayStart.set(Calendar.HOUR_OF_DAY, 0);
		todayStart.set(Calendar.MINUTE, 0);
		todayStart.set(Calendar.SECOND, 0);
		todayStart.set(Calendar.MILLISECOND, 0);
		return todayStart.getTime();
	}

	/**
	 * 获取某天的结束时间
	 *
	 * @param date
	 *            日期，没有取当前日期
	 */
	public static Date getEndTime(Date date) {
		Calendar todayEnd = Calendar.getInstance();
		if (date != null)
			todayEnd.setTime(date);
		todayEnd.set(Calendar.HOUR_OF_DAY, 23);
		todayEnd.set(Calendar.MINUTE, 59);
		todayEnd.set(Calendar.SECOND, 59);
		todayEnd.set(Calendar.MILLISECOND, 999);
		return todayEnd.getTime();
	}

	/**
	 * 比较两个日期是否相同
	 * @return
	 */
	public static boolean compareDate(Date date1, Date date2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date1);
		Calendar c2 = Calendar.getInstance();
		c2.setTime(date2);
		if (c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) && c1.get(Calendar.MONTH) == c2.get(Calendar.MONTH) && c1.get(Calendar.DAY_OF_MONTH) == c2.get(Calendar.DAY_OF_MONTH))
			return true;
		else
			return false;
	}

	public static Integer nextMonthGetMonth(Integer month) {
		if (month == 12) {
			return 1;
		} else {
			return month + 1;
		}
	}

	public static Integer nextMonthGetYear(Integer month, Integer year) {
		if (month == 12) {
			return year + 1;
		} else {
			return year;
		}
	}

	public static Date preDays() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.add(Calendar.DAY_OF_YEAR,-1);
		return excludeMsec(calendar.getTime());
	}
	public static Date lastDays() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return excludeMsec(calendar.getTime());
	}

	/**
	 * 获取两个日期间所有年月
	 *
	 */
	public static List<String> getYearMonList(Date startDate, Date endDate) {
		Calendar startCalendar = Calendar.getInstance();
		Calendar endCalendar = Calendar.getInstance();
		startCalendar.setTime(startDate);
		endCalendar.setTime(endDate);
		List<String> list = new ArrayList<String>();
		while (true) {
			if (endCalendar.getTimeInMillis() >= startCalendar.getTimeInMillis()) {
				list.add(getYearMon(endCalendar.getTime()));
				endCalendar.add(Calendar.MONTH, -1);
			} else {
				break;
			}
		}
		return list;
	}

}
