package com.sntas.common.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.rtf.RtfWriter2;

/**
 * @Title:ItextUtil.java
 * @Description:打印WORD或PDF列表
 * @Company:sinosoft
 * @create time:Mar 29, 2013 3:30:35 PM
 * @author LiWeichao
 * @version 1.0
 * 
 */
public class ItextUtil {
	
	/**
	 * 是否显示行数
	 */
	public static boolean online;
	public static String onlineTitle = "";
	public static Rectangle modelType;
	/**
	 * <p>设置中文字体 </p>
	 * <p>默认：BaseFont.createFont("STSong-Light", "UniGB-UCS2-H",BaseFont.NOT_EMBEDDED);</p>
	 */
	public static BaseFont bfFont;
	/**
	 * <p>列表herder样式 默认普通文本12号字体</p>
	 * <p>headFont = new Font(bfFont,12,Font.NORMAL)</p>
	 */
	public static Font headFont;
	/**
	 * <p>内容样式 默认普通文本10号字体</p>
	 * <p>contextFont = new Font(bfFont,10,Font.NORMAL);</p>
	 */
	public static Font contextFont;

	/**
	 * 右对齐 针对列 如：第2，5列右对齐 [2,5]
	 */
	public static int[] align_right;
	/**
	 * 居中 针对列 如：第2，5列居中 [2,5]
	 */
	public static int[] align_center;
	/**
	 * 宽度百分比 如：5列{15,20,25,10,30} 默认平均
	 */
	public static int[] width;
	
	/**
	 * 应用 实例 使用说明
	 * @author LiWeichao
	 * 
	 * <p>ItextUtil.createWord();//创建WORD 或createPdf();</p>
	 * <p>ItextUtil.online = true;</p>
	 * <p>ItextUtil.width = new int[]{30,30,40};</p>
	 * <p>ItextUtil.align_right = new int[]{3};//设置第三列内容右对齐</p>
	 * <p>ItextUtil.align_center = new int[]{2};//设置第二列内容居中</p>
	 * <p>ItextUtil.modelType = PageSize.B3;//设置文本格式B3纸</p>
	 * <p>ItextUtil.headFont = new Font(ItextUtil.bfFont,10,Font.BOLD);//10号字体加粗</p>
	 * <p>&nbsp;</p>
	 * <p>ItextUtil.addParagraph(ItextUtil.headFont, "打印测试标题", 1);</p>
	 * <p>ItextUtil.addEmptyParagraph();</p>
	 * <p>&nbsp;</p>
	 * <p>List<String> heardList = new ArrayList<String>();</p>
	 * <p>heardList.add("测试1");</p>
	 * <p>heardList.add("测试2");</p>
	 * <p>heardList.add("测试3");</p>
	 * <p>List<Object[]> contextList = new ArrayList<Object[]>();</p>
	 * <p>contextList.add(heardList.toArray());</p>
	 * <p>contextList.add(heardList.toArray());</p>
	 * <p>&nbsp;</p>
	 * <p>ItextUtil.addTable(heardList, contextList);</p>
	 * <p>ItextUtil.fileOutPut("D:/test.doc");//或"D:/test.pdf"</p>
	 */
	public static final String ART_EXAMPLE = "...TEST EXAMPLE...";
	
	public static Document document;
	private static ByteArrayOutputStream baos;
	private static String contentType;
	
	/**
	 * 初始化

	 * @throws Exception
	 */
	private static void init(Rectangle modelType,BaseFont bf) throws Exception{
		online = false;
		onlineTitle = "";
		align_right = null;
		align_center = null;
		width = null;
//		bfFont = bf==null? BaseFont.createFont("STSong-Light", "UniGB-UCS2-H",BaseFont.NOT_EMBEDDED):bf;
		headFont = new Font(bfFont,12,Font.NORMAL);
		contextFont = new Font(bfFont,10,Font.NORMAL);
		baos = new ByteArrayOutputStream();
		document = new Document(modelType);
	}
	
	/**
	 * 创建PDF
	 * @throws Exception
	 */
	public static void createPdf() throws Exception{
		init(PageSize.A4,null);
		contentType = "pdf";
		PdfWriter.getInstance(document, baos);
		document.open();
	}
	
	/**
	 * 创建PDF A4纸张
	 * @param bfFont 字体 如：BaseFont.createFont("C:/Windows/Fonts/FZSong-RKXX.TTF", BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);
	 * @throws Exception
	 */
	public static void createPdf(BaseFont bfFont) throws Exception{
		init(PageSize.A4, bfFont);
		contentType = "pdf";
		PdfWriter.getInstance(document, baos);
		document.open();
	}
	
	/**
	 * 创建PDF A4纸张
	 * @param modelType 纸张类型 如：PageSize.A4纵向或PageSize.A4.rotate()横向
	 * @param bfFont 字体 如：BaseFont.createFont("C:/Windows/Fonts/FZSong-RKXX.TTF", BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);
	 * @throws Exception
	 */
	public static void createPdf(Rectangle modelType, BaseFont bfFont) throws Exception{
		init(modelType,bfFont);
		contentType = "pdf";
		PdfWriter.getInstance(document, baos);
		document.open();
	}
	
	/**
	 * 创建PDF A4纸张
	 * @param modelType 纸张类型 如：PageSize.A4纵向或PageSize.A4.rotate()横向
	 * @throws Exception
	 */
	public static void createPdf(Rectangle modelType) throws Exception{
		init(modelType,null);
		contentType = "pdf";
		PdfWriter.getInstance(document, baos);
		document.open();
	}
	
	/**
	 * 创建WORD A4纸张
	 * @throws Exception
	 */
	public static void createWord() throws Exception{
		init(PageSize.A4,null);
		contentType = "doc";
		RtfWriter2.getInstance(document,baos);
		document.open();
	}
	
	/**
	 * 创建WORD
	 * @param modelType 纸张类型 如：PageSize.A4纵向或PageSize.A4.rotate()横向
	 * @throws Exception
	 */
	public static void createWord(Rectangle modelType) throws Exception{
		init(modelType,null);
		contentType = "doc";
		RtfWriter2.getInstance(document,baos);
		document.open();
	}
	
	/**
	 * 添加图片
	 * @param fileName 文件 绝对路径
	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(String fileName, int align) throws Exception{
		Image img = Image.getInstance(fileName);
	    img.setAlignment(align);
		document.add(img);
	}
	
	/**
	 * 添加图片
	 * @param fileName 文件 绝对路径
	 * @param width，hight
	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(String fileName, float width, float hight, int align) throws Exception{
		Image img = Image.getInstance(fileName);
	    img.setAlignment(align);
	    img.scaleAbsolute(width, hight);
		document.add(img);
	}
	
	/**
	 * 添加图片
	 * @param bytes
	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(byte[] bytes, int align) throws Exception{
		Image img = Image.getInstance(bytes);
		//img.setAbsolutePosition(10, 10);
	    img.setAlignment(align);
		document.add(img);
	}
	
	/**
	 * 添加图片
	 * @param bytes
	 * @param width，hight
	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(byte[] bytes, float width, float hight, int align) throws Exception{
		Image img = Image.getInstance(bytes);
		img.setAbsolutePosition(10, 10);
	    img.setAlignment(align);
	    img.scaleAbsolute(width, hight);
		document.add(img);
	}
	
	/**
	 * 添加图片
	 * @param com.lowagie.text.Image
	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(Image img, int align) throws Exception{
	    img.setAlignment(align); 
		document.add(img);
	}
	
	/**
	 * 添加图片
	 * @param com.lowagie.text.Image
	 * @param width，hight 宽和高

	 * @param align 0居左 1居中 2居右
	 * @throws Exception
	 */
	public static void addImage(Image img, float width, float hight, int align) throws Exception{
	    img.setAlignment(align); 
	    img.scaleAbsolute(width, hight);
		document.add(img);
	}
	
	/**
	 * 添加内容
	 * @param font 字体样式
	 * @param text 内容
	 * @param align 0居左 1居中 2居右
	 * @throws DocumentException 
	 */
	public static void addParagraph(Font font, String text, int align) throws Exception{
		Paragraph p = new Paragraph(text, font);
		p.setAlignment(align);
		document.add(p);
	}
	
	/**
	 * 添加一个空行

	 * @throws DocumentException 
	 */
	public static void addEmptyParagraph() throws Exception{
		document.add(new Paragraph());
	}
	
	/**
	 * 添加内容
	 * @param font 字体样式
	 * @param text 内容
	 * @param align 0居左 1居中 2居右
	 * @throws DocumentException 
	 */
	public static void addPhrase(Font font, String text, int align) throws Exception{
		Phrase p = new Phrase(text, font);
		document.add(p);
	}
	
	/**
	 * 添加换行
	 * @throws DocumentException 
	 */
	public static void addNewLine() throws Exception{
		document.add(Chunk.NEWLINE);
	}
	
	/**
	 * 返回创建的主体内容

	 * @return bytes
	 * @throws Exception
	 */
	public static byte[] getBytes() throws Exception{
		if(document.isOpen()){
			document.close();
		}
		byte[] bytes = baos.toByteArray();
		if(baos != null){
			baos.flush();
		  	baos.close();
		}
		return bytes;
	}
	
	/**
	 * 输出为文件

	 * @param filePath 绝对路径
	 * @throws Exception
	 */
	public static void fileOutPut(String filePath) throws Exception{
        byte[] bytes = getBytes();
		FileOutputStream fos = new FileOutputStream(filePath);
		fos.write(bytes, 0, bytes.length);
		if (fos != null) {
			fos.flush();
			fos.close();
		}
	}
	
	/**
	 * 页面输出
	 * @param response
	 * @throws Exception
	 */
	public static void responseOutPut(HttpServletResponse response) throws Exception{
		responseOutPut(response, String.valueOf(System.currentTimeMillis()));
	}
	
	/**
	 * 页面输出
	 * @param response
	 * @param fileName 输出文件名

	 * @throws Exception
	 */
	public static void responseOutPut(HttpServletResponse response, String fileName) throws Exception{
		byte[] bytes = getBytes();
  		fileName = java.net.URLEncoder.encode(fileName,"UTF-8");
	  	String strDocName = "attachment;filename=" + fileName + "." + contentType;
	  	response.setHeader("Content-disposition", strDocName);
	  	contentType = contentType.replaceAll("doc", "ms_word");
	  	response.setContentType("application/" + contentType + ";charset=UTF-8");
	  	response.setContentLength(bytes.length);
	  	ServletOutputStream ouputStream = response.getOutputStream();
	  	ouputStream.write(bytes, 0, bytes.length);
	  	ouputStream.flush();
	  	ouputStream.close();
	}
	
	/**
	 * 添加一行

	 * @param list 内容等宽
	 * @param align 默认:居左
	 */
	public static void addSimpleTable(String[] list, Integer[] align){
		try {
			Table table = new Table(list.length);
			table.setWidth(100);//占页面宽度比例

			table.setAlignment(Element.ALIGN_RIGHT);//居中   
			table.setBorder(0);//边框宽度
			table.setSpacing(0);
			table.setPadding(0);
			
			Cell cell = null;
			for (int i=0; i<list.length;i++) {
				cell = new Cell(new Phrase(list[i], headFont));
				cell.setBorder(0);
				cell.setHorizontalAlignment(align!=null&&align.length>i?align[i]:0);//默认居左
            	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
            	table.addCell(cell);
			}
			document.add(table);
		} catch (Exception e) {
		} 
	}
	
	/**
	 * 添加主题表格
	 * @param headList List<String> 表头
	 * @param contextList List<String[]> 内容
	 * @throws Exception
	 */
	public static void addTable(List<String> headList, List<Object[]> contextList) throws Exception{
		if(headList == null || headList.size() < 1){
			return;
		}
		int tableSize = headList.size();
		if(online){
			tableSize++;
		}
		Table table = new Table(tableSize); 
		table.setWidth(100);//占页面宽度比例

        table.setAlignment(Element.ALIGN_RIGHT);//居中   
        //table.setAlignment(Element.ALIGN_MIDDLE);//垂直居中
        //table.setAutoFillEmptyCells(true);//自动填满
        table.setBorderWidth(1);//边框宽度
        table.setPadding(10);
        table.setSpacing(0);
        if(width!=null && width.length > 0){
        	
	        int widths[] = new int[tableSize];
	        for (int i = 0; i < widths.length; i++) {
	        	if(i < width.length){
	        		widths[i] = width[i];
	        	}else{
	        		widths[i] = 100/tableSize;//不足按照百分比平均

	        	}
			}
	        table.setWidths(widths);//列宽比例
        }
        
        //context
        int align[] = new int[headList.size()];//默认左对齐

        if(online){
        	align = new int[headList.size()+1];
        }
    	if(align_right != null && align_right.length > 0){
        	for (int i = 0; i < align_right.length; i++) {
				if(align_right[i] <= headList.size()){
					align[align_right[i]-1] = Element.ALIGN_RIGHT;
				}
			}
    	}
    	if(align_center != null && align_center.length > 0){
        	for (int i = 0; i < align_center.length; i++) {
				if(align_center[i] <= headList.size()){
					align[align_center[i]-1] = Element.ALIGN_CENTER;
				}
			}
    	}
    	
    	Cell cell = null;
        //heard
        if(online){
        	cell = new Cell(new Phrase(onlineTitle, contextFont));
         	cell.setHorizontalAlignment(align[0]);
         	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
         	table.addCell(cell);
        }
        for (int i = 0; i < headList.size(); i++) {
         	cell = new Cell(new Phrase(headList.get(i),headFont));
         	cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
         	table.addCell(cell);
 		}
    	
        if(contextList != null && contextList.size() > 0){
	    	for (int i = 0; i< contextList.size(); i++) {
	    		Object[] objects = contextList.get(i);
	    		if(online){
	    			cell = new Cell(new Phrase(String.valueOf(i+1), contextFont));
	            	cell.setHorizontalAlignment(align[0]);
	            	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
	            	table.addCell(cell);
	            }
	    		for (int j = 0; j < objects.length; j++) {
	        		String obj = objects[j]==null?"":String.valueOf(objects[j]).replaceAll("\r\n", "\n");//word中 \r会变成？号

	            	cell = new Cell(new Phrase(obj, contextFont));
	            	cell.setHorizontalAlignment(align[j]);      //原为j+1
	            	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
	            	table.addCell(cell);
				}
			}
        } else {//添加空行
        	 if(online){
             	cell = new Cell(new Phrase("", contextFont));
              	cell.setHorizontalAlignment(align[0]);
              	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
              	table.addCell(cell);
             }
             for (int i = 0; i < headList.size(); i++) {
              	cell = new Cell(new Phrase("",headFont));
              	cell.setHorizontalAlignment(Element.ALIGN_CENTER);
              	cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//垂直居中
              	table.addCell(cell);
      		}
        }
    	document.add(table);
	}
}
