package com.sntas.common.utils;

import java.math.BigDecimal;

/**
 * Created by luoshuifang on 2016/5/11.
 */
public class NumberUtils {
	public static Double divide(Long numerator, Long denominator) {
		if(numerator==null||denominator==null||denominator==0){
			return null;
		}
		return BigDecimal.valueOf(numerator).divide(BigDecimal.valueOf(denominator), 10, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static Double divide(Double numerator, Double denominator) {
		return BigDecimal.valueOf(numerator).divide(BigDecimal.valueOf(denominator), 10, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static Double div(Double num, Double total) {
		return total == 0 ? 0 : BigDecimal.valueOf(num).divide(BigDecimal.valueOf(total), 4, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static Double add(Double num1, Double num2) {
		return BigDecimal.valueOf(num1).add(BigDecimal.valueOf(num2)).doubleValue();
	}

	public static Double sum(Double... doubleArray) {
		Double total = null;
		for (Double doub : doubleArray) {
			if (doub != null) {
				if (total == null) {
					total = doub;
				} else {
					total = add(doub, total);
				}
			}
		}
		return total;
	}

	public static Double divideDouble(Double numerator, Double denominator) {
		if (numerator != null && numerator == 0) {
			return 0d;
		}
		if (numerator == null || denominator == null || denominator == 0) {
			return null;
		}
		return divide(numerator, denominator);
	}

	public static Double multiply(Double numerator, Double denominator) {
		if (numerator == null || denominator == null) {
			return null;
		}
		return BigDecimal.valueOf(numerator).multiply(BigDecimal.valueOf(denominator)).doubleValue();
	}
	public static Double multiply(Double numerator, Integer denominator) {
		if (numerator == null || denominator == null) {
			return null;
		}
		return BigDecimal.valueOf(numerator).multiply(BigDecimal.valueOf(denominator)).doubleValue();
	}
	public static Double isNumToZero(Double num) {
		return num == null ? 0d : num;
	}

}
