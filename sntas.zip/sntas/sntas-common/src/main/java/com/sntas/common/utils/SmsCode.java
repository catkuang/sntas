package com.sntas.common.utils;

import java.util.Random;

public class SmsCode {
    public static final String RANDOM_STRS = "0123456789";
    private static Random random = new Random();

    public SmsCode() {
    }

    private static String getRandomString(int num) {
        return String.valueOf("0123456789".charAt(num));
    }

    public static String smsCapture(int length) {
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; ++i) {
            stringBuilder.append(getRandomString(random.nextInt("0123456789".length())));
        }

        return stringBuilder.toString();
    }
}
