package com.sntas.common.utils.httpUtil;

import net.sf.json.JSONObject;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;

/**
 * Created by ysk on 2016/9/27.
 */
public class HttpClientUtil {
    private final static Logger logger = Logger.getLogger(HttpClientUtil.class);

    /**
     * 转发请求
     *
     * @param url
     * @param nameValuePair
     * @param timeoutConnection 默认1000*60 设置连接超时时间（毫秒）
     * @param timeoutSocket     默认1000*60 设置默认的套接字超时（so_timeout毫秒）。这是为了等待数据超时。
     * @return String 请求返回结果
     */
    public static String buildRequestByUTF8AndTime(String url, Map<String, String> nameValuePair,
                                                   int timeoutConnection, int timeoutSocket) {
        return buildRequest(url, nameValuePair, timeoutConnection, timeoutSocket, "UTF-8");
    }

    /**
     * 转发请求
     *
     * @param url
     * @param nameValuePair
     * @return String 请求返回结果
     */
    public static String buildRequestByUTF8(String url, Map<String, String> nameValuePair) {
        return buildRequest(url, nameValuePair, 1000 * 60, 1000 * 60, "UTF-8");
    }

    public static String buildRequestContentType(String url, Map<String, String> nameValuePair) {
        return buildRequestContentType(url, nameValuePair, 1000 * 60, 1000 * 60, "UTF-8");
    }


    /**
     * 转发请求
     *
     * @param url
     * @param nameValuePair
     * @param timeoutConnection 设置连接超时时间（毫秒）
     * @param timeoutSocket     设置默认的套接字超时（so_timeout毫秒）。这是为了等待数据超时。
     * @return String 请求返回结果
     */
    public static String buildRequestContentType(String url, Map<String, String> nameValuePair,
                                                 int timeoutConnection, int timeoutSocket, String charset) {
        String response = "";
        //构造HttpClient的实例
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        //根据默认超时限制初始化requestConfig
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeoutSocket).setConnectTimeout(timeoutConnection).build();
        try {
            HttpPost httpPost = new HttpPost(url);
            //设置请求器的配置
            httpPost.setConfig(requestConfig);
            //设置httpPost请求参数
            String data = JSONObject.fromObject(nameValuePair).toString();
            StringEntity myEntity = new StringEntity(data, ContentType.APPLICATION_JSON);// 构造请求数据
            httpPost.setEntity(myEntity);// 设置请求体
            //使用execute方法发送HTTP Post请求，并返回HttpResponse对象
            CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                response = EntityUtils.toString(httpResponse.getEntity(), charset);
            } else {
                response = "{\"error_response\":\"" + statusCode + "\"}";
            }
        } catch (ClientProtocolException e) {
            //e.printStackTrace();
            logger.error("ClientProtocolException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"ClientProtocolException\"}";
        } catch (IllegalStateException e) {
            //e.printStackTrace();
            logger.error("IllegalStateException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"IllegalStateException\"}";
        } catch (IOException e) {
            //e.printStackTrace();
            logger.error("IOException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"IOException\"}";
        } catch (Exception e) {
            //e.printStackTrace();
            logger.error("Exception  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"" + e.getMessage() + "\"}";
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                //e.printStackTrace();
                logger.error("IOException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            }
        }
        return response;
    }

    /**
     * 转发请求
     *
     * @param url
     * @param nameValuePair
     * @param timeoutConnection 设置连接超时时间（毫秒）
     * @param timeoutSocket     设置默认的套接字超时（so_timeout毫秒）。这是为了等待数据超时。
     * @return String 请求返回结果
     */
    public static String buildRequest(String url, Map<String, String> nameValuePair,
                                      int timeoutConnection, int timeoutSocket, String charset) {
        String response = "";
        //构造HttpClient的实例
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        //根据默认超时限制初始化requestConfig
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeoutSocket).setConnectTimeout(timeoutConnection).build();
        try {
            HttpPost httpPost = new HttpPost(url);
            //设置请求器的配置
            httpPost.setConfig(requestConfig);
            //设置httpPost请求参数
            httpPost.setEntity(new UrlEncodedFormEntity(generatNamePair(nameValuePair), charset));
            //使用execute方法发送HTTP Post请求，并返回HttpResponse对象
            HttpResponse httpResponse = httpClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                response = EntityUtils.toString(httpResponse.getEntity(), charset);
            } else {
                response = "{\"error_response\":\"request failed\"}";
            }
        } catch (ClientProtocolException e) {
            //e.printStackTrace();
            logger.error("ClientProtocolException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"ClientProtocolException\"}";
        } catch (IllegalStateException e) {
            //e.printStackTrace();
            logger.error("IllegalStateException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"IllegalStateException\"}";
        } catch (IOException e) {
            //e.printStackTrace();
            logger.error("IOException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"IOException\"}";
        } catch (Exception e) {
            //e.printStackTrace();
            logger.error("Exception  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            response = "{\"is_success\":\"F\",\"error_code\":\"" + e.getMessage() + "\"}";
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                //e.printStackTrace();
                logger.error("IOException  HttpClientUtil url=" + url + " nameValuePair=" + nameValuePair + " e=" + e);
            }
        }
        return response;
    }

    /**
     * 使用PSOT方式，必须用NameValuePair数组传递参数
     * 把Parameter类型集合转换成NameValuePair类型集合
     *
     * @param paramTemp 参数集合
     * @return List<BasicNameValuePair>
     */
    private static List<NameValuePair> generatNamePair(Map<String, String> paramTemp) {
        List<NameValuePair> result = new ArrayList<NameValuePair>(0);
        if (null != paramTemp && paramTemp.size() > 0) {
            for (Iterator<String> i = paramTemp.keySet().iterator(); i.hasNext(); ) {
                Object obj = i.next();
                result.add(new BasicNameValuePair(obj.toString(), paramTemp.get(obj)));
            }
        }
        return result;
    }


    /**
     * 向指定URL发送GET方法的请求
     *
     * @param url   发送请求的URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return URL 所代表远程资源的响应结果
     */
    public static String sendGet(String url, Map<String, String> param) {
        String result = "";
        BufferedReader in = null;
        try {
            String urlNameString = url;
            if (param != null) {
                String NameValuePair = "";
                Set<String> set = param.keySet();
                Iterator<String> it = set.iterator();
                while (it.hasNext()) {
                    String object = it.next();
                    NameValuePair = NameValuePair.concat(object + "=" + param.get(object) + "&");
                }
                urlNameString += "?" + NameValuePair;
            }

            URL realUrl = new URL(urlNameString);
            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
//            realUrl.
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Accept-Charset", "utf-8");
            connection.setRequestProperty("contentType", "utf-8");
            // 建立实际的连接
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : map.keySet()) {
                System.out.println(key + "--->" + map.get(key));
            }
            // 定义 BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送GET请求出现异常！" + e);
            e.printStackTrace();
        }
        // 使用finally块来关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    public static void main(String[] args) {
        /*
            Map<String, String> nameValuePair = new HashMap<String, String>();
	        nameValuePair.put("taskId","1");
	        nameValuePair.put("type","1");
	        String url="http://localhost:8080/shibei/invalidDeclarationManage/findInvalidDeclarationManageCorl.do";
	        String results= buildRequest(url, nameValuePair, 1000*60,  1000*60, "UTF-8");
	        System.out.println("-------results--------"+results);
        */
        System.out.println("------开始---------");

        String url = "http://192.168.1.117:8080/shibei/api/ordersList/2";// 请求接口地址
        String result = HttpClientUtil.sendGet(url, null);

        System.out.println(result);

//    	for(int i=0;i<3;i++){
//        	Long starts=System.currentTimeMillis();
//        	Map<String, String> nameValuePair = new HashMap<String, String>();
//            String url="http://localhost:8080/shibei/twoTradeMarkHyq/submitTradeMarkone.do";
//            String results= buildRequest(url, nameValuePair, 1000*30,  1000*30, "UTF-8");
//            Long ends=System.currentTimeMillis();
//            System.out.println("-------results--------"+(ends-starts)/1000);
//            if(true){
//            	System.out.println("-------true----break----"+(ends-starts)/1000);
//            	break;
//            }
//    	}
        System.out.println("------结束---------");

    }
}

















