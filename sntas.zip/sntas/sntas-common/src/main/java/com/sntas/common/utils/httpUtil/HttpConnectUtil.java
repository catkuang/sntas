package com.sntas.common.utils.httpUtil;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;

/**
 * http访问公共接口
 *
 * 2016年3月28日 上午11:19:47
 * lsf@cnsebe.com
 *
 */
public class HttpConnectUtil {
	
	private static final Logger logger = Logger.getLogger(HttpConnectUtil.class);

	// 浏览器列表
	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36";

	// 连接超时
	private static final int CONN_TIMEOUT = 30000;
	private static final int READ_TIMEOUT = 30000;

	/**
	 * 建立http连接，获取数据
	 * 
	 * @param urlStr 访问地址
	 * @param params 访问参数
	 * @param method
	 *            请求方法
	 * @return
	 * @throws IOException
	 */
	public static String httpConnect(String urlStr, Map<String, String> params, String method) {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		InputStream is = null;
		InputStreamReader isr = null;
		String result = null;

		if (method == null || method.equals("GET")) {
			urlStr = urlStr + "?" + urlEncode(params);
		}

		try {
			URL url = new URL(urlStr);
			conn = (HttpURLConnection) url.openConnection();
			if (method == null || method.equals("GET")) {
				conn.setRequestMethod("GET");
			} else {
				conn.setRequestMethod("POST");
				conn.setDoOutput(true);
			}

			conn.setRequestProperty("User-agent", USER_AGENT);
			conn.setUseCaches(false);
			conn.setConnectTimeout(CONN_TIMEOUT);
			conn.setReadTimeout(READ_TIMEOUT);
			conn.setInstanceFollowRedirects(false);
			conn.connect();

			if (params != null && method.equals("POST")) {
				DataOutputStream os = new DataOutputStream(
						conn.getOutputStream());
				os.writeBytes(urlEncode(params));
				os.close();
			}

			is = conn.getInputStream();
			isr = new InputStreamReader(is, "utf-8");
			br = new BufferedReader(isr);
			
			StringBuffer sb = new StringBuffer();
			String str = null;
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}

			result = sb.toString();
		} catch (IOException e) {
			logger.error("http连接异常", e);
		} finally {
			IOUtils.closeQuietly(br);
			IOUtils.closeQuietly(isr);
			IOUtils.closeQuietly(is);
			conn.disconnect();
		}

		return result;
	}

	/**
	 * 建立https get连接
	 * @param urlStr 访问地址和参数
	 * @return
	 */
	public static String httpsGetConnect(String urlStr) {
		HttpsURLConnection conn = null;
		InputStream is = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		String result = null;
		
		try {
			URL url = new URL(urlStr);
			conn = (HttpsURLConnection)url.openConnection();
			
			// 使用自定义信任管理器
			TrustManager[] tm = { new MyX509TrustManager()};
			SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
			sslContext.init(null, tm, new java.security.SecureRandom());
			SSLSocketFactory ssf = sslContext.getSocketFactory();
			conn.setSSLSocketFactory(ssf);
			conn.setDoInput(true);
			
			// 设置请求方式
			conn.setRequestMethod("GET");
			
			// 取得输入流
			is = conn.getInputStream();
			isr = new InputStreamReader(is, "utf-8");
			br = new BufferedReader(isr);
			
			// 读取响应内容
			StringBuffer buffer = new StringBuffer();
			String str = null;
			while((str = br.readLine()) != null) {
				buffer.append(str);
			}
			
			result = buffer.toString();
		} catch (Exception e) {
			logger.error(e);
		} finally {
			IOUtils.closeQuietly(br);
			IOUtils.closeQuietly(isr);
			IOUtils.closeQuietly(is);
			conn.disconnect();
		}
		
		return result;
	}
	
	/**
	 * 建立https get连接
	 * @param urlStr 访问地址和参数
	 * @param content
	 * @return
	 */
	public static String httpsPostConnect(String urlStr, String content) {
		HttpsURLConnection conn = null;
		InputStream is = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		String result = null;
		
		try {
			URL url = new URL(urlStr);
			conn = (HttpsURLConnection)url.openConnection();
			
			// 使用自定义信任管理器
			TrustManager[] tm = { new MyX509TrustManager()};
			SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
			sslContext.init(null, tm, new java.security.SecureRandom());
			SSLSocketFactory ssf = sslContext.getSocketFactory();
			conn.setSSLSocketFactory(ssf);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			
			// 设置请求方式
			conn.setRequestMethod("POST");
			
			// 向输出流写菜单结构
			OutputStream os = conn.getOutputStream();
			os.write(content.getBytes("UTF-8"));
			os.close();
			
			// 取得输入流
			is = conn.getInputStream();
			isr = new InputStreamReader(is, "utf-8");
			br = new BufferedReader(isr);
			
			// 读取响应内容
			StringBuffer buffer = new StringBuffer();
			String str = null;
			while((str = br.readLine()) != null) {
				buffer.append(str);
			}
			
			result = buffer.toString();
		} catch (Exception e) {
			logger.error(e);
		} finally {
			IOUtils.closeQuietly(br);
			IOUtils.closeQuietly(isr);
			IOUtils.closeQuietly(is);
			conn.disconnect();
		}
		
		return result;
	}
	/**
	 * 将map数据转换为url请求参数
	 * 
	 * @param data
	 *            数据
	 * @return
	 */
	public static String urlEncode(Map<String, String> data) {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, String> entry : data.entrySet()) {
			sb.append(entry.getKey()).append("=").append(entry.getValue())
					.append("&");
		}

		return sb.toString();
	}
}

/**
 * 自定义信任管理器类
 *
 * 2016年3月28日 下午1:38:40
 * lsf@cnsebe.com
 *
 *
 */
class MyX509TrustManager implements X509TrustManager{
	
	/**
	 * 检查客户端证书
	 */
	@Override
	public void checkClientTrusted(X509Certificate[] arg0, String arg1)
			throws CertificateException {
		
	}

	/**
	 * 检查服务器端证书
	 */
	@Override
	public void checkServerTrusted(X509Certificate[] arg0, String arg1)
			throws CertificateException {
		
		
	}

	/**
	 * 返回受信任的X509证书数组
	 */
	@Override
	public X509Certificate[] getAcceptedIssuers() {
		
		return null;
	}
}

