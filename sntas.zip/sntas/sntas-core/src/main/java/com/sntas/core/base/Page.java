package com.sntas.core.base;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * Created by luoshuifang on 2016/8/18.
 */
public class Page<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 每页的行数
     */
    private Integer pageSize;
    /**
     * 当前页数
     */
    private Integer pageNo;
    /**
     * 总数量
     */
    private Long totalCount;
    /**
     * 总的页数
     */
    private Integer total;
    private List<T> result;

    public Page() {

    }

    public Page(List<T> list) {
        if (list instanceof com.github.pagehelper.Page) {
            com.github.pagehelper.Page page = (com.github.pagehelper.Page) list;
            this.pageNo = page.getPageNum();
            this.pageSize = page.getPageSize();
            this.result = page;
            this.totalCount = page.getTotal();
            this.total=page.getPages();
        } else if (list instanceof Collection) {
            this.pageNo = 1;
            this.pageSize = list.size();
            this.result = list;
            this.totalCount = (long) list.size();
            this.total=1;
        }

    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @JsonProperty("page")
    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    @JsonProperty("records")
    public Long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    @JsonProperty("result")
    public List<T> getResult() {
        return result;
    }

    public void setResult(List<T> result) {
        this.result = result;
    }
}
