package com.sntas.core.base;

import java.io.Serializable;

/**
 * Created by luoshuifang on 2016/5/11.
 */

public class ResultBase<T> implements Serializable {
    private String errorCode;
    private T data;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
