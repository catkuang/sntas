package com.sntas.core.base;


/**
 * Created by luoshuifang on 2016/4/28.
 */
public class TokenBase {
     private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
