package com.sntas.core.config;

import org.springframework.stereotype.Component;

/**
 * Created by luoshuifang on 2016/5/4.
 */
@Component
public class PropertiesConfig {

    private Double packageRate=0.5;

    public Double getPackageRate() {
        if(packageRate==null){
            return 0d;
        }
        return packageRate;
    }

    public void setPackageRate(Double packageRate) {
        this.packageRate = packageRate;
    }
}
