//package com.sntas.core.dubbo.filter;
//
//
//import com.alibaba.dubbo.rpc.*;
//
//import com.sntas.common.consts.ErrorCodeConst;
//import com.sntas.common.exception.ParamterException;
//import com.sntas.core.base.ResultBase;
//import org.apache.log4j.Logger;
//
///**
// * Created by luoshuifang on 2016/4/28.
// */
//public class ExceptionFilter implements Filter {
//    private static Logger logger= Logger.getLogger(ExceptionFilter.class);
//    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
//        Result result=invoker.invoke(invocation);
//        if(result.hasException()){
//            RpcResult  rpcResult=new RpcResult();
//            ResultBase resultBase=new ResultBase();
//            Throwable throwable=result.getException();
//            if(throwable instanceof ParamterException){
//                logger.error(((ParamterException)throwable).getMessage(),throwable);
//                resultBase.setErrorCode(ErrorCodeConst.RESULT_PARMTER_ERROR);
//            }else{
//                logger.error(throwable.getMessage(),throwable);
//                resultBase.setErrorCode(ErrorCodeConst.RESULT_EXCEPTION_ERROR);
//            }
//            throwable.printStackTrace();
//            rpcResult.setValue(resultBase);
//            result=rpcResult;
//        }
//
//        return result;
//    }
//}
