package com.sntas.core.spring.aop;


import com.sntas.common.enums.BaseErrorCodeEnum;
import com.sntas.common.exception.AuthException;
import com.sntas.core.anno.Auth;
import com.sntas.core.base.TokenBase;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * Created by luoshuifang on 2016/4/28.
 */
@Aspect
@Component
public class AuthAop {
    @Before("@annotation(com.sntas.core.anno.Auth)")
   public void authUser(JoinPoint joinPoint){
       Auth auth= (Auth) joinPoint.getSignature().getDeclaringType().getAnnotation(Auth.class);
        TokenBase tokenBase=null;
        for(Object obj: joinPoint.getArgs()){
            if(obj instanceof TokenBase){
                tokenBase=(TokenBase)obj;
                break;
            }
        }
        if(tokenBase==null||tokenBase.getToken()==null){
            throw new AuthException(BaseErrorCodeEnum.USER_NOTLOGIN_EXCEPTION);
        }
   }
}
