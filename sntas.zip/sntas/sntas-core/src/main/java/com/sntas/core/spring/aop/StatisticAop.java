package com.sntas.core.spring.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * Created by luoshuifang on 2016/4/28.
 */
@Aspect
@Component
public class StatisticAop {
    private static Logger logger= Logger.getLogger(StatisticAop.class);
//    @Pointcut("execution(* com.sntas..*.*(..))")
//    private void anyMethod(){}
//    @Around("anyMethod()")
//   public Object authUser(ProceedingJoinPoint joinPoint) throws Throwable {
//         Long maxMemory= Runtime.getRuntime().maxMemory();
//         Long freeMemory= Runtime.getRuntime().freeMemory();
//        String className=joinPoint.getSignature().getDeclaringTypeName();
//        String methodName=  joinPoint.getSignature().getName();
//
//        Long start=System.currentTimeMillis();
//        Object obj=joinPoint.proceed();
//        if((System.currentTimeMillis()-start)>100){
//          logger.info(className+"."+methodName+";time:"+(System.currentTimeMillis()-start)+"ms");
//        }
//        if((Runtime.getRuntime().freeMemory()-freeMemory)!=0){
//            logger.info(className+"."+methodName+";time:"+(Runtime.getRuntime().freeMemory()-freeMemory)+"b");
//        }
//        if(className.equals("com.cnsebe.tools.core.timer.task.service.StatisticBaseSalesTask")) {
//            logger.info(className+"."+methodName+";time:"+(System.currentTimeMillis()-start)+"ms");
//        }
//        return obj;
//   }
}
