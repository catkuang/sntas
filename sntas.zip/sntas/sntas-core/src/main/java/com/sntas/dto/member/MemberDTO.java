package com.sntas.dto.member;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by kjh on 2017/9/26.
 */
public class MemberDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    public Integer member_id;            //用户id
    public String member_sn;            //用户编码
    public String email;                    //邮件
    public String phone;                    //手机号
//    public String password;                //密码
    public String new_password;            //新密码
    public String token;                //令牌
    public String nickname;                //昵称
    public String truename;                //真实名称
    public String avatar;                //头像
    public Integer sex;                    //性别
    public Long birthday;                //生日
    public String idcard; //企业法人身份证
    public Integer login_num;            //登录次数
    public Long login_time;                //登录时间
//    public Long old_login_time;            //上次登录时间
    public String login_ip;                //登录ip
//    public String old_login_ip;            //上次登录ip
    public String member_address;           //会员住址
    private Date createTime;
    private Date updateTime;
    public String member_industry;


}
