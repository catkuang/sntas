package com.sntas.filter;

import com.alibaba.fastjson.JSON;

import com.sntas.common.exception.BaseException;
import com.sntas.core.base.ResultBean;
import org.springframework.web.util.NestedServletException;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by yanyifei on 2016/8/12.
 */

public class WebExceptionFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("过滤器初始化");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) servletResponse;
//        response.setHeader("Access-Control-Allow-Origin", "*");
//        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
//        response.setHeader("Access-Control-Max-Age", "3600");
//        response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } catch (BaseException e) {
            ResultBean resultBean = new ResultBean();
            resultBean.setCode(e.getCode());
            resultBean.setDesc(e.getDesc());
            servletResponse.reset();
            //servletResponse.setContentType("application/json");
            servletResponse.setContentType("text/plain");
            servletResponse.setCharacterEncoding("UTF-8");
            servletResponse.getWriter().print(JSON.toJSONString(resultBean));
            servletResponse.flushBuffer();
        } catch (NestedServletException e) {
            if (e.getCause() instanceof BaseException) {
                BaseException exception = (BaseException) e.getCause();
                ResultBean resultBean = new ResultBean();
                resultBean.setCode(exception.getCode());
                resultBean.setDesc(exception.getDesc());
                servletResponse.reset();
                //servletResponse.setContentType("application/json");
                servletResponse.setContentType("text/plain");
                servletResponse.setCharacterEncoding("UTF-8");
                servletResponse.getWriter().print(JSON.toJSONString(resultBean));
                servletResponse.flushBuffer();
            } else {
                ResultBean resultBean = new ResultBean();
                resultBean.setCode("-1");
                resultBean.setDesc("");
                servletResponse.reset();
                servletResponse.getWriter().print(JSON.toJSONString(resultBean));
                servletResponse.flushBuffer();
            }
        } catch (Exception e) {
            ResultBean resultBean = new ResultBean();
            resultBean.setCode("-1");
            resultBean.setDesc("");
            servletResponse.reset();
            servletResponse.getWriter().print(JSON.toJSONString(resultBean));
            servletResponse.flushBuffer();
        }
    }

    @Override
    public void destroy() {
        System.out.println("过滤器销毁");
    }
}
