package com.sntas.intercepter;


import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 用于登陆和功能权限验证的拦截器
 *
 * @author lsf
 * @version 1.0
 */
public class AuthInterceptor extends HandlerInterceptorAdapter {

//    @Autowired
//    LoginService loginService;

//    @Autowired
//    MemberService emberService;

    private final static Logger log = Logger.getLogger(AuthInterceptor.class);


    /**
     * 在业务处理器处理请求之前被调用 如果返回false 从当前的拦截器往回执行所有拦截器的afterCompletion(),再退出拦截器链
     * 如果返回true 执行下一个拦截器,直到所有的拦截器都执行完毕 再执行被拦截的Controller 然后进入拦截器链,
     * 从最后一个拦截器往回执行所有的postHandle() 接着再从最后一个拦截器往回执行所有的afterCompletion()
     * <p>
     * 可根据需要继续重写postHandle(显示视图前拦截)，postHandle(显示完视图后拦截)
     */
    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
//        // 排除不进行拦截的请求
//        StewardUser user = SessionUtils.getUser(request);
//
//        //测试阶段
////		String phone = "13646837909";
////		String password = "123456";
////        String phone = "15058111887";
////        String password = "36b6dcde7f95493758218c0f7e403c35";
//		String phone = "13601312187";
//		String password = "5cf9baae37d74a7d770eacca24213641";
//        MemberDTO memberDTO = new MemberDTO();
//        memberDTO.phone = phone;
//        memberDTO.password = password;
//        memberDTO.login_ip ="192.168.1.123";
//        try {
//            memberDTO = emberService.login(memberDTO);
//        } catch (BaseException e) {
//            throw new AuthException(BaseErrorCodeEnum.CONVERT_NO_USER_EXCEPTION);
//        }
//
//        user = new StewardUser();
//        user.setUserId(memberDTO.member_id);
//        user.setPhone(memberDTO.phone);
//        user.setEmail(memberDTO.email);
//        user.setToken(memberDTO.token);
//
//        if (memberDTO.parent != null) {
//            user.setParentId(memberDTO.parent.member_id);
//        }
//
//        SessionUtils.setUser(request, user);
//        if (user == null) {
//            // 检测到登陆异常
//            return loginService.ifLogin(request, response);
//        } else {
//            CookieUtils.setSebeCookie(request, response, "user_token", user.getToken(), true);
//        }
        return true;
    }
}
