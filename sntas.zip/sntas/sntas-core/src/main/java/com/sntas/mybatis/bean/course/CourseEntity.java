package com.sntas.mybatis.bean.course;

import java.util.Date;

/**
 * 
 */
public class CourseEntity {
    /**
     * 
     */
    private Integer courseId;

    /**
     * 课程名称
     */
    private String name;

    /**
     * 课程图片
     */
    private String imgUrl;

    /**
     * 简介
     */
    private String synopsis;

    /**
     * 详细介绍
     */
    private String introduce;

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 
     */
    private Date endTime;

    /**
     * 资源路径
     */
    private String resourceUrl;

    /**
     * 资源时长
     */
    private String duration;

    /**
     * 资源大小
     */
    private String bytes;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date updateTime;

    public CourseEntity(Integer courseId, String name, String imgUrl, String synopsis, String introduce, Date startTime, Date endTime, String resourceUrl, String duration, String bytes, Date createTime, Date updateTime) {
        this.courseId = courseId;
        this.name = name;
        this.imgUrl = imgUrl;
        this.synopsis = synopsis;
        this.introduce = introduce;
        this.startTime = startTime;
        this.endTime = endTime;
        this.resourceUrl = resourceUrl;
        this.duration = duration;
        this.bytes = bytes;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public CourseEntity() {
        super();
    }

    /**
     * 
     * @return course_id 
     */
    public Integer getCourseId() {
        return courseId;
    }

    /**
     * 
     * @param courseId 
     */
    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    /**
     * 课程名称
     * @return name 课程名称
     */
    public String getName() {
        return name;
    }

    /**
     * 课程名称
     * @param name 课程名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 课程图片
     * @return img_url 课程图片
     */
    public String getImgUrl() {
        return imgUrl;
    }

    /**
     * 课程图片
     * @param imgUrl 课程图片
     */
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    /**
     * 简介
     * @return synopsis 简介
     */
    public String getSynopsis() {
        return synopsis;
    }

    /**
     * 简介
     * @param synopsis 简介
     */
    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis == null ? null : synopsis.trim();
    }

    /**
     * 详细介绍
     * @return introduce 详细介绍
     */
    public String getIntroduce() {
        return introduce;
    }

    /**
     * 详细介绍
     * @param introduce 详细介绍
     */
    public void setIntroduce(String introduce) {
        this.introduce = introduce == null ? null : introduce.trim();
    }

    /**
     * 开始时间
     * @return start_time 开始时间
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * 开始时间
     * @param startTime 开始时间
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * 
     * @return end_time 
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 
     * @param endTime 
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * 资源路径
     * @return resource_url 资源路径
     */
    public String getResourceUrl() {
        return resourceUrl;
    }

    /**
     * 资源路径
     * @param resourceUrl 资源路径
     */
    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl == null ? null : resourceUrl.trim();
    }

    /**
     * 资源时长
     * @return duration 资源时长
     */
    public String getDuration() {
        return duration;
    }

    /**
     * 资源时长
     * @param duration 资源时长
     */
    public void setDuration(String duration) {
        this.duration = duration == null ? null : duration.trim();
    }

    /**
     * 资源大小
     * @return bytes 资源大小
     */
    public String getBytes() {
        return bytes;
    }

    /**
     * 资源大小
     * @param bytes 资源大小
     */
    public void setBytes(String bytes) {
        this.bytes = bytes == null ? null : bytes.trim();
    }

    /**
     * 
     * @return create_time 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 
     * @param createTime 
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 
     * @return update_time 
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 
     * @param updateTime 
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}