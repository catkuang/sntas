package com.sntas.mybatis.bean.course;

/**
 * 
 */
public class CourseStatisticsEntity {
    /**
     * 
     */
    private Integer courseStatisticsId;

    /**
     * 课程id
     */
    private Integer courseId;

    /**
     * 收藏数
     */
    private Integer collectNum;

    /**
     * 点击数
     */
    private Integer pvNum;

    /**
     * 预约数
     */
    private Integer subscribeNum;

    /**
     * 下载数
     */
    private Integer downloadNum;

    /**
     * 已购人数
     */
    private Integer buyNum;

    public CourseStatisticsEntity(Integer courseStatisticsId, Integer courseId, Integer collectNum, Integer pvNum, Integer subscribeNum, Integer downloadNum, Integer buyNum) {
        this.courseStatisticsId = courseStatisticsId;
        this.courseId = courseId;
        this.collectNum = collectNum;
        this.pvNum = pvNum;
        this.subscribeNum = subscribeNum;
        this.downloadNum = downloadNum;
        this.buyNum = buyNum;
    }

    public CourseStatisticsEntity() {
        super();
    }

    /**
     * 
     * @return course_statistics_id 
     */
    public Integer getCourseStatisticsId() {
        return courseStatisticsId;
    }

    /**
     * 
     * @param courseStatisticsId 
     */
    public void setCourseStatisticsId(Integer courseStatisticsId) {
        this.courseStatisticsId = courseStatisticsId;
    }

    /**
     * 课程id
     * @return course_id 课程id
     */
    public Integer getCourseId() {
        return courseId;
    }

    /**
     * 课程id
     * @param courseId 课程id
     */
    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    /**
     * 收藏数
     * @return collect_num 收藏数
     */
    public Integer getCollectNum() {
        return collectNum;
    }

    /**
     * 收藏数
     * @param collectNum 收藏数
     */
    public void setCollectNum(Integer collectNum) {
        this.collectNum = collectNum;
    }

    /**
     * 点击数
     * @return pv_num 点击数
     */
    public Integer getPvNum() {
        return pvNum;
    }

    /**
     * 点击数
     * @param pvNum 点击数
     */
    public void setPvNum(Integer pvNum) {
        this.pvNum = pvNum;
    }

    /**
     * 预约数
     * @return subscribe_num 预约数
     */
    public Integer getSubscribeNum() {
        return subscribeNum;
    }

    /**
     * 预约数
     * @param subscribeNum 预约数
     */
    public void setSubscribeNum(Integer subscribeNum) {
        this.subscribeNum = subscribeNum;
    }

    /**
     * 下载数
     * @return download_num 下载数
     */
    public Integer getDownloadNum() {
        return downloadNum;
    }

    /**
     * 下载数
     * @param downloadNum 下载数
     */
    public void setDownloadNum(Integer downloadNum) {
        this.downloadNum = downloadNum;
    }

    /**
     * 已购人数
     * @return buy_num 已购人数
     */
    public Integer getBuyNum() {
        return buyNum;
    }

    /**
     * 已购人数
     * @param buyNum 已购人数
     */
    public void setBuyNum(Integer buyNum) {
        this.buyNum = buyNum;
    }
}