package com.sntas.mybatis.bean.course;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 */
public class KurseEntity {
    /**
     * 系列课程id
     */
    private Integer kurseId;

    /**
     * 系列课程名称
     */
    private String name;

    /**
     * 宣传图片
     */
    private String imgUrl;

    /**
     * 介绍
     */
    private String introduce;

    /**
     * 上课老师
     */
    private Integer teacherId;

    /**
     * 原始价格
     */
    private BigDecimal originalPrice;

    /**
     * 优惠价格
     */
    private BigDecimal preferentialPrice;

    /**
     * 交流群id
     */
    private Integer groupId;

    /**
     * 交流群号
     */
    private String groupSn;

    /**
     * 课程开始时间
     */
    private Date startTime;

    /**
     * 课程结束时间
     */
    private Date endTime;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date updateTime;

    public KurseEntity(Integer kurseId, String name, String imgUrl, String introduce, Integer teacherId, BigDecimal originalPrice, BigDecimal preferentialPrice, Integer groupId, String groupSn, Date startTime, Date endTime, Date createTime, Date updateTime) {
        this.kurseId = kurseId;
        this.name = name;
        this.imgUrl = imgUrl;
        this.introduce = introduce;
        this.teacherId = teacherId;
        this.originalPrice = originalPrice;
        this.preferentialPrice = preferentialPrice;
        this.groupId = groupId;
        this.groupSn = groupSn;
        this.startTime = startTime;
        this.endTime = endTime;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public KurseEntity() {
        super();
    }

    /**
     * 系列课程id
     * @return kurse_id 系列课程id
     */
    public Integer getKurseId() {
        return kurseId;
    }

    /**
     * 系列课程id
     * @param kurseId 系列课程id
     */
    public void setKurseId(Integer kurseId) {
        this.kurseId = kurseId;
    }

    /**
     * 系列课程名称
     * @return name 系列课程名称
     */
    public String getName() {
        return name;
    }

    /**
     * 系列课程名称
     * @param name 系列课程名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 宣传图片
     * @return img_url 宣传图片
     */
    public String getImgUrl() {
        return imgUrl;
    }

    /**
     * 宣传图片
     * @param imgUrl 宣传图片
     */
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    /**
     * 介绍
     * @return introduce 介绍
     */
    public String getIntroduce() {
        return introduce;
    }

    /**
     * 介绍
     * @param introduce 介绍
     */
    public void setIntroduce(String introduce) {
        this.introduce = introduce == null ? null : introduce.trim();
    }

    /**
     * 上课老师
     * @return teacher_id 上课老师
     */
    public Integer getTeacherId() {
        return teacherId;
    }

    /**
     * 上课老师
     * @param teacherId 上课老师
     */
    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    /**
     * 原始价格
     * @return original_price 原始价格
     */
    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    /**
     * 原始价格
     * @param originalPrice 原始价格
     */
    public void setOriginalPrice(BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    /**
     * 优惠价格
     * @return preferential_price 优惠价格
     */
    public BigDecimal getPreferentialPrice() {
        return preferentialPrice;
    }

    /**
     * 优惠价格
     * @param preferentialPrice 优惠价格
     */
    public void setPreferentialPrice(BigDecimal preferentialPrice) {
        this.preferentialPrice = preferentialPrice;
    }

    /**
     * 交流群id
     * @return group_id 交流群id
     */
    public Integer getGroupId() {
        return groupId;
    }

    /**
     * 交流群id
     * @param groupId 交流群id
     */
    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    /**
     * 交流群号
     * @return group_sn 交流群号
     */
    public String getGroupSn() {
        return groupSn;
    }

    /**
     * 交流群号
     * @param groupSn 交流群号
     */
    public void setGroupSn(String groupSn) {
        this.groupSn = groupSn == null ? null : groupSn.trim();
    }

    /**
     * 课程开始时间
     * @return start_time 课程开始时间
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * 课程开始时间
     * @param startTime 课程开始时间
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * 课程结束时间
     * @return end_time 课程结束时间
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 课程结束时间
     * @param endTime 课程结束时间
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * 
     * @return create_time 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 
     * @param createTime 
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 
     * @return update_time 
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 
     * @param updateTime 
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}