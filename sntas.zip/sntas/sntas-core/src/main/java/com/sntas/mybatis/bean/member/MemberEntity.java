package com.sntas.mybatis.bean.member;

import java.util.Date;

/**
 * 
 */
public class MemberEntity {
    /**
     * 会员id
     */
    private Integer memberId;

    /**
     * 会员编码
     */
    private String memberSn;

    /**
     * 会员邮箱
     */
    private String memberEmail;

    /**
     * 会员手机号
     */
    private String memberPhone;

    /**
     * 会员密码
     */
    private String memberPasswd;

    /**
     * 真实姓名
     */
    private String memberTruename;

    /**
     * 会员昵称
     */
    private String memberNickname;

    /**
     * 会员头像
     */
    private String memberAvatar;

    /**
     * 会员性别
     */
    private Byte memberSex;

    /**
     * 生日
     */
    private Date memberBirthday;

    /**
     * 会员身份证
     */
    private String memberIdentificationCard;

    /**
     * 所属行业
     */
    private String memberIndustry;

    /**
     * 会员住址
     */
    private String memberAddress;

    /**
     * 登录次数
     */
    private Integer memberLoginNum;

    /**
     * 当前登录时间
     */
    private Date memberLoginTime;

    /**
     * 上次登录时间
     */
    private Date memberOldLoginTime;

    /**
     * 当前登录ip
     */
    private String memberLoginIp;

    /**
     * 上次登录ip
     */
    private String memberOldLoginIp;

    /**
     * 新增时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    public MemberEntity(Integer memberId, String memberSn, String memberEmail, String memberPhone, String memberPasswd, String memberTruename, String memberNickname, String memberAvatar, Byte memberSex, Date memberBirthday, String memberIdentificationCard, String memberIndustry, String memberAddress, Integer memberLoginNum, Date memberLoginTime, Date memberOldLoginTime, String memberLoginIp, String memberOldLoginIp, Date createTime, Date updateTime) {
        this.memberId = memberId;
        this.memberSn = memberSn;
        this.memberEmail = memberEmail;
        this.memberPhone = memberPhone;
        this.memberPasswd = memberPasswd;
        this.memberTruename = memberTruename;
        this.memberNickname = memberNickname;
        this.memberAvatar = memberAvatar;
        this.memberSex = memberSex;
        this.memberBirthday = memberBirthday;
        this.memberIdentificationCard = memberIdentificationCard;
        this.memberIndustry = memberIndustry;
        this.memberAddress = memberAddress;
        this.memberLoginNum = memberLoginNum;
        this.memberLoginTime = memberLoginTime;
        this.memberOldLoginTime = memberOldLoginTime;
        this.memberLoginIp = memberLoginIp;
        this.memberOldLoginIp = memberOldLoginIp;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public MemberEntity() {
        super();
    }

    /**
     * 会员id
     * @return member_id 会员id
     */
    public Integer getMemberId() {
        return memberId;
    }

    /**
     * 会员id
     * @param memberId 会员id
     */
    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    /**
     * 会员编码
     * @return member_sn 会员编码
     */
    public String getMemberSn() {
        return memberSn;
    }

    /**
     * 会员编码
     * @param memberSn 会员编码
     */
    public void setMemberSn(String memberSn) {
        this.memberSn = memberSn == null ? null : memberSn.trim();
    }

    /**
     * 会员邮箱
     * @return member_email 会员邮箱
     */
    public String getMemberEmail() {
        return memberEmail;
    }

    /**
     * 会员邮箱
     * @param memberEmail 会员邮箱
     */
    public void setMemberEmail(String memberEmail) {
        this.memberEmail = memberEmail == null ? null : memberEmail.trim();
    }

    /**
     * 会员手机号
     * @return member_phone 会员手机号
     */
    public String getMemberPhone() {
        return memberPhone;
    }

    /**
     * 会员手机号
     * @param memberPhone 会员手机号
     */
    public void setMemberPhone(String memberPhone) {
        this.memberPhone = memberPhone == null ? null : memberPhone.trim();
    }

    /**
     * 会员密码
     * @return member_passwd 会员密码
     */
    public String getMemberPasswd() {
        return memberPasswd;
    }

    /**
     * 会员密码
     * @param memberPasswd 会员密码
     */
    public void setMemberPasswd(String memberPasswd) {
        this.memberPasswd = memberPasswd == null ? null : memberPasswd.trim();
    }

    /**
     * 真实姓名
     * @return member_truename 真实姓名
     */
    public String getMemberTruename() {
        return memberTruename;
    }

    /**
     * 真实姓名
     * @param memberTruename 真实姓名
     */
    public void setMemberTruename(String memberTruename) {
        this.memberTruename = memberTruename == null ? null : memberTruename.trim();
    }

    /**
     * 会员昵称
     * @return member_nickname 会员昵称
     */
    public String getMemberNickname() {
        return memberNickname;
    }

    /**
     * 会员昵称
     * @param memberNickname 会员昵称
     */
    public void setMemberNickname(String memberNickname) {
        this.memberNickname = memberNickname == null ? null : memberNickname.trim();
    }

    /**
     * 会员头像
     * @return member_avatar 会员头像
     */
    public String getMemberAvatar() {
        return memberAvatar;
    }

    /**
     * 会员头像
     * @param memberAvatar 会员头像
     */
    public void setMemberAvatar(String memberAvatar) {
        this.memberAvatar = memberAvatar == null ? null : memberAvatar.trim();
    }

    /**
     * 会员性别
     * @return member_sex 会员性别
     */
    public Byte getMemberSex() {
        return memberSex;
    }

    /**
     * 会员性别
     * @param memberSex 会员性别
     */
    public void setMemberSex(Byte memberSex) {
        this.memberSex = memberSex;
    }

    /**
     * 生日
     * @return member_birthday 生日
     */
    public Date getMemberBirthday() {
        return memberBirthday;
    }

    /**
     * 生日
     * @param memberBirthday 生日
     */
    public void setMemberBirthday(Date memberBirthday) {
        this.memberBirthday = memberBirthday;
    }

    /**
     * 会员身份证
     * @return member_identification_card 会员身份证
     */
    public String getMemberIdentificationCard() {
        return memberIdentificationCard;
    }

    /**
     * 会员身份证
     * @param memberIdentificationCard 会员身份证
     */
    public void setMemberIdentificationCard(String memberIdentificationCard) {
        this.memberIdentificationCard = memberIdentificationCard == null ? null : memberIdentificationCard.trim();
    }

    /**
     * 所属行业
     * @return member_industry 所属行业
     */
    public String getMemberIndustry() {
        return memberIndustry;
    }

    /**
     * 所属行业
     * @param memberIndustry 所属行业
     */
    public void setMemberIndustry(String memberIndustry) {
        this.memberIndustry = memberIndustry == null ? null : memberIndustry.trim();
    }

    /**
     * 会员住址
     * @return member_address 会员住址
     */
    public String getMemberAddress() {
        return memberAddress;
    }

    /**
     * 会员住址
     * @param memberAddress 会员住址
     */
    public void setMemberAddress(String memberAddress) {
        this.memberAddress = memberAddress == null ? null : memberAddress.trim();
    }

    /**
     * 登录次数
     * @return member_login_num 登录次数
     */
    public Integer getMemberLoginNum() {
        return memberLoginNum;
    }

    /**
     * 登录次数
     * @param memberLoginNum 登录次数
     */
    public void setMemberLoginNum(Integer memberLoginNum) {
        this.memberLoginNum = memberLoginNum;
    }

    /**
     * 当前登录时间
     * @return member_login_time 当前登录时间
     */
    public Date getMemberLoginTime() {
        return memberLoginTime;
    }

    /**
     * 当前登录时间
     * @param memberLoginTime 当前登录时间
     */
    public void setMemberLoginTime(Date memberLoginTime) {
        this.memberLoginTime = memberLoginTime;
    }

    /**
     * 上次登录时间
     * @return member_old_login_time 上次登录时间
     */
    public Date getMemberOldLoginTime() {
        return memberOldLoginTime;
    }

    /**
     * 上次登录时间
     * @param memberOldLoginTime 上次登录时间
     */
    public void setMemberOldLoginTime(Date memberOldLoginTime) {
        this.memberOldLoginTime = memberOldLoginTime;
    }

    /**
     * 当前登录ip
     * @return member_login_ip 当前登录ip
     */
    public String getMemberLoginIp() {
        return memberLoginIp;
    }

    /**
     * 当前登录ip
     * @param memberLoginIp 当前登录ip
     */
    public void setMemberLoginIp(String memberLoginIp) {
        this.memberLoginIp = memberLoginIp == null ? null : memberLoginIp.trim();
    }

    /**
     * 上次登录ip
     * @return member_old_login_ip 上次登录ip
     */
    public String getMemberOldLoginIp() {
        return memberOldLoginIp;
    }

    /**
     * 上次登录ip
     * @param memberOldLoginIp 上次登录ip
     */
    public void setMemberOldLoginIp(String memberOldLoginIp) {
        this.memberOldLoginIp = memberOldLoginIp == null ? null : memberOldLoginIp.trim();
    }

    /**
     * 新增时间
     * @return create_time 新增时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 新增时间
     * @param createTime 新增时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改时间
     * @return update_time 修改时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 修改时间
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}