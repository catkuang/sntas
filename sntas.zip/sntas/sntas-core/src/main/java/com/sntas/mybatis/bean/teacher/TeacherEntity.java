package com.sntas.mybatis.bean.teacher;

import java.util.Date;

/**
 * 
 */
public class TeacherEntity {
    /**
     * 外教id
     */
    private Integer teacherId;

    /**
     * 外教编码
     */
    private String teacherSn;

    /**
     * 外教邮箱
     */
    private String teacherEmail;

    /**
     * 外教手机号
     */
    private String teacherPhone;

    /**
     * 真实姓名
     */
    private String teacherTruename;

    /**
     * 外教昵称
     */
    private String teacherNickname;

    /**
     * 外教头像
     */
    private String teacherAvatar;

    /**
     * 外教简介
     */
    private String teacherDesc;

    /**
     * 外教详细介绍
     */
    private String teacherIntroduce;

    /**
     * 新增时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    public TeacherEntity(Integer teacherId, String teacherSn, String teacherEmail, String teacherPhone, String teacherTruename, String teacherNickname, String teacherAvatar, String teacherDesc, String teacherIntroduce, Date createTime, Date updateTime) {
        this.teacherId = teacherId;
        this.teacherSn = teacherSn;
        this.teacherEmail = teacherEmail;
        this.teacherPhone = teacherPhone;
        this.teacherTruename = teacherTruename;
        this.teacherNickname = teacherNickname;
        this.teacherAvatar = teacherAvatar;
        this.teacherDesc = teacherDesc;
        this.teacherIntroduce = teacherIntroduce;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public TeacherEntity() {
        super();
    }

    /**
     * 外教id
     * @return teacher_id 外教id
     */
    public Integer getTeacherId() {
        return teacherId;
    }

    /**
     * 外教id
     * @param teacherId 外教id
     */
    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    /**
     * 外教编码
     * @return teacher_sn 外教编码
     */
    public String getTeacherSn() {
        return teacherSn;
    }

    /**
     * 外教编码
     * @param teacherSn 外教编码
     */
    public void setTeacherSn(String teacherSn) {
        this.teacherSn = teacherSn == null ? null : teacherSn.trim();
    }

    /**
     * 外教邮箱
     * @return teacher_email 外教邮箱
     */
    public String getTeacherEmail() {
        return teacherEmail;
    }

    /**
     * 外教邮箱
     * @param teacherEmail 外教邮箱
     */
    public void setTeacherEmail(String teacherEmail) {
        this.teacherEmail = teacherEmail == null ? null : teacherEmail.trim();
    }

    /**
     * 外教手机号
     * @return teacher_phone 外教手机号
     */
    public String getTeacherPhone() {
        return teacherPhone;
    }

    /**
     * 外教手机号
     * @param teacherPhone 外教手机号
     */
    public void setTeacherPhone(String teacherPhone) {
        this.teacherPhone = teacherPhone == null ? null : teacherPhone.trim();
    }

    /**
     * 真实姓名
     * @return teacher_truename 真实姓名
     */
    public String getTeacherTruename() {
        return teacherTruename;
    }

    /**
     * 真实姓名
     * @param teacherTruename 真实姓名
     */
    public void setTeacherTruename(String teacherTruename) {
        this.teacherTruename = teacherTruename == null ? null : teacherTruename.trim();
    }

    /**
     * 外教昵称
     * @return teacher_nickname 外教昵称
     */
    public String getTeacherNickname() {
        return teacherNickname;
    }

    /**
     * 外教昵称
     * @param teacherNickname 外教昵称
     */
    public void setTeacherNickname(String teacherNickname) {
        this.teacherNickname = teacherNickname == null ? null : teacherNickname.trim();
    }

    /**
     * 外教头像
     * @return teacher_avatar 外教头像
     */
    public String getTeacherAvatar() {
        return teacherAvatar;
    }

    /**
     * 外教头像
     * @param teacherAvatar 外教头像
     */
    public void setTeacherAvatar(String teacherAvatar) {
        this.teacherAvatar = teacherAvatar == null ? null : teacherAvatar.trim();
    }

    /**
     * 外教简介
     * @return teacher_desc 外教简介
     */
    public String getTeacherDesc() {
        return teacherDesc;
    }

    /**
     * 外教简介
     * @param teacherDesc 外教简介
     */
    public void setTeacherDesc(String teacherDesc) {
        this.teacherDesc = teacherDesc == null ? null : teacherDesc.trim();
    }

    /**
     * 外教详细介绍
     * @return teacher_introduce 外教详细介绍
     */
    public String getTeacherIntroduce() {
        return teacherIntroduce;
    }

    /**
     * 外教详细介绍
     * @param teacherIntroduce 外教详细介绍
     */
    public void setTeacherIntroduce(String teacherIntroduce) {
        this.teacherIntroduce = teacherIntroduce == null ? null : teacherIntroduce.trim();
    }

    /**
     * 新增时间
     * @return create_time 新增时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 新增时间
     * @param createTime 新增时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改时间
     * @return update_time 修改时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 修改时间
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}