package com.sntas.mybatis.mapper.course;

import com.sntas.mybatis.bean.course.CourseEntity;

public interface CourseEntityMapper {
    int deleteByPrimaryKey(Integer courseId);

    int insert(CourseEntity record);

    int insertSelective(CourseEntity record);

    CourseEntity selectByPrimaryKey(Integer courseId);

    int updateByPrimaryKeySelective(CourseEntity record);

    int updateByPrimaryKey(CourseEntity record);
}