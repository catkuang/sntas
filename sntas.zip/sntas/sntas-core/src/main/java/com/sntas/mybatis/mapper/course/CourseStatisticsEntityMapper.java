package com.sntas.mybatis.mapper.course;

import com.sntas.mybatis.bean.course.CourseStatisticsEntity;

public interface CourseStatisticsEntityMapper {
    int deleteByPrimaryKey(Integer courseStatisticsId);

    int insert(CourseStatisticsEntity record);

    int insertSelective(CourseStatisticsEntity record);

    CourseStatisticsEntity selectByPrimaryKey(Integer courseStatisticsId);

    int updateByPrimaryKeySelective(CourseStatisticsEntity record);

    int updateByPrimaryKey(CourseStatisticsEntity record);
}