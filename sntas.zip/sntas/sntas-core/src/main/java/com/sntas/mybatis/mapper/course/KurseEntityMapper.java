package com.sntas.mybatis.mapper.course;

import com.sntas.mybatis.bean.course.KurseEntity;

public interface KurseEntityMapper {
    int deleteByPrimaryKey(Integer kurseId);

    int insert(KurseEntity record);

    int insertSelective(KurseEntity record);

    KurseEntity selectByPrimaryKey(Integer kurseId);

    int updateByPrimaryKeySelective(KurseEntity record);

    int updateByPrimaryKey(KurseEntity record);
}