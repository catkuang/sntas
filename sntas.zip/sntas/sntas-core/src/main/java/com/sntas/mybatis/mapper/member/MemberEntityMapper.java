package com.sntas.mybatis.mapper.member;

import com.sntas.mybatis.bean.member.MemberEntity;
import org.springframework.stereotype.Service;

@Service
public interface MemberEntityMapper {
    int deleteByPrimaryKey(Integer memberId);

    int insert(MemberEntity record);

    int insertSelective(MemberEntity record);

    MemberEntity selectByPrimaryKey(Integer memberId);

    int updateByPrimaryKeySelective(MemberEntity record);

    int updateByPrimaryKey(MemberEntity record);

    MemberEntity selectMemberByPhone(String phone);
}