package com.sntas.mybatis.mapper.teacher;

import com.sntas.mybatis.bean.teacher.TeacherEntity;

public interface TeacherEntityMapper {
    int deleteByPrimaryKey(Integer teacherId);

    int insert(TeacherEntity record);

    int insertSelective(TeacherEntity record);

    TeacherEntity selectByPrimaryKey(Integer teacherId);

    int updateByPrimaryKeySelective(TeacherEntity record);

    int updateByPrimaryKey(TeacherEntity record);
}