package com.sntas.service.member;


import com.sntas.dto.member.MemberDTO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public interface IMemberService {
    /**
     * 查看会员
     * @param id 会员id
     * @return 会员
     */
    public MemberDTO findOne(Integer id);



    /**
     * 会员注册
     * @param phone
     * @param password
     * @param login_ip
     * @return
     */
    public MemberDTO register(String phone, String password,String login_ip);

    /**
     * 会员登录
     * @param phone
     * @param password
     * @return
     */
    public MemberDTO login(String phone, String password, String captcha, String login_ip);

    /**
     * 会员验证
     * @param token 会员令牌
     */
    public MemberDTO verify(String token, String ip);

    /**
     * 会员登出
     * @param token 会员令牌
     */
    public void logout(String token, String ip);





//    /**
//     * 根据手机号或邮箱查看会员
//     * @param account 会员账户
//     * @return 会员
//     */
//    public MemberDTO findOneByMobileOrMail(String account);
//
//    /**
//     * 编辑会员，根据DTO中的字段是否为null来判断该字段是否更新
//     * @param memberDTO 会员
//     * @return 会员
//     */
//    public MemberDTO edit(MemberDTO memberDTO);
//
//    /**
//     * 编辑会员
//     * @param memberDTO 会员
//     * @return 会员
//     */
//    public MemberDTO editByPhone(MemberDTO memberDTO);
//
//    /**
//     * 会员登录
//     * @param memberDTO 会员
//     * @return 会员
//     */
//    public MemberDTO login(MemberDTO memberDTO);
//
//    /**
//     * 会员验证
//     * @param token 会员令牌
//     */
//    public MemberDTO verify(String token, String ip);
//
//    /**
//     * 会员登出
//     * @param token 会员令牌
//     */
//    public void logout(String token, String ip);
//
//    /**
//     * 设置会员提醒方式
//     * @param memberDTO 会员
//     */
//    public void setRemind(MemberDTO memberDTO);
//
//    /**
//     * 设置会员密码
//     * @param memberDTO 会员
//     */
//    public void setPwd(MemberDTO memberDTO);
//
//    /**
//     * 修改会员密码
//     * @param memberDTO 会员
//     */
//    public void updatePassword(MemberDTO memberDTO, String token);
//
//    /**
//     * 设置会员手机号
//     * @param memberDTO 会员
//     */
//    public void setMobile(MemberDTO memberDTO);
//
//    /**
//     * 设置会员头像
//     * @param memberDTO 会员
//     */
//    public void setAvatar(MemberDTO memberDTO);
//
//    /**
//     * 设置会员邮箱
//     * @param memberDTO 会员
//     */
//    public void setEMail(MemberDTO memberDTO);



    /**
     * 设置提醒发送验证码
     * @param phone
     */
    public void sendCodeBySetRemind(String phone);

    /**
     * 注册验证验证码
     * @param phone
     * @param code
     */
    public void validateCodeBySetRemind(String phone, String code);


    /**
     * 注册发送验证码
     * @param phone
     */
    public void sendCodeByRegister(String phone);

    /**
     * 注册验证验证码
     * @param phone
     * @param code
     */
    public void validateCodeByRegister(String phone, String code);


    /**
     * 找回密码发送验证码
     * @param phone
     */
    public void sendCodeByFindPwd(String phone);

    /**
     * 找回密码验证验证码
     * @param phone
     * @param code
     */
    public void validateCodeByFindPwd(String phone, String code);


    /**
     * 登录发送验证码
     * @param phone
     */
    public void sendCodeByLogin(String phone);

    /**
     * 登录验证验证码
     * @param phone
     * @param code
     */
    public void validateCodeByLogin(String phone, String code);



}
