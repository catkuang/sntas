//package com.sntas.service.member;
//
///**
// * Created by LWD on 2016/11/1.
// */
//public interface MemberCacheService {
//
//    /**
//     * 添加缓存
//     * @param type 类型
//     * @param account   联系方式
//     * @param num  获取验证码位数
//     * @return
//     */
//    public String set(String type, String account, int num);
//
//    /**
//     * 获取缓存
//     * @param type 类型
//     * @param account 联系方式
//     * @return
//     */
//    public String get(String type, String account);
//
//
//    /**
//     * 获取缓存 原生的
//     * @param type 类型
//     * @param account 联系方式
//     * @return
//     */
//    public String getOrg(String type, String account);
//
//
//    /**
//     * 添加缓存
//     * @param type 类型
//     * @param account   联系方式
//     * @param times  时间
//     * @param times  值
//     * @return
//     */
//    public void set(String type, String account, Integer times, String value);
//
//
//    /**
//     * 添加缓存
//     * @param type 类型
//     * @param account   联系方式
//     * @param times  时间
//     * @param times  值
//     * @return
//     */
//    public void setOrg(String type, String account, Integer times, String value);
//
//    /**
//     * 删除缓存
//     * @param type 类型
//     * @param account   联系方式
//     * @return
//     */
//    public void del(String type, String account);
//
//
//    public void incr(String type, String account);
//
//
//    /**
//     * 模糊删除
//     *
//     * @param key
//     */
//    public void delByKeys(String key);
//}
