//package com.sntas.service.member.impl;
//
//import com.sntas.common.consts.CacheConstant;
//import com.sntas.common.exception.ParamterException;
//import com.sntas.common.utils.SmsCode;
//import com.sntas.service.member.MemberCacheService;
//import com.sntas.service.redis.RedisClientTemplate;
//import org.apache.commons.lang.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
///**
// * Created by LWD on 2016/11/1.
// */
//@Service("memberCacheService")
//public class MemberCacheServiceImpl implements MemberCacheService {
//    @Autowired
//    RedisClientTemplate redisClientTemplate;
//
//    @Override
//    public String set(String type, String account, int num) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                ))
//                || num < 1)
//            throw new ParamterException();
//
//        String code = SmsCode.smsCapture(num);
//
//        redisClientTemplate.setex(type + account, CacheConstant.CACHE_SMS_TIME, code);
//        return code;
//    }
//
//    @Override
//    public String get(String type, String account) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                )))
//            throw new ParamterException();
//
////        String code = (String)cacheService.getByKey(type + account);
//        String code = (String)redisClientTemplate.get(type + account);
//
//        return code;
//    }
//
//
//    @Override
//    public String getOrg(String type, String account) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                )))
//            throw new ParamterException();
//
//        //String code = (String)cacheService.getByKey(type + account);
////        JedisConnection jedisConnection= jedisConnectionFactory.getConnection();
////        Jedis redisClientTemplate = jedisConnection.getNativeConnection();
//
//        byte[] code = redisClientTemplate.get((type+account).getBytes());
////        jedisConnection.close();
//        if(code==null){
//            return null;
//        }
//        return new String(code);
//    }
//
//    @Override
//    public void set(String type, String account, Integer times, String value) {
//            if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                    (null == account || StringUtils.isEmpty(account.trim())
//                    )))
//                throw new ParamterException();
//
////            cacheService.setByKey(type + account,times, value);
//        redisClientTemplate.setex(type + account,times, value);
//    }
//
//    @Override
//    public void setOrg(String type, String account, Integer times, String value) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                )))
//            throw new ParamterException();
//
//        redisClientTemplate.set((type+account).getBytes(),value.getBytes());
//        redisClientTemplate.expire((type+account).getBytes(),times);
//
//    }
//
//
//
//    @Override
//    public void del(String type, String account) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                )))
//            throw new ParamterException();
//
//        redisClientTemplate.del(type + account);
//    }
//
//    @Override
//    public void incr(String type, String account) {
//        if(((null == type || StringUtils.isEmpty(type.trim())) &&
//                (null == account || StringUtils.isEmpty(account.trim())
//                )))
//            throw new ParamterException();
//
//        redisClientTemplate.incr((type+account).getBytes());
//
//    }
//
//
//    public void delByKeys(String key) {
//        if (((null == key || StringUtils.isEmpty(key.trim()))))
//            throw new ParamterException();
//        redisClientTemplate.delByKeys(key);
//    }
//
//
//}
