package com.sntas.service.member.impl;

import com.sntas.common.consts.CacheKey;
import com.sntas.common.consts.Constant;
import com.sntas.common.enums.BaseErrorCodeEnum;
import com.sntas.common.exception.AuthorizedException;
import com.sntas.common.exception.NotFountException;
import com.sntas.common.exception.OperationException;
import com.sntas.common.exception.ParamterException;
import com.sntas.common.utils.MD5;
import com.sntas.common.utils.StringUtil;
import com.sntas.dto.member.MemberDTO;
import com.sntas.mybatis.bean.member.MemberEntity;
import com.sntas.mybatis.mapper.member.MemberEntityMapper;
import com.sntas.service.member.IMemberService;
import com.sntas.service.redis.RedisClientTemplate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * 用户操作
 */
@Service("memberService")
public class MemberServiceImpl implements IMemberService {
    private static final Logger logger = Logger.getLogger(MemberServiceImpl.class);

    @Autowired
    private MemberEntityMapper memberEntityMapper;


    @Autowired
    RedisClientTemplate redisClientTemplate;

//    @Resource
//    public Boolean single_user_login_flag;

    private String loginCacheKey_prefix = "sntas_login_";
    private String regCacheKey_prefix = "sntas_reg_";
    private String findPwdCacheKey_prefix = "sntas_find_pwd_";
    private String remindCacheKey_prefix = "sntas_remind_";
    private String regMailTemplateCode = "userregister";
    private String findPwdMailTemplateCode = "userfindpwd";
    private String remindPwdMailTemplateCode = "usersetremind";
    private String regSmsTemplateId = "108585";
    private String findPwdSmsTemplateId = "108586";
    private String remindSmsTemplateId = "111731";
    private Integer cacheTime = 10;//缓存时间（分钟）

    @Override
    public MemberDTO findOne(Integer id) {
        if (id == null || id.intValue() < 0) {
            throw new ParamterException();
        }
        try {
            MemberEntity memberEntity = memberEntityMapper.selectByPrimaryKey(id);
            if (null == memberEntity)
                throw new NotFountException(BaseErrorCodeEnum.USER_NOT_EXIST_EXCEPTION);
            return entity2dto(memberEntity);
        } catch (Exception e) {
            logger.error(e.getStackTrace()[0] + "错误" + e);
            throw new OperationException(BaseErrorCodeEnum.CONVERT_SERVER_EXCEPTION);
        }
    }


    @Override
    public MemberDTO login(String phone, String password, String captcha, String login_ip) {
        if (phone == null || phone.isEmpty())//验证手机号是否正确
            throw new ParamterException();
        if ((null == password || password.isEmpty()) && (captcha == null || captcha.isEmpty()))
            throw new ParamterException();
        MemberDTO dto = null;
        MemberEntity memberEntity = memberEntityMapper.selectMemberByPhone(phone);
        if (null == memberEntity)
            throw new NotFountException(BaseErrorCodeEnum.USER_NOT_EXIST_EXCEPTION);
        //密码为空 验证验证码是否正确
        if (password == null || password.isEmpty()) {
            String redisCaptcha = redisClientTemplate.get(this.getCacheKeyPrefix(BusinessType.LOGIN) + phone);
            if (redisCaptcha != null) {
                if (!redisCaptcha.equals(captcha)) {
                    throw new ParamterException(BaseErrorCodeEnum.USER_VALIDATE_EXCEPTION);
                }
            }
        }

        String psd = MD5.getMD5Str(password);
        //验证码为空 验证密码是否正确
        if ((captcha == null || captcha.isEmpty()) && !psd.equals(memberEntity.getMemberPasswd())) {
            throw new ParamterException(BaseErrorCodeEnum.USER_PASSWORD_EXCEPTION);
        }

        //登录信息存库
        memberEntity.setMemberLoginNum(memberEntity.getMemberLoginNum() + 1);
        memberEntity.setMemberOldLoginTime(new Timestamp(System.currentTimeMillis()));
        memberEntity.setMemberLoginTime(new Timestamp(System.currentTimeMillis()));
        memberEntity.setMemberLoginIp(login_ip);
        memberEntityMapper.updateByPrimaryKeySelective(memberEntity);
        dto = entity2dto(memberEntity);

        //生成token
        String token = createUUID("sntas_member");
        String memberId = CacheKey.SNTAS_MEMBER_.name() + dto.member_id;

//        //单用户登录
//        if (single_user_login_flag) {
//            MemberDTO preMemberDTO = (MemberDTO) redisClientTemplate.getEntity(memberId,MemberDTO.class);
//            if (preMemberDTO != null && preMemberDTO.token != null)
//                redisClientTemplate.del(preMemberDTO.token);
//        }

//        if (resourceType != null && resourceType.intValue() == 2) {//访问来源 wx
//            token = createUUID("iprp_member_fromwx_" + memberDTO.member_id);
//            memberDTO.token = token;
//            redisClientTemplate.set(token.getBytes(), memberId.getBytes());
//            redisClientTemplate.expire(token.getBytes(), Constant.TOKEN_CACHE_TIME);
//            redisClientTemplate.setEntity(memberId, Constant.CACHE_TIME, memberDTO);
//        } else {
        dto.token = token;
        //用户token验证、增加IP
        redisClientTemplate.hset(token.getBytes(), dto.login_ip.getBytes(), memberId.getBytes());
        redisClientTemplate.expire(token.getBytes(), Constant.TOKEN_CACHE_TIME);
        redisClientTemplate.setEntity(memberId, Constant.CACHE_TIME, dto);
//        }
        return dto;
    }

    public MemberDTO entity2dto(MemberEntity entity) {
        if (null == entity)
            return null;
        MemberDTO dto = new MemberDTO();
        dto.member_id = entity.getMemberId();            //用户id
        dto.member_sn = entity.getMemberSn();
//        dto.password = entity.getMemberPasswd();   //用户密码
        dto.email = entity.getMemberEmail();                    //邮件
        dto.phone = entity.getMemberPhone();                    //手机号
        dto.nickname = entity.getMemberNickname();                //昵称
        dto.truename = entity.getMemberTruename();                //真实名称
        dto.avatar = entity.getMemberAvatar();                //头像
        if (entity.getMemberSex() != null)
            dto.sex = Integer.valueOf(entity.getMemberSex() + "");            //性别
        if (entity.getMemberBirthday() != null)
            dto.birthday = entity.getMemberBirthday().getTime();                //生日
        dto.idcard = entity.getMemberIdentificationCard(); //企业法人身份证
        dto.member_industry = entity.getMemberIndustry();
        dto.login_num = entity.getMemberLoginNum();            //登录次数
        if (entity.getMemberLoginTime() != null)
            dto.login_time = entity.getMemberLoginTime().getTime();                //登录时间
//        if (entity.getMemberOldLoginTime() != null)
//            dto.old_login_time = entity.getMemberOldLoginTime().getTime();            //上次登录时间
        dto.login_ip = entity.getMemberLoginIp();                //登录ip
//        dto.old_login_ip = entity.getMemberOldLoginIp();            //上次登录ip
        dto.member_address = entity.getMemberAddress();
        return dto;
    }


    @Override
    public MemberDTO register(String phone, String password, String login_ip) {
        MemberDTO dto = new MemberDTO();
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setMemberPhone(phone);
        memberEntity.setMemberPasswd(MD5.getMD5Str(password));
//        memberEntity.setMemberSn(createUUID(""));  标识码生成规则 以后再说
        //登录信息存库
        memberEntity.setMemberLoginNum(memberEntity.getMemberLoginNum() + 1);
        memberEntity.setMemberOldLoginTime(new Timestamp(System.currentTimeMillis()));
        memberEntity.setMemberLoginTime(new Timestamp(System.currentTimeMillis()));
        memberEntity.setMemberLoginIp(login_ip);
        memberEntityMapper.insertSelective(memberEntity);
        dto = entity2dto(memberEntity);
        //生成token
        String token = createUUID("sntas_member");
        String memberId = CacheKey.SNTAS_MEMBER_.name() + dto.member_id;

//        //单用户登录
//        if (single_user_login_flag) {
//            MemberDTO preMemberDTO = (MemberDTO) redisClientTemplate.getEntity(memberId,MemberDTO.class);
//            if (preMemberDTO != null && preMemberDTO.token != null)
//                redisClientTemplate.del(preMemberDTO.token);
//        }

//        if (resourceType != null && resourceType.intValue() == 2) {//访问来源 wx
//            token = createUUID("iprp_member_fromwx_" + memberDTO.member_id);
//            memberDTO.token = token;
//            redisClientTemplate.set(token.getBytes(), memberId.getBytes());
//            redisClientTemplate.expire(token.getBytes(), Constant.TOKEN_CACHE_TIME);
//            redisClientTemplate.setEntity(memberId, Constant.CACHE_TIME, memberDTO);
//        } else {
        dto.token = token;
        //用户token验证、增加IP
        redisClientTemplate.hset(token.getBytes(), dto.login_ip.getBytes(), memberId.getBytes());
        redisClientTemplate.expire(token.getBytes(), Constant.TOKEN_CACHE_TIME);
        redisClientTemplate.setEntity(memberId, Constant.CACHE_TIME, dto);
//        }
        return dto;
    }

    /**
     * 生成UUID
     *
     * @param name to 模块名称
     * @return to 模块名-UUID(64位)
     */
    public String createUUID(String name) {
        String token = UUID.randomUUID().toString() + UUID.randomUUID().toString();
        token = token.replace("-", "").toLowerCase();
        token = name + "_" + token;
        return token;
    }


    @Override
    public MemberDTO verify(String token, String ip) {
        if (token.length() < 5) {//防刷新 token=null
            throw new AuthorizedException();
        }
        byte[] memberIdByte = redisClientTemplate.hget(token.getBytes(), ip.getBytes());

        String memberId = "";
        if (memberIdByte != null) {
            memberId = new String(memberIdByte);
        }
        if (StringUtil.isEmpty(memberId))
            throw new AuthorizedException();
        MemberDTO memberDTO = (MemberDTO) redisClientTemplate.getEntity(memberId, MemberDTO.class);
        if (memberDTO != null)
            return memberDTO;
        memberDTO = findOne(Integer.parseInt(memberId.replace(CacheKey.SNTAS_MEMBER_.name(), "")));
        redisClientTemplate.setEntity(memberId, Constant.CACHE_TIME, memberDTO);

        //是否延长存活时间
        redisClientTemplate.hset(token.getBytes(), ip.getBytes(), memberId.getBytes());
        redisClientTemplate.expire(token.getBytes(), Constant.TOKEN_CACHE_TIME);
        return memberDTO;
    }

    @Override
    public void logout(String token, String ip) {
        byte[] memberIdByte = redisClientTemplate.hget(token.getBytes(), ip.getBytes());
        if (null == memberIdByte) {
            return;
        }
        String member_id = new String(memberIdByte);
        if (null != member_id) {
            redisClientTemplate.del(token);
            redisClientTemplate.del(member_id);
        }
    }


    @Override
    public void sendCodeByRegister(String account) {
        sendCode(account, BusinessType.REGISTER);
    }

    @Override
    public void sendCodeBySetRemind(String account) {
        sendCode(account, BusinessType.REMIND);
    }

    @Override
    public void validateCodeBySetRemind(String account, String code) {
        ValidateCode(account, code, BusinessType.REMIND);
    }

    @Override
    public void validateCodeByRegister(String account, String code) {
        ValidateCode(account, code, BusinessType.REGISTER);
    }


    @Override
    public void sendCodeByFindPwd(String account) {
        sendCode(account, BusinessType.FINDPWD);
    }

    @Override
    public void validateCodeByFindPwd(String account, String code) {
        ValidateCode(account, code, BusinessType.FINDPWD);
    }

    @Override
    public void sendCodeByLogin(String account) {
        sendCode(account, BusinessType.LOGIN);
    }

    @Override
    public void validateCodeByLogin(String account, String code) {
        ValidateCode(account, code, BusinessType.LOGIN);
    }

    enum BusinessType {
        REGISTER,
        FINDPWD,
        REMIND,
        LOGIN
    }

    public void sendCode(String phone, BusinessType bizType) {
        MemberDTO memberDTO = null;
        MemberEntity memberEntity = memberEntityMapper.selectMemberByPhone(phone);
        if (bizType == BusinessType.FINDPWD || bizType == BusinessType.LOGIN) {
            if (null == memberEntity)
                throw new NotFountException(BaseErrorCodeEnum.USER_NOT_EXIST_EXCEPTION);
        } else if (bizType == BusinessType.REGISTER) {
            if (null != memberEntity)
                throw new ParamterException(BaseErrorCodeEnum.USER_REGISTER_EXCEPTION);
        }
//        String code = SmsCode.smsCapture(4);
        String code = "1234";
        redisClientTemplate.setex(this.getCacheKeyPrefix(bizType), Constant.CACHE_SMS_TIME, code);
        //TODO 短信通道发送短信
    }

    private void ValidateCode(String phone, String code, BusinessType bizType) {
        if (code == null)
            throw new ParamterException();
        String cacheCode = (String) redisClientTemplate.get(this.getCacheKeyPrefix(bizType) + phone);
        if (cacheCode == null)
            throw new ParamterException(BaseErrorCodeEnum.USER_VALIDATEOVERDUE_EXTST_ERROR_MSG);
        if (!cacheCode.equals(code))
            throw new ParamterException(BaseErrorCodeEnum.USER_VALIDATE_EXCEPTION);
//        redisClientTemplate.delete(this.getCacheKeyPrefix(bizType)+phone);
    }

    private String getCacheKeyPrefix(BusinessType bizType) {
        if (bizType == BusinessType.REGISTER)
            return this.regCacheKey_prefix;
        else if (bizType == BusinessType.FINDPWD)
            return this.findPwdCacheKey_prefix;
        else if (bizType == BusinessType.REMIND)
            return this.remindCacheKey_prefix;
        if (bizType == BusinessType.LOGIN)
            return this.loginCacheKey_prefix;
        else
            return null;
    }


}
