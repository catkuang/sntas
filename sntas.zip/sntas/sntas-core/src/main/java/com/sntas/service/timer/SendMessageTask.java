package com.sntas.service.timer;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * 定时器  预约推送提醒
 */
@Component
public class SendMessageTask {
    private static final Logger logger = Logger.getLogger(SendMessageTask.class);

//    @Autowired
//    private MessageService messageService;
//
//    @Autowired
//    private MemberService memberService;
//
//    @Autowired
//    private SmsService smsService;

//    @Autowired
//    private StewardTradeMarkInfoMapper stewardTradeMarkInfoMapper;

//    @Autowired
//    private MemberService memberService;
    /**
     * 检查续费商标发送消息给用户
     */
//    @Scheduled(cron = "0 0 2 * * ?")
//    public void sendTrademarkMessageToUser() {
//        //检查根据userid分组 查询有哪些商标 等待续费
//        List<Integer> userIds = stewardTradeMarkInfoMapper.queryTradeMarkInfoTimer();
//        if (userIds != null && userIds.size() > 0) {
//            for (Integer userId : userIds) {
//                if (userId != null) {
////                    //发送系统消息
////                    MessageDTO messageDTO = new MessageDTO();
////                    messageDTO.platform = 4;
////                    messageDTO.platform_id = 0;
////                    messageDTO.bs_id = 0;
////                    messageDTO.platform_user_id = userId;
////                    messageDTO.resource_type = 0;
////                    messageDTO.resource_id = 0;
////                    messageDTO.content = "您好，您有商标即将到期，请尽快续费！";
////                    messageService.add(messageDTO);
//
//                    //TODO 发送邮件 短信
//                }
//            }
//        }
//    }
//    /*select a.member_id,count(a.member_id ),min(b.private_date) FROM steward_relation a INNER JOIN steward_trademarkInfo b on a.trademark_patent_id=b.id where a.type=0 and a.state=1
//    and   '2026-07-20'  > DATE_SUB(b.private_date, INTERVAL -114 MONTH) AND '2026-07-20'< DATE_SUB(b.private_date, INTERVAL -126 MONTH) and a.member_id=11 GROUP BY a.member_id ;*/
//    @Scheduled(cron = "0 0 22 * * ?")
////    @Scheduled(cron = "0/30 * * * * ?")
//    public void selectRenewTime() {
////        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
////        Integer memberId=0;
//
//        SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
//        Date beginDate = new Date();
//        String nowdate=dft.format(beginDate);
//        //查询续费商标
//        List<Map<String,Object>> list = stewardTradeMarkInfoMapper.selectRenew(nowdate);
//        //计算明天9点用于短信定时发送
//        Calendar date = Calendar.getInstance();
//        date.setTime(beginDate);
//        date.set(Calendar.DATE, date.get(Calendar.DATE) + 1);
//        Date endDate = null;
//        try {
//            endDate = dft.parse(dft.format(date.getTime()));
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        Long sendTime = Long.parseLong(new SimpleDateFormat("yyyyMMdd").format(endDate)+"090000");
//
//
//        for(int i=0;i<list.size();i++){
//            Map<String,Object> map=list.get(i);
//
//            Date update_time= (Date) map.get("update_time");
//            String updateTime=dft.format(update_time);
//            String renewTime= (String) map.get("renewTime");
//            //如果是当天的托管商标或60天续费的商标
//            if(updateTime.equals(nowdate)||zeroRenewTime(renewTime)==0){
//                Integer memberId= (Integer) map.get("member_id");
//                MemberDTO memberDTO= memberService.findOne(memberId);
//                Long renewNumber= (Long)map.get("renewNumber");
//                SmsDTO smsDTO=new SmsDTO();
//                smsDTO.template_id="renew_remind";
//                smsDTO.senders = new ArrayList<SmsSender>();
//                SmsSender smsSender = new SmsSender();
//                smsSender.mobile = memberDTO.phone;
//                smsSender.template_params = new ArrayList<String>();
////                smsSender.template_params.add(memberDTO.truename);
//                smsSender.template_params.add(renewNumber.toString());
//                smsDTO.sendTime = sendTime;
//                smsDTO.senders.add(smsSender);
////                System.out.println(smsDTO.senders.get(0).mobile);
//                smsService.sendAsync(smsDTO);
//            }
//
//        }
////        System.out.println(smsDTO.senders.get(0).mobile);
////        smsService.sendAsync(smsDTO);
//
//        }
//
//        public Long zeroRenewTime(String dstr){
//            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");//小写的mm表示的是分钟
////            String dstr="2017-11-20";
//            Date date= null;
//            try {
//                date = sdf.parse(dstr);
//            } catch (ParseException e) {
//                e.printStackTrace();
//            }
//            Long a=date.getTime()/1000/3600/24;
//            Long b=new Date().getTime()/1000/3600/24;
//            Long c=Math.abs(a-b);
//            long aa=999;
//            if(c<180){
//                aa=c%60;
//            }
//            return aa;
//        }
//
//



}
