package com.sntas.app.controller;


import com.sntas.common.exception.AuthorizedException;
import com.sntas.common.exception.ParamterException;
import com.sntas.core.base.Page;
import com.sntas.common.bean.StewardUser;
import com.sntas.common.consts.ErrorCodeConst;
import com.sntas.common.enums.BaseErrorCodeEnum;
import com.sntas.common.exception.OperationException;
import com.sntas.common.utils.HtmlUtil;
import com.sntas.common.utils.SessionUtils;
import com.sntas.core.base.ResultBean;
import com.github.pagehelper.PageHelper;
import com.sntas.dto.member.MemberDTO;
import com.sntas.service.member.IMemberService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseController {
    public final static Integer PAGE_SIZE = 20;
    public final static Integer FIRST_PAGE = 1;
    @Resource
    public IMemberService memberService;

    /**
     * 如果是子账户登录 赋值主账户id
     *
     * @param request
     * @return
     */
    public Integer getUserId(HttpServletRequest request) {
        StewardUser user = SessionUtils.getUser(request);
        if (user != null) {
            if (user.getParentId() == null || user.getParentId() == 0) {
                return user.getUserId();
            } else {
                return user.getParentId();
            }
        } else {
            throw new OperationException(BaseErrorCodeEnum.USER_NOTLOGIN_EXCEPTION);
        }
    }

    /**
     * 提示成功信息
     *
     * @param code
     */
    public void sendSuccessMessageData(HttpServletResponse response, String code, Map<String, Object> map) {
        map.put("code", code);
        HtmlUtil.IEwriter2Json(response, map);
    }

    /**
     * 提示失败信息
     *
     * @param code
     */
    public void sendFailureMessage(HttpServletResponse response, String code) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("code", code);
        HtmlUtil.IEwriter2Json(response, result);
    }

    /**
     * 提示失败信息
     *
     * @param code
     */
    public void sendFailure(HttpServletResponse response, String code, Map<String, Object> map) {
        map.put("code", code);
        HtmlUtil.IEwriter2Json(response, map);
    }

    /**
     * @param response
     * @param result
     * @return void
     * @throws
     * @Title: sendMessage
     * @Description: 发送消息和信息，所有消息 和/或 信息发送都可以适用
     */
    public void sendMessage(HttpServletResponse response, Object result) {
        HtmlUtil.writerJson(response, result);
    }


    /**
     * 提示失败信息
     *
     * @param message
     */
    public void sendFailureMessageJson(HttpServletResponse response, String message) {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("code", "fail");
        result.put("msg", message);
        HtmlUtil.writerJson(response, result);
    }


    public void startPage(Integer page, Integer pageSize) {
        if (page == null) {
            page = FIRST_PAGE;
        }
        if (pageSize == null) {
            pageSize = PAGE_SIZE;
        }
        PageHelper.startPage(page, pageSize);
    }

    public <T> ResultBean<T> createdResultBean(String code, T t, String message) {
        ResultBean<T> resultBean = new ResultBean<T>();
        resultBean.setCode(code);
        resultBean.setData(t);
        resultBean.setDesc(message);
        return resultBean;
    }

    public <T> ResultBean<Map<String, Object>> createdResultBean(Map<String, Object> map) {
        ResultBean<Map<String, Object>> resultBean = new ResultBean<Map<String, Object>>();
        resultBean.setCode(ErrorCodeConst.RESULT_SUCCESS);
        resultBean.setData(map);
        return resultBean;
    }

    public <T> ResultBean<T> createdResultBean(T t, Class<T> clazz) {
        ResultBean<T> resultBean = new ResultBean<T>();
        resultBean.setCode(ErrorCodeConst.RESULT_SUCCESS);
        resultBean.setData(t);
        return resultBean;
    }

    public <T> ResultBean<T> createdResultBean(Class<T> clazz) {
        ResultBean<T> resultBean = new ResultBean<T>();
        resultBean.setCode(ErrorCodeConst.RESULT_SUCCESS);
        return resultBean;
    }

    public <T> ResultBean<List<T>> createdResultBean(List<T> t, Class<T> clazz) {
        if (t == null) {
            t = new ArrayList<T>();
        }
        ResultBean<List<T>> resultBean = new ResultBean<List<T>>();
        resultBean.setCode(ErrorCodeConst.RESULT_SUCCESS);
        resultBean.setData(t);
        return resultBean;
    }

    public <T> ResultBean<Page<T>> createdPageResultBean(List<T> t, Class<T> clazz) {
        if (t == null) {
            t = new ArrayList<T>();
        }
        Page<T> page = new Page<T>(t);
        ResultBean<Page<T>> resultBean = new ResultBean<Page<T>>();
        resultBean.setCode(ErrorCodeConst.RESULT_SUCCESS);
        resultBean.setData(page);
        return resultBean;
    }



    /**
     * 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址;
     *
     * @param request
     * @return
     * @throws IOException
     */
    public String getIpAddress(HttpServletRequest request){
        // 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址
        String ip = request.getHeader("X-Real-IP");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("X-Forwarded-For");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("HTTP_CLIENT_IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("HTTP_X_FORWARDED_FOR");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }
        } else {
            if (ip.length() > 15) {
                String[] ips = ip.split(",");
                for (int index = 0; index < ips.length; index++) {
                    String strIp = (String) ips[ips.length-1];
                    if (!("unknown".equalsIgnoreCase(strIp))) {
                        ip = strIp;
                        break;
                    }
                }
            }
        }
        return ip;
    }




    /**
     * 根据token获取会员信息
     * @param token
     * @return
     */
    public MemberDTO getUserByToken(String token, String ip){
        MemberDTO memberDTO;
        try {
            memberDTO = memberService.verify(token,ip);
            if(null == memberDTO.member_id)
                throw new ParamterException();
        }catch (AuthorizedException ex) {
            throw new AuthorizedException();
        }
        return memberDTO;
    }



}
