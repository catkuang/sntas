package com.sntas.app.controller.drumbeating;

import com.sntas.app.controller.BaseController;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 宣传视频
 * Created by kjh on 2017/9/26.
 */
@Controller
@RequestMapping("/drumbeatingVideo")
public class DrumbeatingVideoController extends BaseController {

    private static final Logger logger = Logger.getLogger(DrumbeatingVideoController.class);

//    /**
//     * 获取宣传视频列表
//     *
//     * @return
//     */
//    @ResponseBody
//    @RequestMapping(value = "/getDrumbeatingVideoList", method = {RequestMethod.POST, RequestMethod.GET})
//    public ResultBean<Page<StewardPatentInfo>> getDrumbeatingVideoList(
//            @RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
//            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
//            HttpServletRequest request) {
//        startPage(pageNo, pageSize);
//        Integer userId = getUserId(request);
//        List<StewardPatentInfo> StewardPatentInfoList = null;
//        return createdPageResultBean(StewardPatentInfoList, StewardPatentInfo.class);
//    }





//    /**
//     * 获取宣传视频列表
//     *
//     * @return
//     */
//    @ResponseBody
//    @RequestMapping(value = "/getDrumbeatingVideoDetail", method = {RequestMethod.POST, RequestMethod.GET})
//    public ResultBean<StewardPatentInfo> getDrumbeatingVideoDetail(
//            @RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
//            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
//            HttpServletRequest request) {
//        startPage(pageNo, pageSize);
//        Integer userId = getUserId(request);
//        StewardPatentInfo StewardPatentInfoList = null;
//        return createdResultBean(StewardPatentInfoList, StewardPatentInfo.class);
//    }






}
