package com.sntas.app.controller.file;

import com.sntas.app.controller.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by sgj on 2017-03-16.
 */
@Controller
@RequestMapping("/file")
public class FileController extends BaseController {
//    @Resource
//    public FileService fileService;
//
//    @RequestMapping(value = "aaa", method = RequestMethod.POST)
//    public void aaa(String aaa,HttpServletRequest httpRequest,HttpServletResponse response){
//sendMessage(response,"asdads");
//    }

//    @RequestMapping(value = "uploadData")
//    public ResponseEntity<?> upload(@RequestParam("fileData") MultipartFile fileData,
//            HttpServletRequest httpRequest,HttpServletResponse response){
//        JsonObject jsonObj = new JsonObject();
//        if (fileData != null) {
//            try {
//                //获取图片大小和尺寸
////                BufferedImage sourceImg = ImageIO.read(inStream);
////                System.out.println(String.format("%d",data.getSize()/1024));
////                System.out.println(sourceImg.getWidth());
////                System.out.println(sourceImg.getHeight());
//
//                FileDTO fileDTO = new FileDTO();
//                fileDTO.file_name = fileData.getOriginalFilename();
//
////                图片信息
//                InputStream inStream = fileData.getInputStream();
//                ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
//                byte[] buff = new byte[100]; //buff用于存放循环读取的临时数据
//                int rc = 0;
//                while ((rc = inStream.read(buff, 0, 100)) > 0) {
//                    swapStream.write(buff, 0, rc);
//                }
//
//                fileDTO.content = swapStream.toByteArray();
//                fileDTO = fileService.add(fileDTO);
//                jsonObj.addProperty("url", fileDTO.url);
//
//            } catch (Exception e) {
//                e.printStackTrace();
//                jsonObj.addProperty("status", "500");
//                jsonObj.addProperty("msg", e.toString());
//            }
//        } else {
//            jsonObj.addProperty("status", "601");
//            jsonObj.addProperty("msg", "upload file not found");
//        }
//
//        return new ResponseEntity<String>(jsonObj.toString(), HttpStatus.OK);
//    }
}
