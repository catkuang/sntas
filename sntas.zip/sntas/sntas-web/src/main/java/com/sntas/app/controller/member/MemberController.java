package com.sntas.app.controller.member;

import com.sntas.app.controller.BaseController;
import com.sntas.common.exception.ParamterException;
import com.sntas.core.base.ResultBean;
import com.sntas.dto.member.MemberDTO;
import com.sntas.service.member.IMemberService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * 宣传视频
 * Created by kjh on 2017/9/26.
 */
@Controller
@RequestMapping("/member")
public class MemberController extends BaseController {
    private static final Logger logger = Logger.getLogger(MemberController.class);
//    @Resource
//    public MemberCacheService memberCacheService;

    @Resource
    public IMemberService memberService;

    /**
     * 会员登录
     *
     * @param phone    手机号
     * @param password 密码(验证码登录的时候可不填)
     * @param captcha  验证码登录（密码登录的时候可不填）
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "login", method = {RequestMethod.POST, RequestMethod.GET})
    public ResultBean<MemberDTO> login(
            @RequestParam(value = "phone") String phone,
            @RequestParam(value = "password", required = false) String password,
            @RequestParam(value = "captcha", required = false) String captcha,
            HttpServletRequest request) {
        if (null == phone)
            throw new ParamterException();
        if (null == password && captcha == null)
            throw new ParamterException();
        //获取IP
        String ip = getIpAddress(request);
        MemberDTO memberDTO = memberService.login(phone, password, captcha, ip);
        return createdResultBean(memberDTO, MemberDTO.class);
    }


//    /**
//     * 获取宣传视频列表
//     *
//     * @return
//     */
//    @ResponseBody
//    @RequestMapping(value = "/getMemberDetail", method = {RequestMethod.POST, RequestMethod.GET})
//    public ResultBean<MemberDTO> getMemberDetail(
//            @RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
//            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
//            HttpServletRequest request) {
//        startPage(pageNo, pageSize);
//        Integer userId = getUserId(request);
//        List<StewardPatentInfo> StewardPatentInfoList = null;
//        return createdPageResultBean(StewardPatentInfoList, StewardPatentInfo.class);
//    }


    /**
     * 会员登录获取验证码
     *
     * @param request
     * @param response
     */
    @ResponseBody
    @RequestMapping(value = "/login/sendcode", method = {RequestMethod.POST, RequestMethod.GET})
    public Map<String, String> loginSendcode(
            HttpServletRequest request, HttpServletResponse response,
            @RequestParam(value = "phone") String phone) {
        if (null == phone)
            throw new ParamterException();
        memberService.sendCodeByLogin(phone);
        Map<String, String> map = new HashMap<String, String>();
        map.put("code", "200");
        map.put("data", "验证码发送成功");
        return map;
    }

    /**
     * 会员注册验证验证码
     *
     * @param request
     * @param response
     * @param phone
     */
    @ResponseBody
    @RequestMapping(value = "/register/sendcode", method = {RequestMethod.POST, RequestMethod.GET})
    public void registerSendcode(
            HttpServletRequest request, HttpServletResponse response,
            @RequestParam(value = "phone") String phone) {
        if (null == phone)
            throw new ParamterException();
        memberService.sendCodeByRegister(phone);
    }

//    /**
//     * 会员注册验证验证码
//     *
//     * @param request
//     * @param response
//     * @param code
//     */
//    @ResponseBody
//    @RequestMapping(value = "/register/verify", method = RequestMethod.POST)
//    public void registerValidate(
//            HttpServletRequest request, HttpServletResponse response,
//            @RequestParam(value = "phone") String phone,
//            @RequestParam(value = "code") String code) {
//        if (null == phone || null == code)
//            throw new ParamterException();
//        memberService.validateCodeByRegister(phone, code);
//    }


}
