<template>
	<div>
        <el-select v-model="pId" @change="chgProvince(pId);" placeholder="请选择所在省份">
            <el-option v-for="item,$index in provinces" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="cId" @change="chgCity(cId);" placeholder="请选择所在城市">
            <el-option v-for="item,$index in citys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="ctId" placeholder="请选择所在区县"><!--@change="chgCounty(ctId);"-->
            <el-option v-for="item,$index in countys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
		<!--<el-select v-model="p" placeholder="请选择省份" @change="chg(p);">
    		<el-option v-for="item,$index in addressData" :label="item" v-bind:value="item.area_id">{{item.name}}</el-option>
  		</el-select>
  		<el-select v-model="city" placeholder="请选择城市">
    		<el-option v-for="item in citys" :label="item" :value="item"></el-option>
  		</el-select>
  		<el-select v-model="county" placeholder="请选择区县">
    		<el-option v-for="item in countys" :label="item" :value="item"></el-option>
  		</el-select>
  		<el-input class="detail" v-model="addrDetail" placeholder="请输入详细地址"></el-input>-->
    </div>
</template>

<script>
import axios from 'axios'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getLocation } from '../../api/api'
export default {
	name: 'AreaThreeLevelLinkage',
 	props: ['province','city','county'],
 	data() {
 		return {
            pId:'',
            cId:'',
            ctId:'',
 			provinces:[],
            citys:[],
            countys:[]
 		}
 	},
 	mounted(){
      NProgress.start();
      getLocation().then((res) => {
        console.log(res);
        NProgress.done();   
        var elements = res.elements;
        var array_1 = [];
        for(let i=0; i < elements.length; i++){
            if(elements[i].deep ==1){
                array_1.push(elements[i]);
            }
        }
        this.provinces = array_1;
  
      }); 
        /*this.addressData=[
            {
                pName:'湖南',
                citys:[
                    {
                        cName:'长沙',
                        countys:[
                            {
                                cyName:'区1'
                            },
                            {
                                cyName:'区2'
                            }
                        ]
                    },                   
                ]
            },
            {
                pName:'浙江',
                citys:[
                    {
                        cName:'杭州',
                        countys:[
                            {
                                cyName:'区3'
                            },
                            {
                                cyName:'区4'
                            }
                        ]
                    },                   
                ]
            }
        ]*/
    },
 	methods: {
        chgProvince(id){
            this.cId = '';
            this.ctId= '';
            let para = { pId:id };
            getLocation(para).then((res) => { this.citys = res.elements; });
        },
        chgCity(id){
            this.ctId= '';
            let para = { pId:id };
            getLocation(para).then((res) => { this.countys = res.elements; });
        },
        /*chgCounty(ctId){
            let para = { pId:ctId };
            getLocation(para).then((res) => { this.countys = res.elements; });
        }*/
 	},
 	computed:{
        /*provinces:function(){
            if(!this.addressData)return

            var c=[]
            for(var i=0 ;i <this.addressData.length; i++){
                c.push(this.addressData[i].pName)
            }
            return c
        },
        p_citys:function(){
            if(!this.addressData)return

            var c=[]
            for(var i=0 ;i <this.addressData.length; i++){
                c = this.addressData[i].citys
            }
            return c
        },
        citys:function(){
            if(!this.addressData || !this.province)return 

            var c=[]
            for(var i=0;i <this.p_citys.length; i++){
                c.push(this.p_citys[i].cName)
            }
            return c
        },
        c_countys:function(){
            if(!this.addressData)return

            var c=[]
            for(var i=0; i <this.p_citys.length; i++){
                c = this.p_citys[i].countys
            }
            return c
        },
        countys:function(){
            if(!this.addressData || !this.province || !this.city)return

            var c=[]
            for(var i=0 ;i <this.c_countys.length; i++){
                c.push(this.c_countys[i].cyName)
            }

            return c
        }*/
 		/*provinces:function(){
            if(!this.addressData)return

            var c=[]
            for(var key in this.addressData){
                c.push(key)
            }

            return c
        },
        citys:function(){
            if(!this.addressData 
                || !this.province)
                return 

            var c=[]
            for(var key in this.addressData[this.province]){
                c.push(key)
            }

            return c
        },
        countys:function(){
            if(!this.addressData
                ||!this.city)
                return

            var c=[]
            for(var key in this.addressData[this.province][this.city]){
                c.push(key)
            }

            return c
        }*/
 	},
    watch:{
        province:function(val,oldval){
            if(val!==oldval){
                this.city=''
            }
        },
        city:function(val,oldval){
            if(val!==oldval){
                this.county=''
            }
        }
    //},
 	}
}
</script>

<style scoped>
	ul,li{
 		list-style-type: none;
	}
	.detail{
		padding:10px 0px;
		display:block;
		width:438px;
	}
</style>
