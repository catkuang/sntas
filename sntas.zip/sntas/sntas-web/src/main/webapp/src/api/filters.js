var SIGN_REGEXP = /([yMdhsm])(\1*)/g;
var DEFAULT_PATTERN = 'yyyy-MM-dd';
function padding(s, len) {
    var len = len - (s + '').length;
    for (var i = 0; i < len; i++) { s = '0' + s; }
    return s;
};

export default {
    getQueryStringByName: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        var context = "";
        if (r != null)
            context = r[2];
        reg = null;
        r = null;
        return context == null || context == "" || context == "undefined" ? "" : context;
    },
    formatDate: {
        //日期转yyyy-mm-dd格式
        format: function (date, pattern) {
            pattern = pattern || DEFAULT_PATTERN;
            return pattern.replace(SIGN_REGEXP, function ($0) {
                switch ($0.charAt(0)) {
                    case 'y': return padding(date.getFullYear(), $0.length);
                    case 'M': return padding(date.getMonth() + 1, $0.length);
                    case 'd': return padding(date.getDate(), $0.length);
                    case 'w': return date.getDay() + 1;
                    case 'h': return padding(date.getHours(), $0.length);
                    case 'm': return padding(date.getMinutes(), $0.length);
                    case 's': return padding(date.getSeconds(), $0.length);
                }
            });
        },
        parse: function (dateString, pattern) {
            var matchs1 = pattern.match(SIGN_REGEXP);
            var matchs2 = dateString.match(/(\d)+/g);
            if (matchs1.length == matchs2.length) {
                var _date = new Date(1970, 0, 1);
                for (var i = 0; i < matchs1.length; i++) {
                    var _int = parseInt(matchs2[i]);
                    var sign = matchs1[i];
                    switch (sign.charAt(0)) {
                        case 'y': _date.setFullYear(_int); break;
                        case 'M': _date.setMonth(_int - 1); break;
                        case 'd': _date.setDate(_int); break;
                        case 'h': _date.setHours(_int); break;
                        case 'm': _date.setMinutes(_int); break;
                        case 's': _date.setSeconds(_int); break;
                    }
                }
                return _date;
            }
            return null;
        },
        //日期转时间戳
        timeStamp:function(date){
            var timestamp = Date.parse(new Date(date));
            timestamp = timestamp / 1000;
            return timestamp
        },
        //日期格式转换
        dateFormat: function (input,type) {
            if(input == null || input=='' || typeof(input) == "undefined"){
                return "";
            }
            var _date = new Date(input);
            var year = _date.getFullYear();
            var month = _date.getMonth() + 1 > 9 ? _date.getMonth() + 1 : "0" + (_date.getMonth() + 1);
            var day = _date.getDate() > 9 ? _date.getDate() : "0" + _date.getDate();
            var hour = _date.getHours() > 9 ? _date.getHours() : "0" + _date.getHours();
            var minutes = _date.getMinutes() > 9 ? _date.getMinutes() : "0" + _date.getMinutes();
            var seconds = _date.getSeconds() > 9 ? _date.getSeconds() : "0" + _date.getSeconds();
            if(type == "date"){
                return year + "-" + month + "-" + day;
            } else if(type == "time") {
                return hour + ":" + minutes + ":" + seconds;
            } else {
                return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
            }
            return "";
      }
    },
    formatPatent:{
        //专利类型转换
        format: function (input) {
            if(input == null || input=='' || typeof(input) == "undefined"){
                return "";
            }else{
                switch (input){
                    case 1:
                        return "发明专利";
                    case 2:
                        return "实用新型专利";
                    case 3:
                        return "外观设计专利";
                }
            }
        }
    },
    formatIPRClassify:{
        //知产分类转换
        format: function (input) {
            switch (input){
                case 0:
                    return "商标";
                case 1:
                    return "专利";
            }
        }
    },
    formatStatus:{
        //会员状态转换
        format: function (input) {
            switch (input){
                case false:
                    return 0;
                case true:
                    return 1;
            }
        }
    }

};
