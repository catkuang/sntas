<template>
	<div class="ft">
	   <div class="footer">
            <div class="content">
    		    <div class="contUs">
                    <span>关于我们</span> 
                    <span>网站地图</span> 
                    <span>联系我们</span>  
                    <div class="addr">地址:杭州市 江干区 九环路 9号 浙江清华长三角研究院杭州分院 3楼 303室</div>    
                </div>
                <div class="contMthd">
                    <div class="mthdItem">微信:sebe2015</div>
                    <div class="mthdItem">传真:0571-28253780</div>
                    <div class="mthdItem">邮箱:sebe@cnsebe.com</div>
                </div>
                <div class="code">
                    <img src="../assets/images/code.png">
                </div>
                <div class="tel">
                    <img src="../assets/images/tel.png">
                    <span class="telNum">0571-28253786</span>
                    <div class="time">(服务时间:周一~周五8:30~17.30)</div>
                </div>
                <div class="link">
                    <span>友情链接：</span>
                    <span>阿里巴巴知识产权保护平台</span>
                    <span>商标局</span>
                    <span>版权局</span>
                    <span>阿里巴巴</span>
                    <span>淘宝网</span>
                    <span>阿里云</span>
                    <span>京东商城</span>
                    <span>网易云</span>
                    <span>专利局</span>
                </div>
            </div>
	   </div>
	   <div class="footer_bottom">
            <div class="commWith">
        	   <span>拾贝知识产权服务有限公司&nbsp;&nbsp;</span>
        	   <span>www.cnsebe.com&nbsp;&nbsp;</span>
        	   <i></i>
        	   <span>浙公网安备&nbsp;302022102110120号</span>
    	   </div>
	   </div>
	</div>
</template>

<script>
export default {

}
</script>


<style scoped lang="scss">
    .ft{
        position: relative;
    }
	.footer {
        margin: 0px auto;
        width: 100%;
    	background: #fff;
    	height: 236px;
        .content{
            margin: 0px auto;
            width: 1200px;
            height: 160px;
            .contUs{
                float: left;
                margin-top: 50px;
                text-align: center;
                span{
                    padding:0px 65px;
                    font-size: 16px;
                    color: #77747f;
                }
                .addr{
                    font-size: 14px;
                    color: #afafaf;
                    padding-top:48px;
                }
            }
            .contMthd{
                float: left;
                margin-left: 20px;
                margin-top: 50px;
                font-size: 14px;
                color: #afafaf;
                .mthdItem{
                    padding:6px 0px
                }
            }
            .code{
                float: left;
                margin-left: 60px;
                margin-top: 42px;
                img{
                    width: 70%;
                }
            }
            .tel{
                float: left;
                margin-left: 20px;
                margin-top: 65px;
                img{
                    margin-bottom: 10px;
                }
                .telNum{
                    color: #fd6f2b;
                    font-size: 26px;
                }
                .time{
                    font-size: 14px;
                    color: #afafaf;
                }
            }
            .link{
                width: 1200px;
                margin: 0px auto;
                text-align: left;
                clear: both;
                margin-left: 65px;
                font-size: 14px;
                color: #afafaf;
                padding-top: 5px;
                border-top: 1px dashed #afafaf;
            }
        }
	}
	.footer_bottom {
    	background: #01172F;
    	height: 40px;
    	line-height: 40px;
        margin: 0px auto;
        width: 100%;
	}
    .commWith {
        width: 1280px;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        color: #fff;
    }
    /* @media screen and (max-width: 2880px) {
        .commWith {
            width: 1280px;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
    }
    @media screen and (min-width: 960px) and (max-width:1680px) {
        .commWith {
            width: 1024px;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
    } */
	.footer_bottom >div i {
    	display: inline-block;
    	width: 14px;
    	height: 16px;
    	margin-right: 6px;
    	background: url(../assets/images/icon-police.png) 0 0 no-repeat;
    	vertical-align: middle;
    	margin-top: -4px;
	}
    .link{
        text-align: left;
    }
</style>
