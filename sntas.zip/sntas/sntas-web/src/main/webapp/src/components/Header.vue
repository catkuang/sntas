<template>
	<div>
		<div id="topPic">
    		<div class="topBar">
        		<div class="top commWith">
            		<div class="top_left fl">
                		<a class="fl top_img">
                    		<img src="http://192.168.1.189:8070/portalsite-cnsebe/images/twowei.png" alt="" v-on:mouseenter="showCode" v-on:mouseleave="hodeCode">
                    		<i v-if="codeShow"></i>
                		</a>
                		<a class="gzgg-icon" style="text-decoration: none;">戳这里，关注拾贝</a>
            		</div>
            		<div class="fl overflowhidden">
                		<div class="fl">
                    		<img src="http://192.168.1.189:8070/portalsite-cnsebe/images/phone.png" alt="">
                		</div>
                		<span style="color: #ffffff">400-04204625</span>
            		</div>
            		<div class="top_right fr">
                		<div class="top_right_btn fl" id="LoginBtn" style="display: block;">
                    		<!--<a href="#" id="lnkLogin" class="login_btn ff">购物车（<strong class="shop_color">0</strong>）件</a><span></span>-->
                    		<a href="http://user.cnsebe.com/iprp_portal/user/www/index.html#/access/login?return_url=http://steward.cnsebe.com/cnsebe-steward-web/dist/index.html" class="zhuce_btn ff" target="_blank" style="text-decoration: none;">立即登录</a><span></span>
                    		<a href="http://user.cnsebe.com/iprp/#/access/register" class="zhuce_btn ff" target="_blank" style="text-decoration: none;">免费注册</a><span></span>
                		</div>
                	<div class="top_right_btn fl" id="UserInfo" style="display: none;">
                    	<a href="http://user.cnsebe.com/iprp/#/home/order" class="zhuce_btn ff" target="_blank" style="text-decoration: none;">我的订单</a><span></span>
                	</div>
                	<div class="top_right_btn fl">
                    	<a href="#" target="_blank" class="zhuce_btn ff" style="text-decoration: none;">客服中心</a>
                	</div>
            	</div>
            <div class="clear"></div>
        </div>
        <!--<div class="title">
    		<div class="commwidth titletop overflowhidden">
        		<div class="fl">
            		<img src="../assets/images/logo1.png" alt="">
        		</div>  
    		</div>
		</div>-->
    </div>
</div>
	</div>
	<!--<div class="login flr">
		<template v-if="!username">
			<button class="btn_dl mr10" @click="header.jumpLogin()">登录</button>
			<button class="btn_zc mr10" @click="header.jumpRegister()">注册</button>
		</template>
		<template v-else>
			<span class="helloKitty ng-binding">{{username}}</span>
			<span class="curp" style="color: #FFFFFF" @click="logout">退出</span>
		</template>
	</div>-->
</template>

<script>
export default {
  props:[],
  data() {
    return {
    	username:'',
    	root: 'http://www.cnsebe.com/',
      	isLeave: true,
      	codeShow:false,
    }
  },
  methods: {
  	showCode(){
  		this.codeShow = true;
  	},
  	hodeCode(){
  		this.codeShow = false;
  	},
  	logout(){
  		location.href = this.root+ "iprp_portal/api/logout?access_token=" + this.$cookie.get('user_token')
  	}
  }
}
</script>

<style>
	html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, menu, nav, output, ruby, section, summary, time, mark, audio, video {
    	margin: 0;
    	padding: 0;
    	border: 0;
    	font-size: 100%;
    	font: inherit;
    	vertical-align: baseline;
    	text-decoration: none;
	}
	body p, body span {
    	font-size: 14px;
	}
	div {
    	margin: 0;
    	padding: 0;
    	border: 0;
    	font-size: 100%;
    	font: inherit;
    	vertical-align: baseline;
    	text-decoration: none;
	}
	img {
    	vertical-align: middle;
    	border: 0;
	}
	.topBar, .topPic {
    	height: 32px;
    	width: 100%;
    	background: #333333;
    	line-height: 32px;
	}
	.commWith {
    	width: 100%;
    	margin-left: auto;
    	margin-right: auto;
	}
	.topBar .top_left, .topBarFix .top_left {
    	line-height: 16px;
    	padding: 6px 10px;
    	height: 16px;
	}
	.top_left {
    	position: relative;
    	text-align: center;
    	margin-right: 30px;
	}
	.fl {
    	float: left;
	}
	.top_left a {
    	font-size: 12px;
    	color: #ffffff;
    	font-family: "microsoft yahei","微软雅黑";
    	display: inline-block;
    	line-height: 12px;
	}
	a {
    	background-color: transparent;
    	outline: none;
    	text-decoration: none;
    	color: #333333;
	}
	.top_img {
    	margin: -2px 0px 0 0;
	}
	.top_img >i {
    	width: 137px;
    	height: 137px;
    	position: absolute;
    	background: url(../assets/images/code.png) left top no-repeat;
    	z-index: 100;
	}
	.overflowhidden {
    	height: auto;
    	overflow: hidden;
    	margin: auto;
	}
	.top div:nth-child(2) >div >img {
    	margin-bottom: 4px;
    	margin-right: 5px;
	}
	.top_right {
    	font-size: 12px;
    	padding: 6px 0 10px;
    	height: 16px;
    	line-height: 16px;
        padding-right: 35px;
	}
	.fr {
    	float: right;
	}
	.top_right_btn >a, .top_right_btn>span {
    	vertical-align: middle;
	}
	.ff {
    	color: #ffffff;
	}
	.top_right_btn span, .help-box .shu, .top_right_login .shu {
    	margin: 0 20px;
    	border-left: 1px solid #E0E0E0;
    	display: inline-block;
    	height: 16px;
	}
	.clear {
    	clear: both;
	}
	.title {
    	background: #f2f2f2;
    	height: 89px;
    	width: 100%;
    	line-height: 32px;
	}
	.overflowhidden {
 	   height: auto;
    	overflow: hidden;
    	margin: auto;
	}
	.commwidth {
 	   width: 1200px;
       margin-left: auto;
       margin-right: auto;
	}
</style>
