import babelpolyfill from 'babel-polyfill'
import Vue from 'vue'
import App from './App'
import VueResource from 'vue-resource'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-default/index.css'
import VueRouter from 'vue-router'
import store from './vuex/store'
import Vuex from 'vuex'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import {routes} from './routes'
import { getUserInfo } from './api/api'

//mockdata数据模拟
//import Mock from './mock'
//Mock.bootstrap();

import 'font-awesome/css/font-awesome.min.css'

Vue.use(ElementUI)
Vue.use(VueRouter)
Vue.use(Vuex)

NProgress.configure({ showSpinner: false });

const router = new VueRouter({
  routes
})

const LoginUser = {
    member_id:'',
    email:'',
    phone:'',
    token:'',
    nickname:'',
    truename:'',
    avatar:'',
    sex:'',
    area_info:'',
    member_address:'',
    organization_id:'',
    parent:{
      member_id:'',
    },
};

//默认跳转登录页面
/*router.beforeEach((to, from, next) => {
  //NProgress.start();
  if (to.path == '/login') {
    sessionStorage.removeItem('user');
  }
  let user = JSON.parse(sessionStorage.getItem('user'));
  if (!user && to.path != '/login') {
    next({ path: '/login' })
  } else {
    next()
  }
})*/

//用户登录信息初始化
//默认跳转官网登录页面(根据用户token过期时间)
//router.push({ path: '/main' });
router.beforeEach((to, from, next) => {
  /*if (to.path == '/login') {
    sessionStorage.removeItem('user');
  }*/
  NProgress.start();

  //用户信息通过cookie获取
  /*function getcookie(objname){//获取指定名称的cookie的值
    var arrstr = document.cookie.split(";");
    for(var i = 0;i < arrstr.length;i ++){
      var temp = arrstr[i].split("=");
      if(temp[0] == objname) return unescape(temp[1]);
    } 
  }

  var test = getcookie('_ga');
  console.log(test);*/

  getUserInfo().then((res) => {
    var code = res.code;
    NProgress.done();
    if (code == "4010008") {
      window.location.href = 'http://user.cnsebe.com/iprp/#!/access/login?return_url=http://steward.cnsebe.com/dist/index.html';
    } else if(code == "0") {    
      LoginUser.member_id = res.data.member_id;
      LoginUser.email = res.data.email;
      LoginUser.phone = res.data.phone;
      LoginUser.token = res.data.token;
      LoginUser.nickname = res.data.nickname;
      LoginUser.truename = res.data.truename;
      LoginUser.avatar = res.data.avatar;
      LoginUser.sex = res.data.sex;
      LoginUser.area_info = res.data.area_info;
      LoginUser.member_address = res.data.member_address;
      LoginUser.organization_id = 0;
      LoginUser.parent.member_id = res.data.parent.member_id;
      //LoginUser.organization_id = res.data.organization.organization_id;
      //console.log(LoginUser);
      sessionStorage.setItem('user', JSON.stringify(LoginUser)); 
      let user = JSON.parse(sessionStorage.getItem('user'));  
      //登录拦截
      /*if (!user && to.path != '/login') {
        next({ path: '/login' })
      } else {
        next()
      }*/
      next()
    }    
  }); 
})

//router.afterEach(transition => {
//NProgress.done();
//});

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

