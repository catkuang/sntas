<template>
	<div>
		<sebe-header></sebe-header>
		<div class="title">
    		<div class="banner">
            	<img src="../assets/images/logo_1.png" alt=""> 
            	<div class="route">
            		<router-link to="/main">首页</router-link>
            		<router-link to="/infoManage">消息</router-link>
            	</div>
				<div class="userinfo">
					<img class="word" src="../assets/images/logo_word.png" alt="">
					<el-dropdown trigger="click">
						<span class="el-dropdown-link userinfo-inner">
							<img :src="this.sysUserAvatar" /> 
							<span style="color:#000">您好,</span>
							{{sysUserName}}
						</span>
					</el-dropdown>
				</div>
    		</div>
		</div>
		<div class="main">
			<aside>
				<el-menu :default-active="$route.path" unique-opened class="el-menu-vertical-demo" @open="handleopen" @close="handleclose" @select="handleselect" router>
					<template v-for="(item,index) in $router.options.routes" v-if="!item.hidden">
						<el-submenu :index="index+''" v-if="!item.leaf">
							<template slot="title"><i :class="item.iconCls"></i>{{item.name}}</template>
							<el-menu-item v-for="child in item.children" :index="child.path" v-if="!child.hidden">{{child.name}}</el-menu-item>
						</el-submenu>
						<el-menu-item v-if="item.leaf&&item.children.length>0" :index="item.children[0].path"><i :class="item.iconCls"></i>{{item.children[0].name}}</el-menu-item>
					</template>
				</el-menu>
			</aside>
			<section class="content-container">
				<div class="grid-content bg-purple-light">
					<transition>
						<router-view></router-view>
					</transition>
				</div>
			</section>
		</div>
		<sebe-footer></sebe-footer>
	</div>
	<!--<div>
		<el-row class="container">
		<el-col :span="24" class="header">
			<el-col :span="4" class="logo">
				<img src="../assets/images/logo2.png" /> 
				<span><i class="txt" style="font-style:normal">拾贝管家</i></span>
			</el-col>
			<el-col :span="16">
				<el-menu theme="dark" class="row-nav" mode="horizontal">
  					<el-menu-item index="1"><router-link to="/main">首页</router-link></el-menu-item>
  					<el-menu-item index="2"><router-link to="/infoManage">消息</router-link></el-menu-item>
				</el-menu>
			</el-col>
			<el-col :span="4" class="userinfo">
				<el-dropdown trigger="click">
					<span class="el-dropdown-link userinfo-inner"><img :src="this.sysUserAvatar" /> {{sysUserName}}</span>
					<!-.-<el-dropdown-menu slot="dropdown">
						<el-dropdown-item>我的消息</el-dropdown-item>
						<el-dropdown-item>设置</el-dropdown-item>
						<el-dropdown-item divided @click.native="logout">退出登录</el-dropdown-item>
					</el-dropdown-menu>-.->
				</el-dropdown>
			</el-col>
		</el-col>
		<el-col :span="24" class="main">
			<aside>
				<el-menu :default-active="$route.path" class="el-menu-vertical-demo" @open="handleopen" @close="handleclose" @select="handleselect"
					theme="dark" unique-opened router>
					<template v-for="(item,index) in $router.options.routes" v-if="!item.hidden">
						<el-submenu :index="index+''" v-if="!item.leaf">
							<template slot="title"><i :class="item.iconCls"></i>{{item.name}}</template>
							<el-menu-item v-for="child in item.children" :index="child.path" v-if="!child.hidden">{{child.name}}</el-menu-item>
						</el-submenu>
						<el-menu-item v-if="item.leaf&&item.children.length>0" :index="item.children[0].path"><i :class="item.iconCls"></i>{{item.children[0].name}}</el-menu-item>
					</template>
				</el-menu>
			</aside>
			<section class="content-container">
				<div class="grid-content bg-purple-light">
					<!-.-<el-col :span="24" class="breadcrumb-container">
						<strong class="title">{{$route.name}}</strong>
						<el-breadcrumb separator="/" class="breadcrumb-inner">
							<el-breadcrumb-item v-for="item in $route.matched">
								{{ item.name }}
							</el-breadcrumb-item>
						</el-breadcrumb>
					</el-col>-.->
					<el-col :span="24" class="content-wrapper">
						<transition>
							<router-view></router-view>
						</transition>
					</el-col>
				</div>
			</section>
		</el-col>
		</el-row>
	</div>-->
</template>

<script>
	import sebeHeader from 'components/Header.vue'
	import sebeFooter from 'components/Footer.vue'
	export default {
		components: {
			sebeHeader,
			sebeFooter
		},
		data() {
			return {
				sysUserName: '',
				sysUserAvatar: '',
				form: {
					name: '',
					region: '',
					date1: '',
					date2: '',
					delivery: false,
					type: [],
					resource: '',
					desc: ''
				}
			}
		},
		methods: {
			onSubmit() {
				console.log('submit!');
			},
			handleopen() {
				//console.log('handleopen');
			},
			handleclose() {
				//console.log('handleclose');
			},
			handleselect: function (a, b) {
			},
			//退出登录
			logout: function () {
				var _this = this;
				this.$confirm('确认退出吗?', '提示', {
					//type: 'warning'
				}).then(() => {
					sessionStorage.removeItem('user');
					_this.$router.push('/login');
				}).catch(() => {

				});


			}
		},
		mounted() {
			var user = sessionStorage.getItem('user');
			if (user) {
				user = JSON.parse(user);
				this.sysUserName = user.truename || '';
				this.sysUserAvatar = user.avatar || '';
			}
		}
	}

</script>

<style scoped lang="scss">
	.title {
    	background: #f2f2f2;
    	height: 89px;
    	width: 100%;
    	line-height: 89px;
    	position:relative;
    	.banner {
    		width: 100%;
    		margin: 0px auto;    	
    		background-color:#fff;	
    		img{
    			position: relative;
    			left: -280px;
    		}
    		.route{
    			display: inline-block;
    			position:relative;
    			left: -250px;
    			a{
    				padding-right:15px;
    				color: #48576a;
    			}
    		}
    		.word{
    			position:relative;
    			left: -60px;
    		}
    		.userinfo {
    			display: inline-block;
				text-align: right;
				padding-right: 35px;
				position:absolute;
				right: 0%;
				.userinfo-inner {
					color: #ff7019;
					cursor: pointer;
					img {
						position: absolute;
    					left: -62px;
    					top: 16px;
						width: 40px;
						height: 40px;
						border-radius: 20px;
						margin: 10px 0px 10px 10px;
					}
				}
			}
		}
	}
	.main{
		background: #f2f2f2;
    	padding-top: 20px;
		width: 100%;
		height: 100%;
		min-height: 800px;
		position:relative;
		clear: both;
		min-width: 1200px;
		max-width: 1920px;
		aside{
			position: absolute;
    		left: 0px;
    		width: 230px;
    		height: 600px;
    		//background-color: #fff;
    		border-radius:3px;
		}
		.content-container{
    		margin-left: 250px;
		}
	}
	/*.container {
		position: absolute;
		top: 0px;
		bottom: 0px;
		width: 100%;
		.header {
			height: 60px;
			line-height: 60px;
			background: #1F2D3D;
			color: #c0ccda;
			.row-nav{
				background-color:#1F2D3D;
				a{
					text-decoration: none;
				}
			}
			.userinfo {
				text-align: right;
				padding-right: 35px;
				.userinfo-inner {
					color: #c0ccda;
					cursor: pointer;
					img {
						width: 40px;
						height: 40px;
						border-radius: 20px;
						margin: 10px 0px 10px 10px;
						float: right;
					}
				}
			}
			.logo {
				font-size: 22px;
				img {
					width: 100px;
					float: left;
					margin: 10px 10px 10px 18px;
				}
				.txt {
					color: #20a0ff
				}
			}
		}
		.main {
			background: #324057;
			position: absolute;
			top: 60px;
			bottom: 0px;
			overflow: hidden;
			aside {
				width: 230px;
			}
			.content-container {
				background: #f1f2f7;
				position: absolute;
				right: 0px;
				top: 0px;
				bottom: 0px;
				left: 230px;
				overflow-y: scroll;
				.breadcrumb-container {
					margin-bottom: 15px;
					.title {
						width: 200px;
						float: left;
						color: #475669;
					}
					.breadcrumb-inner {
						float: right;
					}
				}
				.content-wrapper {
					background-color: #fff;
					box-sizing: border-box;
				}
			}
		}
	}*/
</style>
<style>
	.el-submenu__title{
		background-color: #004991;
		color: #fff;
	}
	.el-submenu__title:hover {
    	background-color: #004991;
	}
	.el-menu-item{
		background-color: #fff;
	}
	.el-submenu .el-menu-item:hover{
		background-color: #CBE3FF
	}
</style>