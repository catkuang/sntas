<template>
	<div>
        <!--<el-select v-model="pId" @change="chgProvince(pId);" placeholder="请选择所在省份">
            <el-option v-for="item,$index in provinces" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="cId" @change="chgCity(cId);" placeholder="请选择所在城市">
            <el-option v-for="item,$index in citys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="ctId" placeholder="请选择所在区县">
            <el-option v-for="item,$index in countys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>-->
        <!--<div>{{province.name}}</div>-->
        <select v-model="province" @change="chgProvince(province);" placeholder="请选择所在省份" class="selt">
            <option v-for="item,$index in provinces" :value="item">{{ item.name }}</option>
        </select>
        <select v-model="city" @change="chgCity(city);" placeholder="请选择所在城市" class="selt">
            <option v-for="item,$index in citys" :value="item">{{ item.name }}</option>
        </select>
        <select v-model="county" @change="chgCounty(county)" placeholder="请选择所在区县" class="selt">
            <option v-for="item,$index in countys" :value="item">{{ item.name }}</option>
        </select>
    </div>
</template>

<script>
import axios from 'axios'
import URLSearchParams from 'url-search-params'
import qs from 'qs'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getLocation, getBasicInfo } from '../../api/api'
export default {
	name: 'AreaThreeLevelLinkage',
 	props: [],
 	data() {
 		return {
            province:{
                area_id:null,
                name:''
            },
            city:{
                area_id:null,
                name:''
            },
            county:{
                area_id:null,
                name:''
            },
 			provinces:[],
            citys:[],
            countys:[],
            //用户初始化地址
            area_info:'',
            province_id:null,
            city_id:null,
            area_id:null,
            pro:'',
            ct:'',
            cty:'',
 		}
 	},
    beforeMount(){
    },
 	mounted(){
        this.getUserArea();
        this.getProvinceData();
        /*this.addressData=[
            {
                pName:'湖南',
                citys:[
                    {
                        cName:'长沙',
                        countys:[
                            {
                                cyName:'区1'
                            },
                            {
                                cyName:'区2'
                            }
                        ]
                    },                   
                ]
            },
            {
                pName:'浙江',
                citys:[
                    {
                        cName:'杭州',
                        countys:[
                            {
                                cyName:'区3'
                            },
                            {
                                cyName:'区4'
                            }
                        ]
                    },                   
                ]
            }
        ]*/
    },
 	methods: {
        //获取初始化用户所在省市区并反绑
        getUserArea(){
            getBasicInfo().then((res) => {             
                this.area_info = res.data.area_info;
                //console.log(this.area_info);
                this.province_id = res.data.province_id;
                this.city_id = res.data.city_id;
                this.area_id = res.data.area_id;
                let str = this.handleAreaInfoSplit(this.area_info);
                this.pro = str[0];
                this.ct = str[1];
                this.cty = str[2];   
                this.province.area_id = this.province_id;
                this.province.name = this.pro;
                this.city.area_id = this.city_id;
                this.city.name = this.ct;
                this.county.area_id = this.area_id;
                this.county.name = this.cty;
                //市区反绑获取select列表
                if(this.province.area_id != null && this.province.name != ''){
                    this.chgPro(this.province);
                };
                if(this.city.area_id != null && this.city.name != ''){
                    this.chgCt(this.city);
                };
                //this.chgCity(this.county);
                //console.log(JSON.stringify(this.province) + JSON.stringify(this.city) + JSON.stringify(this.county));
            });
        },
        //地址切割
        handleAreaInfoSplit(areaInfo){
            var str = areaInfo.split(" ");
            return str;
        },
        //获取省数据
        getProvinceData(){
            /*let para = new URLSearchParams();
            para.append('pId', 0)*/
            let para = {'pId':0}
            getLocation(qs.stringify(para)).then((res) => {  
                var elements = res.elements;
                this.provinces = elements.map(function(item){
                    return {
                        area_id:item.area_id,
                        name:item.name
                    }
                })
                //console.log(this.provinces);
            }); 
        },
        chgPro(provinceObj){
            this.countys.length = 0;
            /*let para = new URLSearchParams();
            para.append('pId', provinceObj.area_id)*/
            let para = {'pId':provinceObj.area_id}
            getLocation(qs.stringify(para)).then((res) => { 
                var elements = res.elements;
                this.citys = elements.map(function(item){
                    return {
                        area_id:item.area_id,
                        name:item.name
                    }
                })
            });
        },
        chgProvince(provinceObj){
            this.countys.length = 0;
            /*let para = new URLSearchParams();
            para.append('pId', provinceObj.area_id)*/
            let para = {'pId':provinceObj.area_id}
            getLocation(qs.stringify(para)).then((res) => { 
                var elements = res.elements;
                this.citys = elements.map(function(item){
                    return {
                        area_id:item.area_id,
                        name:item.name
                    }
                })
            });
            this.city.name = '';
            this.county.name = '';

            //向父组件传播事件,数据
            this.$emit('provinceChg', provinceObj, this.city.name, this.county.name);
        },
        chgCounty(countyObj){
            //向父组件传播事件,数据
            this.$emit('countyChg', countyObj);
        },
        chgCt(cityObj){
            /*let para = new URLSearchParams();
            para.append('pId', cityObj.area_id)*/
            let para = {'pId':cityObj.area_id}
            getLocation(qs.stringify(para)).then((res) => { 
                var elements = res.elements;
                this.countys = elements.map(function(item){
                    return {
                        area_id:item.area_id,
                        name:item.name
                    }
                })
            });
        },
        chgCity(cityObj){
            /*let para = new URLSearchParams();
            para.append('pId', cityObj.area_id)*/
            let para = {'pId':cityObj.area_id}
            getLocation(qs.stringify(para)).then((res) => { 
                var elements = res.elements;
                this.countys = elements.map(function(item){
                    return {
                        area_id:item.area_id,
                        name:item.name
                    }
                })
            });
            //向父组件传播事件,数据
            this.$emit('cityChg', cityObj);
        },
        chgCounty(countyObj){
            //向父组件传播事件,数据
            this.$emit('countyChg', countyObj);
        },

 	},
    /*watch:{
        province:function(val,oldval){
            if(val!==oldval){
                this.province={
                    area_id:null,
                    name:''
                }
            }
        },
        city:function(val,oldval){
            if(val!==oldval){
                this.city={
                    area_id:null,
                    name:''
                }
            }
        }
 	}*/
}
</script>

<style scoped>
	ul,li{
 		list-style-type: none;
	}
	.detail{
		padding:10px 0px;
		display:block;
		width:438px;
	}
    .selt{
        border-radius: 4px;
        border: 1px solid #bfcbd9;
        box-sizing: border-box;
        color: #1f2d3d;
        display: inline-block;
        font-size: inherit;
        height: 36px;
        line-height: 1;
        outline: 0;
        padding: 3px 10px;
        transition: border-color .2s cubic-bezier(.645,.045,.355,1);
        width: 12%;
    }
</style>
