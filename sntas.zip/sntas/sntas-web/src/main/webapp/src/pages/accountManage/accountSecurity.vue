<template>
	<section>
		<div class="account-security">
            <div class="security-title">
            	账户安全
            </div>
            <div class="tip">
           		<el-tag type="danger">警告：</el-tag>
           		<span>建议您启用全部安全设置,以保证资金账户安全</span>
            </div>
            <div class="security-content">
				<ul style="display:inline">
					<li class="bind">
						<div class="bind-img">
							<a>
								<img data-v-05772e73="" src="../../assets/images/phone.png">
							</a>
						</div>
						<h3 class="bind-pros">
							<a>手机号</a>
							<p class="desc">您已绑定手机号136***2187</p>
							<el-button type="info">重新绑定</el-button>
						</h3>
					</li>
					<li class="bind">
						<div class="bind-img">
							<a>
								<img data-v-05772e73="" src="../../assets/images/email.png">
							</a>
						</div>
						<h3 class="bind-pros">
							<a>邮箱</a>
							<p class="desc">您还未绑定邮箱</p>
							<el-button type="info">绑定邮箱</el-button>
						</h3>
					</li>
					<li class="bind">
						<div class="bind-img">
							<a>
								<img data-v-05772e73="" src="../../assets/images/name.png">
							</a>
						</div>
						<h3 class="bind-pros">
							<a>实名认证</a>
							<p class="desc">您还未实名认证</p>
							<el-button type="info">实名认证</el-button>
						</h3>
					</li>
				</ul>
            </div>
		</div>
	</section>
</template>

<script>
	export default {
		data(){
			return{

			}
		},
		methods:{

		},
		mounted(){

		}
	}

</script>

<style scoped lang="scss">
    .account-security{
    	padding:10px;
		.security-title{
			color: #48576a;
    		line-height: 1;
    		padding: 15px 12px 15px 0;
    		vertical-align: middle;
    		font-size: 18px;
    		font-weight: 600;
		}
		.tip{
			color: #48576a;
		}
		.security-content{
			margin-top: 50px;
			.bind{
				list-style-type: none;
    			height: 250px;
    			padding: 20px 0;
    			position: relative;
    			z-index: 1;
    			float: left;
    			width: 234px;
    			margin: 0px 20px 0px 0px;
    			transition: all .2s linear;
    			.bind-img{
    				width: 50px;
    				height: 50px;
    				margin: 0 auto 18px;
    				img{
    					width: 50px;
    					height: 50px;
    				}
    			}
    			.bind-pros{
    				margin: 0 10px 2px;
    				color: #333;
    				font-size: 14px;
    				font-weight: 400;
    				text-align: center;
    				.desc{
    					margin: 0 10px 10px;
    					height: 18px;
    					font-size: 12px;
    					text-align: center;
    					text-overflow: ellipsis;
    					white-space: nowrap;
    					overflow: hidden;
    					color: #b0b0b0;
    				}
    			}
			}
		}
    }
</style>
