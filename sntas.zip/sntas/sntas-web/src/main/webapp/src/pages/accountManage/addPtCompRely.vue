<template>
	<section>
    <div class="operate">
      <a class="delete" @click="batchAdd"><i class="el-icon-plus"></i>批量添加专利资产</a>
    </div>
		<div class="trademark-list">
      <el-table :data="patentAddListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;" >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="patentName" label="专利名称"></el-table-column>
        <el-table-column prop="applyNo" label="申请号" ></el-table-column>
        <el-table-column prop="applyTime" label="申请时间" ></el-table-column>
        <el-table-column prop="publicNoticeNo" label="公开公告号" ></el-table-column>
        <el-table-column prop="publicNoticeDate" label="公开公告日期" ></el-table-column>
        <el-table-column prop="ipcType" label="IPC分类号" ></el-table-column>
        <el-table-column prop="applyUser" label="申请人" ></el-table-column> 
        <el-table-column prop="inventUser" label="发明人"></el-table-column>
      </el-table>
		</div>
	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { queryCompTmRely, addCompTmRely } from '../../api/api';
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data(){
			return{
				searchType: '1',
        listLoading:false,
				//查询条件
				schCondition: {
          keyword:'',
    		},
				patentAddListData: [],
        selecteds: [],//列表选中列
			}
		},
		methods:{

      //查询公司与专利的依赖
      getPatentListsData(){
        let memberId = JSON.parse(sessionStorage.getItem("user")).member_id;
        /*let para = new URLSearchParams();
        para.append('memberId', memberId);
        para.append('type', 1);*/
        let para = { 
          'memberId': memberId,
          'type': 1,
        }
        this.listLoading = true;
        NProgress.start();
        queryCompTmRely(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.patentAddListData = res.patentInfo;
          this.listLoading = false;
          //console.log(this.trademarkAddListData);
          NProgress.done();
        });
      },
      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },
      //添加公司与专利的依赖
      batchAdd: function () {
        //console.log(this.selecteds);
        var ids = this.selecteds.map(item => item.id).toString();
        if(!ids){
          this.$notify.info({
            title: '消息',
            message: '请选择需要添加项'
          });
          return false;
        }else{
          this.$confirm('确认添加选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            //let para = JSON.stringify(this.selecteds);
            /*let para = new URLSearchParams();
            para.append('idList', ids);
            para.append('type',1);
            para.append('organization_id',this.$route.params.organization_id);*/
            let para = { 
              'idList': ids,
              'type': 1,
              'organization_id': this.$route.params.organization_id
            }
            addCompTmRely(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '添加成功',
                type: 'success'
              });
              setTimeout(this.$router.push({ path: '/companyInfo' }),3000);
            });
          }).catch(() => {
          });
        }
      }
		},
		mounted(){
      this.getPatentListsData();
		}
	}

</script>

<style scoped lang="scss">
    .tab{
    	padding:10px;
    }
    .operate{
    	padding:10px;
    	a{
			  margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
        cursor: pointer;
    	}
    }
    .trademark-list{
    	padding:10px;
    }
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
