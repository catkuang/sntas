<template>
	<section>
    <div class="operate">
      <a class="delete" @click="batchAdd"><i class="el-icon-plus"></i>批量添加商标资产</a>
    </div>
		<div class="trademark-list">
			<el-table :data="trademarkAddListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;" >
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="intCls" label="分类号"></el-table-column>
				<el-table-column prop="regNo" label="商标注册号"></el-table-column>
				<el-table-column prop="tmImg"  label="商标图形">
          <template scope="scope">
            <img class="lazy" :src="'http://pic.tmkoo.com/pic.php?s=1&zch='+scope.row.tmImg" >
          </template>
        </el-table-column>
				<el-table-column prop="applicantCn" label="注册人"></el-table-column>
				<el-table-column prop="appDate" label="申请日期"></el-table-column>
				<el-table-column prop="regDate" label="注册日期"></el-table-column>
			</el-table>
		</div>
	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { queryCompTmRely, addCompTmRely } from '../../api/api';
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data(){
			return{
				searchType: '1',
        listLoading:false,
				//查询条件
				schCondition: {
          keyword:'',
    		},
				trademarkAddListData: [],
        selecteds: [],//列表选中列
			}
		},
		methods:{

      //查询公司与商标的依赖
      getTrademarkListsData(){
        let memberId = JSON.parse(sessionStorage.getItem("user")).member_id;
        /*let para = new URLSearchParams();
        para.append('memberId', memberId);
        para.append('type', 0);*/
        let para = { 
          'memberId': memberId,
          'type': 0,
        }
        this.listLoading = true;
        NProgress.start();
        queryCompTmRely(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.trademarkAddListData = res.tradeMarkInfo;
          this.listLoading = false;
          //console.log(this.trademarkAddListData);
          NProgress.done();
        });
      },
      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },
      //添加公司与商标的依赖
      batchAdd: function () {
        //console.log(this.selecteds);
        var ids = this.selecteds.map(item => item.id).toString();
        if(!ids){
          this.$notify.info({
            title: '消息',
            message: '请选择需要添加项'
          });
          return false;
        }else{
          this.$confirm('确认添加选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            //let para = JSON.stringify(this.selecteds);
            /*let para = new URLSearchParams();
            para.append('idList', ids);
            para.append('type',0);
            para.append('organization_id',this.$route.params.organization_id);*/
            let para = { 
              'idList': ids,
              'type': 0,
              'organization_id': this.$route.params.organization_id
            }
            addCompTmRely(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '添加成功',
                type: 'success'
              });
              setTimeout(this.$router.push({ path: '/companyInfo' }),3000);
            });
          }).catch(() => {
          });
        }
      }
		},
		mounted(){
      this.getTrademarkListsData();
		}
	}

</script>

<style scoped lang="scss">
    .tab{
    	padding:10px;
    }
    .operate{
    	padding:10px;
    	a{
			  margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
        cursor: pointer;
    	}
    }
    .trademark-list{
    	padding:10px;
    }
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
