<template>
	<div>
        <!--<el-select v-model="pId" @change="chgProvince(pId);" placeholder="请选择所在省份">
            <el-option v-for="item,$index in provinces" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="cId" @change="chgCity(cId);" placeholder="请选择所在城市">
            <el-option v-for="item,$index in citys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>
        <el-select v-model="ctId" placeholder="请选择所在区县">
            <el-option v-for="item,$index in countys" :label="item.name" :value="item.area_id" ></el-option>
        </el-select>-->
        <select v-model="province" @change="chgProvince(province);" placeholder="请选择所在省份" class="selt">
            <option v-for="item,$index in provinces" :value="item">{{ item.name }}</option>
        </select>
        <select v-model="city" @change="chgCity(city);" placeholder="请选择所在城市" class="selt">
            <option v-for="item,$index in citys" :value="item">{{ item.name }}</option>
        </select>
        <select v-model="county" @change="chgCounty(county)" placeholder="请选择所在区县" class="selt">
            <option v-for="item,$index in countys" :value="item">{{ item.name }}</option>
        </select>
    </div>
</template>

<script>
import axios from 'axios'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getLocation } from '../../api/api'
export default {
	name: 'Address',
 	//props: ['province','city','county'],
 	data() {
 		return {
            province:'',
            city:'',
            county:'',
 			provinces:[],
            citys:[],
            countys:[]
 		}
 	},
 	mounted(){
        this.getProvinceData();
        /*this.addressData=[
            {
                pName:'湖南',
                citys:[
                    {
                        cName:'长沙',
                        countys:[
                            {
                                cyName:'区1'
                            },
                            {
                                cyName:'区2'
                            }
                        ]
                    },                   
                ]
            },
            {
                pName:'浙江',
                citys:[
                    {
                        cName:'杭州',
                        countys:[
                            {
                                cyName:'区3'
                            },
                            {
                                cyName:'区4'
                            }
                        ]
                    },                   
                ]
            }
        ]*/
    },
 	methods: {
        //获取省数据
        getProvinceData(){
            let para = new URLSearchParams();
            para.append('pId', 0)
            getLocation(para).then((res) => {  
                this.provinces = res.elements;
            }); 
        },
        chgProvince(provinceObj){
            let para = new URLSearchParams();
            para.append('pId', provinceObj.area_id)
            getLocation(para).then((res) => { this.citys = res.elements; });
            //向父组件传播事件,数据
            this.$emit('provinceChg', provinceObj);
        },
        chgCity(cityObj){
            let para = new URLSearchParams();
            para.append('pId', cityObj.area_id)
            getLocation(para).then((res) => { this.countys = res.elements; });
            //向父组件传播事件,数据
            this.$emit('cityChg', cityObj);
        },
        chgCounty(countyObj){
            //向父组件传播事件,数据
            this.$emit('countyChg', countyObj);
        },

 	},
    watch:{
        pId:function(val,oldval){
            if(val!==oldval){
                //this.cId=''
            }
        },
        cId:function(val,oldval){
            if(val!==oldval){
                //this.ctId=''
            }
        }
 	}
}
</script>

<style scoped>
	ul,li{
 		list-style-type: none;
	}
	.detail{
		padding:10px 0px;
		display:block;
		width:438px;
	}
    .selt{
        border-radius: 4px;
        border: 1px solid #bfcbd9;
        box-sizing: border-box;
        color: #1f2d3d;
        display: inline-block;
        font-size: inherit;
        height: 36px;
        line-height: 1;
        outline: 0;
        padding: 3px 10px;
        transition: border-color .2s cubic-bezier(.645,.045,.355,1);
        width: 12%;
    }
</style>
