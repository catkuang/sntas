<template>
	<section style="position:relative;">
		<div class="basicInfo">
			<div class="basicInfo-title">基本信息</div>
        <el-form ref="ruleForm" :rules="basicRules" :model="form" label-width="100px">
          	<el-form-item label="头像" class="wid20"><!--//192.168.1.123:8181/cnsebe-steward-web/FileController/uploadData.do-->
    				  <el-upload class="avatar-uploader" name="fileData" action="http://steward.cnsebe.com/FileController/uploadData.do" :show-file-list="false" :on-success="handleAvatarScucess" :before-upload="beforeAvatarUpload">
  						  <img v-if="imageUrl" :src="imageUrl" class="avatar">
  						  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
					   </el-upload>
  				  </el-form-item>
  				<el-form-item label="昵称" class="wid350" ><!--prop="nickname"-->
    				<el-input v-model="form.nickname"></el-input>
  				</el-form-item>
          <el-form-item label="姓名" class="wid350" prop="truename">
            <el-input v-model ="form.truename"></el-input>
          </el-form-item>
          <!--<i class="warning sexPos"></i>-->
  				<el-form-item label="性别" class="wid350">
    				<el-radio-group v-model="form.sex">
      					<el-radio :label="1">男</el-radio>
      					<el-radio :label="0">女</el-radio>
    				</el-radio-group>
  				</el-form-item>
          <i class="warning idPos"></i>
          <el-form-item label="身份证" class="wid350" prop="memberIdentificationCard">
            <el-input v-model="form.memberIdentificationCard"></el-input>
          </el-form-item>
          <!--<i class="warning birthPos"></i>-->
  				<el-form-item label="出生年月" class="wid350" prop="birthday">
    				<div class="block">
              <el-date-picker v-model="form.birthday" format="yyyy-MM-dd" type="date" placeholder="选择日期" :picker-options="pickerOptions0">
              </el-date-picker>
            </div>
  				</el-form-item>
          <el-form-item label="所属行业" class="wid350">
            <el-select v-model="form.member_industry" placeholder="选择所属行业">
              <el-option v-for="item in industrys" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
          <i class="warning phonePos"></i>
          <el-form-item label="手机号" class="wid500" prop="phone">
            <el-input v-model="form.phone" style="width:62%"></el-input>
            <el-button type="info" @click="getCode" :disabled="vali">{{codeTxt}}</el-button>
        </el-form-item>
        <!--<i class="warning codePos"></i>-->
        <el-form-item label="验证码" class="wid350"><!--prop="code"-->
          <!--<el-tooltip class="item" effect="dark" content="如果更换手机请重新获取并填写验证码" placement="right">-->
            <el-input v-model="form.code"  @blur="clearMsg"></el-input><!--@blur="codeValidate"-->
            <el-tag type="danger">如果更换手机请重新获取并填写验证码</el-tag>
          <!--</el-tooltip>-->
          <span class="valiMsg">{{valiMsg}}</span>
        </el-form-item>
        <i class="warning emailPos"></i>
  				<el-form-item label="E-mail" class="wid350" prop="email">
    				<el-input v-model="form.email"></el-input>
  				</el-form-item>
          <i class="warning areaPos"></i>
          <el-form-item label="所在区域" >
            <AreaThreeLevelLinkage @provinceChg="provinceChg" @cityChg="cityChg" @countyChg="countyChg"></AreaThreeLevelLinkage>
            <span class="valiMsg">{{areaValiMsg}}</span>
          </el-form-item>
          <el-form-item label="详细地址" class="wid41"><!--prop="member_address"-->
            <el-input v-model="form.member_address"></el-input>
          </el-form-item>
  				<el-form-item>
    				<el-button type="primary" @click="saveBasicInfo('ruleForm')">保存</el-button>
  				</el-form-item>
			</el-form>
		</div>
	</section>
</template>

<script>
  import Vue from 'vue'
  import NProgress from 'nprogress'
  import 'nprogress/nprogress.css'
  import imgUpload from './imgUpload.vue'
  import AreaThreeLevelLinkage from './AreaThreeLevelLinkage.vue'
  import { getBasicInfo, baseUrl_sgj, updateBasicInfo, uploadPic, getPhoneCode, validatePhoneCode } from '../../api/api'
  import filters from '../../api/filters'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data(){
      //身份证验证
      let checkId = (rule, value, callback) => {
        let reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
        if (!value) {
          return callback(new Error('身份证不能为空'));
        }
        setTimeout(() => {
          if (!reg.test(value)) {
            callback(new Error('身份证格式错误'));
          } else {
            callback();
          }
        }, 1000);
      };
      //手机号码验证
      let checkPhone = (rule, value, callback) => {
        let reg = /^(13[0-9]|17[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|16[4]|18[0-9])\d{8}$/;
        if (!value) {
          return callback(new Error('手机号不能为空'));
        }
        setTimeout(() => {
          if (!reg.test(value)) {
            callback(new Error('手机号格式错误'));
          } else {
            callback();
          }
        }, 1000);
      };
      //验证码验证
      let checkCode = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('验证码不能为空'));
        }
        setTimeout(() => {  
          //var code = this.validateCode();
          //console.log(code);
          //返回Promise解析
          var code = '';
          Promise.resolve(this.validateCode()).then(function(onFulfilled, onRejected){
            //console.log(onFulfilled);
            code = onFulfilled;
            if(code == 200){
              callback(new Error('验证码错误'));
            }else if(code == 0){
              callback();
            }
          });
        }, 1000);
      };
      //邮箱验证
      let checkEmail = (rule, value, callback) =>{
        let emailReg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!value) {
          return callback(new Error('邮箱不能为空'));
        }
        setTimeout(() => {
          if (!emailReg.test(value)) {
            callback(new Error('邮箱格式错误'));
          } else {
            callback();
          }
        }, 1000);
      };
      //出生年月验证
      let checkBirth = (rule, value, callback) =>{
        console.log(value);
        if (!value) {
          return callback(new Error('请选择出生年月'));
        }
      };
			return{
        listLoading:false,
				imageUrl: '',
        codeTxt:'获取验证码',
        vali:false,
        valiMsg:'',
        areaValiMsg:'',
        valiCode:'',
				form:{
          avatar:'',
    			nickname: '',         			
          truename:'',
          sex:1,
          memberIdentificationCard:'',
          birthday:'',
          member_industry:'',
          phone:'',
          code:'',
          email:'',
          province:'',
          province_id:'',
          proObj:{
            area_id:'',
            name:'',
          },
          city:'',
          city_id:'',
          cityObj:{
            area_id:'',
            name:'',
          },
          county:'',
          area_id:'',
          countyObj:{
            area_id:'',
            name:'',
          },
          area_info:'',
          member_address:''
        },
        basicRules:{
          nickname:[
            { required: true, message: '请输入昵称', trigger: 'blur' }
          ],
          truename:[
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          /*birthday:[
            { validator:checkBirth, trigger: 'blur' }
          ],*/
          memberIdentificationCard: [
            { validator:checkId, trigger: 'blur' }
          ],
          phone: [
            { validator:checkPhone, trigger: 'blur' }
          ],
          code: [
            { validator:checkCode, trigger: 'blur' }
          ],
          email:[
            { validator:checkEmail, trigger: 'blur' }
          ],

          member_address:[
            { required: true, message: '请输入联系地址', trigger: 'blur' }
          ],
        },
        industrys: [{
          value: '1',
          label: '餐饮'
        }, {
          value: '2',
          label: '互联网'
        }, {
          value: '3',
          label: '家政'
        }],
        pickerOptions0: {
        },
			}
		},
    components: {
      imgUpload,
      AreaThreeLevelLinkage
    },
		methods:{

      //获取基本信息
      getBasicInfoData(){
        NProgress.start();
        getBasicInfo().then((res) => {
          let { code } = res;
          //console.log(code);
          //console.log(res);
          NProgress.done();
          if(code != 0){
            alert("网络异常");
          }else{    
            this.form.avatar = res.data.avatar; 
            this.form.nickname = res.data.nickname;
            this.form.truename = res.data.truename;
            this.form.sex = res.data.sex;
            this.form.memberIdentificationCard = res.data.memberIdentificationCard;
            this.form.birthday = res.data.birthday;
            this.form.member_industry = res.data.member_industry;
            this.form.phone = res.data.phone;
            this.form.email = res.data.email;
            this.form.area_info = res.data.area_info;
            this.form.province_id = res.data.province_id;
            this.form.city_id = res.data.city_id;
            this.form.area_id = res.data.area_id;
            this.form.member_address = res.data.member_address;
            //console.log(this.form);
            //console.log(this.form.area_info);
            let str = this.handleAreaInfoSplit(this.form.area_info);
            this.form.province = str[0];
            this.form.city = str[1];
            this.form.county = str[2];

            this.form.proObj.area_id = this.form.province_id;
            this.form.proObj.name = this.form.province;
            this.form.cityObj.area_id = this.form.city_id;
            this.form.cityObj.name = this.form.city;
            this.form.countyObj.area_id = this.form.area_id;
            this.form.countyObj.name = this.form.county;

          }    
        }); 
      },
      //地址切割
      handleAreaInfoSplit(areaInfo){
        var str = areaInfo.split(" ");
        return str;
      },
      handleAvatarScucess(res, file) {
        //console.log(res);
        //console.log(file);
        this.imageUrl = res.url
        //console.log(this.imageUrl);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';
        const isBMP = file.type === 'image/bmp';
        const isLt10M = file.size / 1024 / 1024 < 10;

        if (!isJPG && !isPNG && !isBMP) {
          this.$message.error('上传头像图片只能是 JPG,PNG或BMP 格式!');
        }

        if (!isLt10M) {
          this.$message.error('上传头像图片大小不能超过 10MB!');
        }
        return isJPG || isPNG || isBMP && isLt2M;
      },
      //获取地址组件省数据
      provinceChg(provinceObj,ct,cty){
        //console.log(provinceObj);
        //console.log(ct);
        //console.log(cty);
        this.form.province_id = provinceObj.area_id;
        this.form.province = provinceObj.name;
        this.form.city = ct;
        this.form.county = cty;
        //console.log(this.form.province_id + " " + this.form.province);
      },
      //获取地址组件市数据
      cityChg(cityObj){
        //console.log(cityObj);
        this.form.city_id = cityObj.area_id;
        this.form.city = cityObj.name;
        //console.log(this.form.city_id + " " + this.form.city);
      },
      //获取地址组件区数据
      countyChg(countyObj){
        //console.log(countyObj);
        this.form.area_id = countyObj.area_id;
        this.form.county = countyObj.name;
        //console.log(this.form.area_id + " " + this.form.county);
      },
      //省市区拼接
      handleAreaInfoJoint(){
        var areaJoint = this.form.province + " " + this.form.city + " " + this.form.county;
        //console.log(areaJoint);
        return areaJoint
      },
      //省市区非空验证
      provinceCityCountyValidate(){
        if(this.form.province == ''){
          this.areaValiMsg = '请选择所在省份';
        }else if(this.form.city == ''){
          this.areaValiMsg = '请选择所在市';
        }else if(this.form.county == ''){
          this.areaValiMsg = '请选择所在区';
        }else{
          this.areaValiMsg = '';
        }
      },
      //获取验证码
      getCode(){
        /*let para = new URLSearchParams();
        para.append('phone',this.form.phone);*/
        let para = { 
          'phone': this.form.phone,
        }
        getPhoneCode(qs.stringify(para)).then((res) => {
          //console.log(res);
          let second = 60;
          let timePromise = setInterval(() =>{
            if(second<=0){
                clearInterval(timePromise);
                second = 60;
                this.codeTxt = "重发验证码";
                this.vali = false;
              }else{
                this.vali = true;
                this.codeTxt = second + "秒后可重发";
                second--;
              }
          },1000)
        })
      },
      //验证验证码(独立)
      codeValidate(){
        if(!this.form.code){
          this.valiMsg = "验证码不能为空";
        }else{
          /*let para = new URLSearchParams();
          para.append('phone',this.form.phone);
          para.append('validate',this.form.code);*/
          let para = { 
            'phone': this.form.phone,
            'validate':this.form.code
          }
          validatePhoneCode(qs.stringify(para)).then((res) => {
            if(res.code = 0){
              this.valiMsg = '';
              this.valiCode = 0;
            }else{
              this.valiMsg = res.msg;
              this.valiCode = '';
            }
          });    
        }
      },
      //验证验证码(同步等待)
      async validateCode(){
          /*let para = new URLSearchParams();
          para.append('phone',this.form.phone);
          para.append('validate',this.form.code);*/
          let para = { 
            'phone': this.form.phone,
            'validate':this.form.code
          }
          var promiseFunc = await validatePhoneCode(qs.stringify(para)).then((res) => {
            return res;
          });
          return promiseFunc;   
      },
      clearMsg(){
        this.valiMsg = '';
      },
      //基本信息修改
			saveBasicInfo(formName) {
        //var code = null;
        this.handleAreaInfoJoint();

        //this.codeValidate();
        /*Promise.resolve(this.validateCode()).then(function(onFulfilled, onRejected){
          //console.log(onFulfilled);
          let data = onFulfilled;
          console.log(data);            
        });*/

        //this.provinceCityCountyValidate();

        if(this.form.province == ''){
          this.areaValiMsg = '请选择所在省份';
          return false
        }else if(this.form.city == ''){
          this.areaValiMsg = '请选择所在市';
          return false
        }else if(this.form.county == ''){
          this.areaValiMsg = '请选择所在区';
          return false
        }else{
          this.areaValiMsg = '';

          //promise解析
          /*Promise.resolve(this.validateCode()).then(function(onFulfilled, onRejected){
            //console.log(onFulfilled);
            let code = onFulfilled;
            console.log(code);  
          });*/
          
          this.$refs[formName].validate((valid) => {
            if (valid) {
            this.$confirm('确认修改用户基本信息吗?', '提示', {
              type: 'warning'
            }).then(() => {
              this.listLoading = true;
              NProgress.start();
              //this.form.areaInfo = this.province + ' ' + this.city + ' ' + this.county;  
              var birthday = filters.formatDate.timeStamp(this.form.birthday);
              /*let para = new URLSearchParams();
              para.append('body', JSON.stringify({  
                avatar:this.imageUrl,
                phone:this.form.phone,
                validate:this.form.code,
                email:this.form.email,
                nickname:this.form.nickname,
                truename:this.form.truename,
                sex:this.form.sex,
                memberIdentificationCard:this.form.memberIdentificationCard,
                birthday:birthday,
                member_industry:this.form.member_industry,
                province_id:this.form.province_id,
                city_id:this.form.city_id,
                area_id:this.form.area_id,
                area_info:this.handleAreaInfoJoint(),
                member_address:this.form.member_address,
              }));*/
              let para = { 
                'avatar':this.imageUrl,
                'phone':this.form.phone,
                'validate':this.form.code,
                'email':this.form.email,
                'nickname':this.form.nickname,
                'truename':this.form.truename,
                'sex':this.form.sex,
                'memberIdentificationCard':this.form.memberIdentificationCard,
                'birthday':birthday,
                'member_industry':this.form.member_industry,
                'province_id':this.form.province_id,
                'city_id':this.form.city_id,
                'area_id':this.form.area_id,
                'area_info':this.handleAreaInfoJoint(),
                'member_address':this.form.member_address,
              }
            updateBasicInfo(para).then((res) => {
              this.listLoading = false;
              NProgress.done();
              if(res.code==1010009 || res.code==1010010 ||res.code==10027){
                this.valiMsg = res.error;
                this.$notify({
                  title: '失败',
                  message: res.error,
                  type: 'error'
                });
              }else{
                this.$notify({
                  title: '成功',
                  message: '修改成功',
                  type: 'success'
                });
              }              
              this.getBasicInfoData();
            });
            }).catch(() => {
            });
            }
          });

        }
      },
		},
		mounted(){
      this.getBasicInfoData();
		},
    beforeMount(){
    },
	}

</script>

<style scoped lang="scss">
  .valiMsg{
    color: #ff4949;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
  }
  .warning:before {content: '*';color: #ff4949;margin-right: 4px;}
  .sexPos{position: absolute;left: 56px;top: 385px;}
  .birthPos{position: absolute;left: 30px;top: 501px;}
  //firefox IE(9,10)hack
  *>.idPos{position:absolute;left: 42px;top: 473px;}
  //chrome 360 qq hack
  @media screen and (-webkit-min-device-pixel-ratio:0) {.idPos{position:absolute;left: 42px;top: 443px;}}
  *>.phonePos{position: absolute;left: 43px;top: 684px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.phonePos{position: absolute;left: 43px;top: 616px;}}
  *>.codePos{position: absolute;left: 43px;top: 755px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.codePos{position: absolute;left: 43px;top: 674px;}}
  *>.emailPos{position: absolute;left: 43px;top: 857px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.emailPos{position: absolute;left: 43px;top: 765px;}}
  *>.areaPos{position: absolute;left: 30px;top: 928px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.areaPos{position: absolute;left: 30px;top: 824px;}}
	.wid20{width:20%;}
  .wid30{width:30%;}
	.wid41{width:41%;}
  .wid350{width:350px;}
  .wid500{width:500px;}
  .basicInfo{
  	padding:10px;
    	.basicInfo-title{
    		color: #48576a;
    		line-height: 1;
    		padding: 15px 12px 15px 0;
    		vertical-align: middle;
    		font-size: 18px;
        font-weight: 600;
    	}
    	.avatar-uploader .el-upload {
    		border: 1px dashed #d9d9d9;
    		border-radius: 6px;
    		cursor: pointer;
    		position: relative;
    		overflow: hidden;
  		}
  		.avatar-uploader .el-upload:hover {
    		border-color: #20a0ff;
  		}
  		.avatar-uploader-icon {
    		font-size: 28px;
    		color: #8c939d;
    		width: 178px;
    		height: 178px;
    		line-height: 178px;
    		text-align: center;
  		}
  		.avatar {
    		width: 178px;
    		height: 178px;
    		display: block;
        border-radius:95px;
  		}
    }
</style>
