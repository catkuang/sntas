<template>
	<section>
		<div class="authInfo">
			<div class="authInfo-title">公司信息</div>
      <div>
        <el-button type="info" @click="addCompInfo" v-if="compInfoExistBtn=='show'">添加公司</el-button>
        <!--<el-button style="cursor:pointer;padding-left:10px;" type="info" @click="batchRemove(0)" >商标资产批量删除</el-button>
        <el-button style="cursor:pointer;padding-left:10px;" type="info" @click="batchRemove(1)" >专利资产批量删除</el-button>-->
      </div>
      <div class="authInfo-add" v-if="compInfoExist=='show'">
        <div class="authInfo-list">
          <el-row >
            <el-col :span="24">
              <div class="grid-content bg-purple">
                <el-row v-for="c in compInfoLists" style="padding-bottom:20px;border-bottom:2px solid #dfe6ec">
                  <el-col :span="4">
                    <div class="grid-content bg-purple compItem">
                      <div class="title">公司信息:</div>
                      <div class="item-desc">
                        <dl class="item-desc-name">
                          <dd>企业名称：{{c.name}}</dd>
                          <dd>营业执照注册号：{{c.business.business_licence_number}}</dd>
                          <dd>营业执照副本：</dd>
                        </dl>
                      </div>
                      <div class="item-img">
                        <img v-if="c.business.business_licence_number_electronic" :src="c.business.business_licence_number_electronic">
                      </div>
                      <div>
                        <dd class="item-btn">
                          <el-button type="info" @click="showEditCompInfo(c)">编辑</el-button>
                          <!--<el-button type="info">添加</el-button>-->
                        </dd>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span="20">
                    <div class="grid-content bg-purple">
                      <div class="trademark-list">
                        <!--<table style="position: relative;overflow: hidden;box-sizing: border-box;width: 100%;max-width: 100%;background-color: #fff;border: 1px solid #dfe6ec;font-size: 14px;color: #1f2d3d;">
                            <tr>商标信息：</tr>
                            <tr style="background-color: #eef1f6;text-align: left;border: 1px solid #dfe6ec;height:40px;">
                              <td>agent：</td>
                              <td>intCls：</td>
                              <td>regNo：</td>
                            </tr>
                            <tr v-for="pat in c.tradeMarkInfo">
                              <td>{{pat.agent}}</td>
                              <td>{{pat.intCls}}</td>
                              <td>{{pat.regNo}}</td>
                              <td><el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button></td>
                              <td><el-button size="small" type="danger" @click="handleDelete(pat)">删除</el-button></td>
                            </tr>
                            <tr>专利信息：</tr>
                            <tr>
                              <td>patentName：</td>
                              <td>publicNoticeNo：</td>
                              <td>inventUser：</td>
                            </tr>
                            <tr v-for="tm in c.patentInfo">
                              <td>{{tm.patentName}}</td>
                              <td>{{tm.publicNoticeNo}}</td>
                              <td>{{tm.inventUser}}</td>
                              <td><el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button></td>
                              <td><el-button size="small" type="danger" @click="handleDelete(tm)">删除</el-button></td>
                            </tr>
                          </tbody>
                        </table>-->
                        <div class="title">商标信息: 
                          <a style="cursor:pointer;padding-left:10px;color:#20a0ff" @click="batchRemoveTm(0,c.tradeMarkInfo)" ><i class="el-icon-delete"></i>批量删除</a>
                          <a style="cursor:pointer;padding-left:10px;color:#20a0ff;" @click="addTmAsset(c)"><i class="el-icon-plus"></i>添加商标资产</a>
                        </div>
                        <el-table :data="c.tradeMarkInfo" highlight-current-row v-loading="listLoading" @selection-change="tmselectedsChange" style="width: 100%;" >
                          <el-table-column type="selection" width="55"></el-table-column>
                          <el-table-column prop="agent" label="代理公司" ></el-table-column>
                          <el-table-column prop="intCls" label="分类" ></el-table-column>
                          <el-table-column prop="regNo" label="注册号/专利号" ></el-table-column>
                          <el-table-column label="操作" >
                            <template scope="scope">
                              <el-button type="danger" size="small" @click="handleDel(0,scope.$index, scope.row)">删除</el-button>
                            </template>
                          </el-table-column>
                        </el-table>
                        <div class="title">专利信息:
                          <a style="cursor:pointer;color:#20a0ff;" class="delete" @click="batchRemovePt(1,c.patentInfo)"><i class="el-icon-delete"></i>批量删除</a>
                          <a style="cursor:pointer;padding-left:10px;color:#20a0ff;" @click="addPtAsset(c)"><i class="el-icon-plus"></i>添加专利资产</a>
                        </div>
                        <el-table :data="c.patentInfo" highlight-current-row v-loading="listLoading" @selection-change="ptselectedsChange" style="width: 100%;" >
                          <el-table-column type="selection" width="55"></el-table-column>
                          <el-table-column prop="patentName" label="专利名称" ></el-table-column>
                          <el-table-column prop="publicNoticeNo" label="公开公告号" ></el-table-column>
                          <el-table-column prop="inventUser" label="发明人" ></el-table-column>
                          <el-table-column label="操作" >
                            <template scope="scope">
                              <el-button type="danger" size="small" @click="handleDel(1,scope.$index, scope.row)">删除</el-button>
                            </template>
                          </el-table-column>
                        </el-table>
                      </div>
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
      <div v-else-if="compInfoExist=='add'" style="position:relative;">
        <el-form :model="addForm" :rules="addFormRules" ref="ruleForm" label-width="150px" class="demo-ruleForm">
          <el-form-item label="企业名称：" prop="company_name" class="wid500">
            <el-input v-model = "addForm.company_name"></el-input>
          </el-form-item>
          <el-form-item label="营业执照注册号：" prop="business_licence_number" class="wid500">
            <el-input v-model = "addForm.business_licence_number"></el-input>
          </el-form-item>
          <i class="warning picPos"></i><!--//192.168.1.123:8181/cnsebe-steward-web/FileController/uploadData.do-->
          <el-form-item label="营业执照副本：" class="wid500">
            <el-upload class="avatar-uploader" name="fileData" action="http://steward.cnsebe.com/FileController/uploadData.do" :show-file-list="false" :on-success="handleLicenceScucess" :before-upload="beforeLicenceUpload">
              <img v-if="addForm.business_licence_number_electronic" :src="addForm.business_licence_number_electronic" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="addComp('ruleForm')">添加</el-button>
            <el-button @click="cancel">取消</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!--编辑公司信息界面-->
      <el-dialog title="编辑公司信息" v-model="compInfoVisible" size="tiny">
        <el-form :model="editCompForm" :rules="editCompFormRules" ref="ruleForm" label-width="150px" class="demo-ruleForm">
          <el-form-item label="企业名称：" prop="company_name">
            <el-input v-model = "editCompForm.company_name"></el-input>
          </el-form-item>
          <el-form-item label="营业执照注册号：" prop="business_licence_number">
            <el-input v-model = "editCompForm.business_licence_number"></el-input>
          </el-form-item><!--//192.168.1.123:8181/cnsebe-steward-web/FileController/uploadData.do-->
          <el-form-item label="营业执照副本：" class="wid500">
            <el-upload class="avatar-uploader" name="fileData" action="http://steward.cnsebe.com/FileController/uploadData.do" :show-file-list="false" :on-success="handleLicenceScucess" :before-upload="beforeLicenceUpload">
              <img v-if="editCompForm.business_licence_number_electronic" :src="editCompForm.business_licence_number_electronic" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="editCompInfo('ruleForm')">修改</el-button>
          </el-form-item>
        </el-form>
      </el-dialog>

			<!--<div v-else-if="compInfoExist=='modify'">
			  <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" label-width="110px" class="demo-ruleForm">	
				  <el-form-item label="企业名称" class="wid350">
    				<el-input v-model="form.company_name" placeholder="请输入企业名称"></el-input>
  				</el-form-item>
          <el-form-item label="营业执照注册号" class="wid350">
            <el-input v-model="form.business_licence_number" placeholder="请输入营业执照注册号"></el-input>
          </el-form-item>
          <el-form-item label="所属行业" class="wid20">
            <el-select v-model="form.company_industry" placeholder="选择所属行业">
              <el-option v-for="item in company_industrys" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
  				<el-form-item label="注册地址">
    				<Address :province="ruleForm2.province" :city="ruleForm2.city" :county="ruleForm2.county" :addrDetail="ruleForm2.addrDetail" ></Address>
  				</el-form-item>
          <el-form-item label="详细地址" class="wid500">
            <el-input v-model="form.company_address"></el-input>
          </el-form-item>
  				<el-form-item label="公司营业执照" style="display:inline-block;margin-bottom:0px;" >
            <el-upload class="avatar-uploader" name="fileData" action="//192.168.1.117:8080/FileController/uploadData.do" :show-file-list="false" :on-success="handleLicenceScucess" :before-upload="beforeLicenceUpload">
                <img v-if="form.business_licence_number_electronic" :src="form.business_licence_number_electronic" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
				  </el-form-item>        
          <el-form-item style="margin-top:20px;">
            <el-tag type="danger">提示：</el-tag>
            <span style="color:#48576a;">涉及业务操作，请上传清晰的公司营业执照证明。图片小于20M,允许类型(jpg(RGB格式),png,bmp)</span>
          </el-form-item>
          <el-form-item label="法人姓名" class="wid350">
            <el-input v-model="form.owner_name" placeholder="请输入法人姓名"></el-input>
          </el-form-item>
          <el-form-item label="法人身份证" style="display:inline-block;margin-bottom:0px;" >
            <el-upload class="avatar-uploader" name="fileData" action="//192.168.1.117:8080/FileController/uploadData.do" :show-file-list="false" :on-success="handleIDCardScucess" :before-upload="beforeIDCardUpload">
                <img v-if="form.owner_identification_card" :src="form.owner_identification_card" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>        
          <el-form-item style="margin-top:20px;">
            <el-tag type="danger">提示：</el-tag>
            <span style="color:#48576a;">涉及业务操作，请上传清晰的公司营业执照证明。图片小于20M,允许类型(jpg(RGB格式),png,bmp)</span>
          </el-form-item>
          <el-form-item label="审核状态" class="wid20">
            <el-select v-model="form.selectedStatus" placeholder="选择审核状态">
              <el-option v-for="item in status" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
  				<el-form-item>
    				<el-button type="primary" @click="submitForm('ruleForm2')">提交认证</el-button>
  				</el-form-item>
			  </el-form>
			</div>-->
		</div>
	</section>
</template>

<script>
  import Vue from 'vue'
  import NProgress from 'nprogress'
  import 'nprogress/nprogress.css'
  import imgUpload from './imgUpload.vue'
  import AreaThreeLevelLinkage from './AreaThreeLevelLinkage.vue'
  import { getAllCompTmInfo, addCompanyInfo, editCompanyInfo, queryCompTmRely, addCompTmRely, deleteCompTmRely } from '../../api/api'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		components: {
 			AreaThreeLevelLinkage
 		},
		mounted(){},
 		props: { },
		data(){
			return{
        compInfoExist:'',
        compInfoExistBtn:'show',
        compInfoLists:[],
        patentInfoLists:[],
        tradeMarkInfoLists:[],
        listLoading:false,
        compInfoVisible:false,
        form: {
          company_name:'',
          business_licence_number:'',
          company_industry:'',
          company_address:'',
          business_licence_number_electronic:'',
          owner_name:'',
          owner_identification_card:'',
          selectedStatus:'',
          patentInfo:[],
          tradeMarkInfo:[],
        },
        selecteds: [],//列表选中列
        tmselecteds: [],//商标列表选中列
        ptselecteds: [],//专利列表选中列
        company_industrys: [
          {
            value: '1',
            label: '餐饮'
          }, 
          {
            value: '2',
            label: '互联网'
          }, 
          {
            value: '3',
            label: '家政'
          }
        ],
        status: [
          {
            value: '-1',
            label: '待审核'
          }, 
          {
          value: '1',
          label: '审核成功'
          }, 
          {
            value: '0',
            label: '审核失败'
          }
        ],
        addForm:{
          company_name:'',
          business_licence_number:'',
          business_licence_number_electronic:'',
        },
        addFormRules: {
          company_name: [
            { required: true, message: '请输入企业名称', trigger: 'blur' }
          ],
          business_licence_number:[
            { required: true, message: '请输入公司营业执照注册号', trigger: 'blur' }
          ]
        },
        editCompForm:{
          company_name:'',
          business_licence_number:'',
          business_licence_number_electronic:'',
          organization_id:'',
          pid:'',
        },
        editCompFormRules:{
          company_name: [
            { required: true, message: '请输入企业名称', trigger: 'blur' }
          ],
          business_licence_number:[
            { required: true, message: '请输入公司营业执照注册号', trigger: 'blur' }
          ]
        }

			}
		},
		methods:{
      //判断主子账号
      isParentAccount(){
        let user = JSON.parse(sessionStorage.getItem('user'));  
        if(user.parent.member_id==0){
          this.compInfoExistBtn='show';
        }else{
          this.compInfoExistBtn='';
        }
      },
      handleLicenceScucess(res, file) {
        //console.log(res);
        //console.log(file);
        this.addForm.business_licence_number_electronic = res.url;
        this.editCompForm.business_licence_number_electronic = res.url;
        //console.log(this.form.business_licence_number_electronic);
      },
      beforeLicenceUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';
        const isBMP = file.type === 'image/bmp';
        const isLt10M = file.size / 1024 / 1024 < 10;

        if (!isJPG && !isPNG && !isBMP) {
          this.$message.error('上传头像图片只能是 JPG,PNG或BMP 格式!');
        }

        if (!isLt10M) {
          this.$message.error('上传头像图片大小不能超过 10MB!');
        }
        return isJPG || isPNG || isBMP && isLt2M;
      },
      handleIDCardScucess(res, file) {
        //console.log(res);
        //console.log(file);
        this.form.owner_identification_card = res.url
        //console.log(this.form.owner_identification_card);
      },
      beforeIDCardUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';
        const isBMP = file.type === 'image/bmp';
        const isLt10M = file.size / 1024 / 1024 < 10;

        if (!isJPG && !isPNG && !isBMP) {
          this.$message.error('上传头像图片只能是 JPG,PNG或BMP 格式!');
        }

        if (!isLt10M) {
          this.$message.error('上传头像图片大小不能超过 10MB!');
        }
        return isJPG || isPNG || isBMP && isLt2M;
      },
      //获取所有公司和对应商标专利信息
      getAllCompData(){
        NProgress.start();
        getAllCompTmInfo().then((res) => {
          let { code } = res;
          //console.log(code);
          //console.log(res);
          //console.log(res.data);
          NProgress.done();           
          this.compInfoExist = 'show';
          //this.compInfoLists = res.data.elements;
          var getpatTradData;
          let patentInfo;
          let tradeMarkInfo; 
          var promiseFunc;
          //console.log(res);
          var elements = res.data.map(function(item){
              //同步
            /*  async function getpatTradData(){
                //console.log(item.organization_id); 
                let para = new URLSearchParams();
                let user = JSON.parse(sessionStorage.getItem("user"));
                para.append("memberId",user.member_id);
                para.append("companyinfoId",item.organization_id);
                //同步等待
                promiseFunc = await queryCompTmRely(para).then((res) => {
                  //console.log(res);
                  patentInfo = res.patentInfo;
                  tradeMarkInfo = res.tradeMarkInfo;
                  // console.log(patentInfo);
                  // console.log(tradeMarkInfo);
                  return res
                });
                console.log(promiseFunc);
              }
              console.log(getpatTradData());
            */
            //this.form.patentInfo = patentInfo;
            //this.form.tradeMarkInfo = tradeMarkInfo;

            /*var business = '';
            if(item.organizationDTO.business && item.organizationDTO.business != null){
              business = JSON.parse(item.organizationDTO.business);
            }else{
              business = '';
            }*/

            var business = '';
            if(item.organizationDTO.business === ''){
              business = '';
            }else{
              business = JSON.parse(item.organizationDTO.business);
            }

            return{
              organization_id:item.organizationDTO.organization_id,
              name:item.organizationDTO.name,
              business: business,//JSON.parse(item.organizationDTO.business)
              //patentInfo:getpatTradData().patentInfo,
              patentInfo:item.patentInfo,
              tradeMarkInfo:item.tradeMarkInfo,
              pid:item.organizationDTO.parent.organization_id,
            }
          });
          this.compInfoLists = elements;
          //console.log(this.compInfoLists);

          var pat = res.data.map(function(item){
            return item.patentInfo
          });
          var tm = res.data.map(function(item){
            return item.tradeMarkInfo
          });

          this.patentInfoLists = pat;
          this.tradeMarkInfoLists = tm;
          //console.log(this.compInfoLists);
          //console.log(this.patentInfoLists);
          //console.log(this.tradeMarkInfoLists);
          /*this.form.company_name = res.data.company_name;
          this.form.business_licence_number = res.data.business_licence_number;
          this.form.company_industry = res.data.company_industry;
          this.form.company_address = res.data.company_address;
          this.owner_name = res.data.owner_name;
          this.form.avatar = res.data.avatar; 
          this.form.nickName = res.data.nickname;
          this.form.trueName = res.data.truename;
          this.form.sex = res.data.sex;
          this.form.memberIdentificationCard = res.data.memberIdentificationCard;
          this.form.birthday = res.data.birthday;
          this.form.member_industry = res.data.member_industry;
          this.form.phone = res.data.phone;
          this.form.email = res.data.email;
          this.form.area_info = res.data.area_info;
          this.form.member_address = res.data.member_address;
          console.log(this.form);*/   
        });
      },
      //单个删除
      handleDel(type, $index, row){
        //console.log(type + " " + $index + " " + JSON.stringify(row));
        this.$confirm('确认删除该记录吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true;
          NProgress.start();
          /*let para = new URLSearchParams();
          para.append('idList',JSON.stringify(row.id));
          para.append('type',type);*/
          let para = { 
            'idList': JSON.stringify(row.id),
            'type': type,
          }
          deleteCompTmRely(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success'
            });
            this.getAllCompData();
          });
        }).catch(() => {

        });
      },
      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },
      //商标选中项
      tmselectedsChange: function (selection) {
        this.tmselecteds = selection;
        //console.log(this.selecteds);
      },
      //专利选中项
      ptselectedsChange: function (selection) {
        this.ptselecteds = selection;
        //console.log(this.selecteds);
      },
      //批量删除
      batchRemove: function (type) {
        var ids = this.selecteds.map(item => item.id).toString();
        /*var ids = this.selecteds.map(function(item){
          return item.id
        });*/
        //console.log(ids);
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择删除项'
          });
          return false;
        }else{ 
          this.$confirm('确认删除选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('idList', ids);
            para.append('type',type);*/
            let para = { 
              'idList': JSON.stringify(ids),
              'type': type,
            }
            deleteCompTmRely(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '删除成功',
                type: 'success'
              });
              this.getAllCompData();
            });
          }).catch(() => {
          });
        }
      },

      //商标批量删除
      batchRemoveTm: function (type,tradeMarkInfo) {
        //console.log(tradeMarkInfo);
        var ids = this.tmselecteds.map(item => item.id).toString();
        /*var ids = this.selecteds.map(function(item){
          return item.id
        });*/
        //console.log(ids);
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择需要删除的商标项'
          });
          return false;
        }else{ 
          this.$confirm('确认删除选中商标记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('idList', ids);
            para.append('type',type);*/
            let para = { 
              'idList': ids,
              'type': type,
            }
            deleteCompTmRely(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '商标资产删除成功',
                type: 'success'
              });
              this.getAllCompData();
            });
          }).catch(() => {
          });
        }
      },

      //专利批量删除
      batchRemovePt: function (type,patentInfo) {
        //console.log(patentInfo);
        var ids = this.ptselecteds.map(item => item.id).toString();
        /*var ids = this.selecteds.map(function(item){
          return item.id
        });*/
        //console.log(ids);
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择需要删除的专利项'
          });
          return false;
        }else{ 
          this.$confirm('确认删除选中专利记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('idList', ids);
            para.append('type',type);*/
            let para = { 
              'idList': ids,
              'type': type,
            }
            deleteCompTmRely(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '专利资产删除成功',
                type: 'success'
              });
              this.getAllCompData();
            });
          }).catch(() => {
          });
        }
      },

      //添加公司
      addCompInfo(){
        this.compInfoExist = 'add';
        this.compInfoExistBtn='';
        this.addForm = {
          company_name:'',
          business_licence_number:'',
          business_licence_number_electronic:'',
        }
      },
      addComp(formName){ 
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if(!this.addForm.business_licence_number_electronic){
              this.$notify.info({
                title: '警告',
                message: '请上传营业执照副本'
              });
              return false;
            }else{
              this.$confirm('确认添加公司信息吗?', '提示', {
                type: 'warning'
              }).then(() => {
                this.listLoading = true;
                NProgress.start();
                /*let para = new URLSearchParams();
                para.append('company_name',this.addForm.company_name);
                para.append('business_licence_number',this.addForm.business_licence_number);
                para.append('business_licence_number_electronic', this.addForm.business_licence_number_electronic);
                let orgId = JSON.parse(sessionStorage.getItem("user")).organization_id;
                let organization_id = '';
                if(orgId = 0){
                  organization_id = 1
                }else{
                  organization_id = 0
                }
                para.append('key', organization_id);*/
                let orgId = JSON.parse(sessionStorage.getItem("user")).organization_id;
                let organization_id = '';
                if(orgId = 0){
                  organization_id = 1
                }else{
                  organization_id = 0
                }
                let para = { 
                  'company_name': this.addForm.company_name,
                  'business_licence_number': this.addForm.business_licence_number,
                  'business_licence_number_electronic': this.addForm.business_licence_number_electronic,
                  'key': organization_id,
                }
                addCompanyInfo(qs.stringify(para)).then((res) => {
                  this.listLoading = false;
                  NProgress.done();

                  if(res.code==10093 || res.code==1010012 || res.code==1010011){
                    this.$notify({
                      title: '添加失败',
                      message: res.desc,
                      type: 'error'
                    });
                  }else{
                    this.$notify({
                      title: '成功',
                      message: '添加成功',
                      type: 'success'
                    });
                  }  

                this.compInfoExist = 'show';
                this.compInfoExistBtn='show';
                this.getAllCompData();
              });
              }).catch(() => {
              });
            }
          }
        });
      },
      //取消
      cancel(){
        this.compInfoExist = 'show';
        this.compInfoExistBtn='show';
      },
      //重置
      reset(formName) {
        this.$refs[formName].resetFields();
      },
      //单条公司信息
      showEditCompInfo(compInfo){
        this.compInfoVisible = true;
        //console.log(compInfo);
        this.editCompForm.company_name = compInfo.name;
        this.editCompForm.business_licence_number = compInfo.business.business_licence_number;
        this.editCompForm.business_licence_number_electronic = compInfo.business.business_licence_number_electronic;
        this.editCompForm.organization_id = compInfo.organization_id;
        this.editCompForm.pid = compInfo.pid;
      },
      //编辑公司信息
      editCompInfo(formName){
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if(!this.editCompForm.business_licence_number_electronic){
              this.$notify.info({
                title: '警告',
                message: '请上传营业执照副本'
              });
              return false;
            }else{
              this.$confirm('确认修改公司信息吗?', '提示', {
                type: 'warning'
              }).then(() => {
                this.listLoading = true;
                NProgress.start();
                /*let para = new URLSearchParams();
                para.append('company_name',this.editCompForm.company_name);
                para.append('business_licence_number',this.editCompForm.business_licence_number);
                para.append('business_licence_number_electronic', this.editCompForm.business_licence_number_electronic);
                para.append('organization_id', this.editCompForm.organization_id);
                let key = '';
                if(this.editCompForm.pid = 0){
                  key = 1;
                }else{
                  key = 0;
                }
                para.append('key', key);*/

                let key = '';
                if(this.editCompForm.pid = 0){
                  key = 1;
                }else{
                  key = 0;
                }
                let para = { 
                  'company_name': this.editCompForm.company_name,
                  'business_licence_number': this.editCompForm.business_licence_number,
                  'business_licence_number_electronic':this.editCompForm.business_licence_number_electronic,
                  'organization_id':this.editCompForm.organization_id,
                  'key':key
                }
                editCompanyInfo(qs.stringify(para)).then((res) => {
                  this.listLoading = false;
                  NProgress.done();
                  if(res.code==10093){
                    this.$notify({
                      title: '修改失败',
                      message: res.error,
                      type: 'error'
                    });
                  }else{
                    this.$notify({
                      title: '成功',
                      message: '修改成功',
                      type: 'success'
                    });
                  }  
                this.getAllCompData();
                this.compInfoVisible = false;
              });
              }).catch(() => {
              });
            }
          }
        });
      },
      //添加商标资产
      addTmAsset(compInfo){
        //console.log(compInfo);
        this.$router.push({ name: 'addTmCompRely', params:{organization_id:compInfo.organization_id} });

      },
      //添加专利资产
      addPtAsset(compInfo){
        //console.log(compInfo);
        this.$router.push({ name: 'addPtCompRely', params:{organization_id:compInfo.organization_id} });
      }
		},
    mounted(){
      this.getAllCompData(); 
      this.isParentAccount();
    }
	}

</script>

<style scoped lang="scss">
  .warning:before {content: '*';color: #ff4949;margin-right: 4px;}
  *>.picPos{position:absolute;left: 25px;top: 150px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.picPos{position:absolute;left: 25px;top: 125px;}}
	.wid200{width:200px;}
	.wid350{width:350px;}
  .wid500{width:500px;}
  .authInfo{
    padding:10px;
    .authInfo-title{
  		color: #48576a;
    	line-height: 1;
    	padding: 15px 12px 15px 0;
  		vertical-align: middle;
  		font-size: 18px;
    	font-weight: 600;
  	}
    .authInfo-add{
      padding:10px 0px;
      .authInfo-list{
        padding:20px 0px;
        .compItem{
          height: 360px;
          margin-bottom: 14px;
          background-color: #f2f2f2;
          .title{
            text-align:left;
            color: #20a0ff;
            font-size: 16px;
            padding:10px 0px ;
            background-color:#f2f2f2;
            height: 35px;
          }
          .item-img{
            position: relative;
            width: 100%;
            height: 218px;
            text-align: left;
            overflow: hidden;
            img{
              width: 80%;
            }
          }
          .item-desc{
            border-top: 1px solid #eee;
            .item-desc-name{
              font-size: 14px;
              float: left;
              width: 100%;
              text-align: center;
              color:#48576a;
              dd{
                text-align: left;
              }
            }
          }
          .item-btn{
            text-align:right;
            margin-right:40px;
            margin-top:10px;
            float: right;
            margin-right: 20%;
          }
        }
        .trademark-list{
          .title{
            color: #20a0ff;
            font-size: 16px;
            padding:10px 0px ;
            background-color:#f2f2f2;
            height: 35px;
          }
          .operate{
            padding-bottom:10px;
            .delete{
              margin-right: 20px;
              color: #20a0ff;
              font-size: 14px;
              cursor: pointer;
            }
          }
        }
      }
    }
    .authInfo-authObj{
	   	margin-bottom: 22px;
			.authObj-label:before{
				content:"*";
				color: red;
				margin-right: 4PX;
			}
			.authObj-label{
				text-align: right;
    		vertical-align: middle;
    		float: left;
    		font-size: 14px;
  			color: #48576a;
      	line-height: 1;
    		padding: 11px 12px 11px 46px;
    		box-sizing: border-box;
    		cursor: pointer;
			}
			.authObj-item{
				margin-left: 100px;
			  line-height: 36px;
    		position: relative;
    		font-size: 14px;
			}			
  		.authInfo-idImg{
  			position:relative;
			.authInfo-icon-position{
			  position: absolute;
    		top: 38%;
    		left: 46%;
    		color: red;
    		font-size: 21px;
			}
  	}
  	}
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 200px;
    height: 160px;
    line-height: 160px;
    text-align: center;
  }
  .frontImg{
    background-image:url(../../assets/images/front.png);
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
