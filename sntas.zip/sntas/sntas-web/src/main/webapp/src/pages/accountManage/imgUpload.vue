<template>
  <div class='finish_room'>    
      <div class='finish_room2'>
         <div class='room_img'>
            <img :src="img">
          </div> 
          <div class='room_add_img'>
            <el-button type="info">编辑头像</el-button>
            <input @change='add_img' :value="img" type="file" >
          </div>
       </div>
  </div>
</template>

<script>
import Vue from 'vue'
export default {
  props: [],
  data() {
    return {
      img:"",
    }
  },
  mounted () {
    
  },
  methods: {
    add_img(event){
      var reader =new FileReader();
      var img1=event.target.files[0];                 
      reader.readAsDataURL(img1);
      var that=this;
      reader.onloadend=function(){
        that.img = reader.result
      }
      //this.$emit('addImg', this.img);
      //console.log(this.img.name);
    }
  }
}
</script>

<style scoped>
  .finish_room{
      width: 200px;
      height: 200px
  }

     .finish_room2{
     width: 100%;
     height: auto;
     padding-top: 15px;
     padding-bottom: 15px;
     display: flex;
     align-items: center;
   }
    
   .finish_room2 .room_img{
     width: 136px;
     height: 136px;
     border-radius: 70px;
     margin-right: 10px;
     position: relative;
     overflow: hidden;
   }
   .finish_room2 .room_img img{
     
     width: 100%;
     height: 100%;
   }
   .finish_room2>.room_img span{
      position: absolute;
      width: auto;
      height: auto;
      right: 5px;
      bottom:3px;
   }
   .room_add_img{
        position: absolute;
    top: 160px;
    left: 25px;
   }
  .room_add_img input{
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
      height: 100%;
      z-index: 99999;
      opacity: 0;
  }
</style>