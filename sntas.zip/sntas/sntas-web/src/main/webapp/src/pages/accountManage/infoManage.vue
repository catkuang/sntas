<template>
	<section>
		<div class="title">
			<span class="box">收件箱</span>
			<span>共<span style="color:red;"> {{totalCount}} </span>封</span><!--, 其中<span class="unread">未读邮件</span>封-->
		</div>
		<div class="operate">
			<a class="delete" @click="batchRemove" :disabled="this.selecteds.length===0"><i class="el-icon-delete"></i>批量删除</a>
      <a class="delete" @click="batchReadedMark" :disabled="this.selecteds.length===0"><i class="el-icon-edit"></i>批量标记为已读</a>
		</div>
		<el-table :data="msgListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 95%;margin-left:10px;">
			<el-table-column type="selection" width="55">
			</el-table-column>
			<el-table-column width="30">
      			<template scope="scope">
        			<el-icon v-if="scope.row.state==0" name="message" style="color:#20a0ff;"></el-icon>
      			</template>
    		</el-table-column>
			<el-table-column prop="scope" label="标题内容">
        <template scope="scope">
          <span @click="seeMsg(scope.$index, scope.row)" :class="{ unreaded: scope.row.state==0 }">{{ scope.row.content}}</span>
        </template>
			</el-table-column>
			<el-table-column scope="scope" label="时间" >
				<template scope="scope">
        	<span @click="seeMsg(scope.$index, scope.row)" :class="{ unreaded: scope.row.state==0 }">{{ scope.row.create_time | dateFormat}}</span>
      	</template>
			</el-table-column>
			<!--<el-table-column prop="state" label="消息状态" min-width="100">
			</el-table-column>-->
			<el-table-column label="操作" width="200">
				<template scope="scope">
          <el-button size="small" type="info" @click="seeMsg(scope.$index, scope.row)">查看</el-button>
					<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
				</template>
			</el-table-column>
		</el-table>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>

    <!--消息详情-->
    <el-dialog title="消息详情" v-model="msgVisible" size="tiny">
     <span>{{msgDetail.content}}</span>
     <span>{{msgDetail.create_time | dateFormat}}</span>
      <!--<span slot="footer" class="dialog-footer">
        <el-button @click="msgVisible = false">取 消</el-button>
        <el-button type="primary" @click="msgVisible = false">确 定</el-button>
      </span>-->
    </el-dialog>
	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { getMsgList, deleteMsg, setMsgRead, getMsgDetail } from '../../api/api';
  import filters from '../../api/filters'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data() {
			return {
				listLoading:false,
				msgListData:[],
				has_previous:false,
				has_next:false,
				index:'',
				currentPage:1,
        totalPages:1,//总页数
        totalCount:null,//总条数
        selecteds: [],//列表选中列
        msgVisible:false,
        msgDetail:''
			}
		},
		methods: {
			//获取消息列表
			getMsgListData(){
				this.listLoading = true;
        /*let para = new URLSearchParams();
        para.append('pageNo',this.currentPage);
        para.append('pageSize',20);*/   
        let para = { 
          'pageNo':this.currentPage,
          'pageSize':20
        }

        NProgress.start();
        getMsgList(qs.stringify(para)).then((res) => {
          let { code } = res;
          //console.log(code);
          //console.log(res);
          NProgress.done();
          if(code != 0){
            alert("网络异常");
          }else{    
          	this.listLoading = false;
          	this.msgListData = res.data.elements;
          	this.has_previous = res.data.has_previous;
          	this.has_next = res.data.has_next;
          	this.totalPages = res.data.total_pages;//总页数
          	this.totalCount = res.data.total_elements;//总条数
            this.currentPage = res.data.index;//当前页
          }    
        }); 
      },

      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getMsgListData();
      },
      //单个删除
      handleDel($index, row){
        //console.log($index + " " + JSON.stringify(row));
        this.$confirm('确认删除该消息吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true;
          NProgress.start();
				  /*let para = new URLSearchParams();
          para.append('messageIds', JSON.stringify(row.message_id));*/

          let para = { 
            'messageIds': JSON.stringify(row.message_id),
          }

          deleteMsg(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success'
            });
            for(var i=0; i < this.msgListData.length; i++){
              if(i == $index){
                this.msgListData.splice(i,1);
                return;
              }
            }
          });
        }).catch(() => {
       	});
      },

      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },

      //删除指定项
      removeByValue:function(arr, val) {
  			for(var i=0; i<arr.length; i++) {
    			if(arr[i] == val) {
      			arr.splice(i, 1);
      			break;
    			}
    		}	
  		},

      //批量删除
      batchRemove: function () {    
      	var messageIds = this.selecteds.map(item => item.message_id).toString();
        if(!messageIds){
          this.$notify.info({
            title: '警告',
            message: '请选择删除项'
          });
          return false;
        }else{
          this.$confirm('确认删除选中的消息吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('messageIds', messageIds);*/
            let para = { 
              'messageIds': messageIds,
            }
            deleteMsg(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '删除成功',
                type: 'success'
              });
              for(var i=0; i < this.selecteds.length; i++){
                this.removeByValue(this.msgListData, this.selecteds[i]);
              }               
            });
          }).catch(() => {
          });
        }
      },

      //批量标记消息为已读
      batchReadedMark(){
        var messageIds = this.selecteds.map(item => item.message_id).toString();
        if(!messageIds){
          this.$notify.info({
            title: '警告',
            message: '请选择需要标记消息'
          });
          return false;
        }else{
          this.$confirm('确认标记选中的消息为已读吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('messageIds', messageIds);*/

            let para = { 
              'messageIds': messageIds,
            }

            setMsgRead(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '标记成功',
                type: 'success'
              });
              this.getMsgListData();             
            });
          }).catch(() => {
          });
        }
      },

      //获取消息详情
      seeMsg($index, row){
        this.msgVisible = true;
        //获取消息详情
        /*let para = new URLSearchParams();
        para.append('messageId', row.message_id);*/

        let para = { 
          'messageId': row.message_id,
        }
        getMsgDetail(qs.stringify(para)).then((res) => {
          this.msgDetail = res.data;
          this.readMark($index, row);
        });
      },
      //单条标记为已读  
      readMark($index,row){
        /*let para = new URLSearchParams();
        para.append('messageIds', JSON.stringify(row.message_id));*/

        let para = { 
          'messageIds': row.message_id,
        }
        setMsgRead(qs.stringify(para)).then((res) => {
          this.$notify({
            title: '成功',
            message: '已读',
            type: 'success'
          });
          this.getMsgListData();    
        });
      } 

		},
    filters: {
      dateFormat : filters.formatDate.dateFormat
    },
		mounted() {
			this.getMsgListData();
		}
	}

</script>

<style scoped lang="scss">
	.title{
		color: #48576a;
    	line-height: 1;
    	vertical-align: middle;
    	font-size: 16px;
    	padding:10px;
      width: 200px;
      background-color:#f2f2f2;
      height: 20px;
		.box {
			font-size: 18px;
      font-weight: 500;
      color: #000;
		}
		.unread{
			color: #20a0ff;
		}
	}
	.operate{
    	padding:10px;
    	a{
			margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
      		cursor: pointer;
    	}
  }
  .unreaded{
    font-weight: 600;
  }
  .readed{
    font-weight: 300;
  }
  #pagenation{
    padding:20px 70px 50px;
    text-align: right;
  }
</style>