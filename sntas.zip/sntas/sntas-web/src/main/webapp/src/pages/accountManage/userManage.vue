<template>
	<section>
    <div class="userMg">
      <div class="userMg-title">用户管理</div>
    </div> 
		<div class="operate">
      <el-button type="info" icon="plus" @click="showAddUser" v-if="userInfoExistBtn">添加新用户</el-button>
		</div>
		<div class="user-list">
			<el-table :data="userListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;">
				<!--<el-table-column type="selection" width="55"></el-table-column>-->
				<el-table-column type="index" label="序号" width="100"></el-table-column>
				<el-table-column prop="truename" label="用户名"></el-table-column>
        <el-table-column prop="nickname" label="昵称"></el-table-column>
        <el-table-column prop="area_info" label="地址"></el-table-column>
				<el-table-column prop="phone" label="手机号"></el-table-column>
				<el-table-column prop="type" label="会员类型"></el-table-column>
        <el-table-column prop="grade_id" label="会员等级" ></el-table-column>
				<el-table-column label="操作" width="285" align="center">
					<template scope="scope">
						<!--<el-button size="small" type="info" @click="seeUserInfo(scope.$index, scope.row)">查看</el-button>-->
            <el-button size="small" type="info" @click="editUserInfo(scope.$index, scope.row)">编辑</el-button>
            <el-button size="small" type="info" @click="getUserMemberLevelData(scope.$index, scope.row)">升级</el-button>
						<!--<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>-->
            <el-switch v-model="scope.row.status" on-text="冻结" off-text="解冻" on-color="#ff4949" off-color="#13ce66" @change="chgState(scope.$index, scope.row)"></el-switch>
					</template>
				</el-table-column>
			</el-table>
		</div>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>

    <!--查看用户信息-->
    <el-dialog title="用户信息详情" v-model="userInfoVisible">
      <table class="userDetail">
        <tr>
          <td>用户id：</td>
          <td>{{userInfo.member_id}}</td>
          <td>等级id：</td>
          <td>{{userInfo.grade_id}}</td>
          <td>手机号：</td>
          <td>{{userInfo.phone}}</td>          
          <td>状态：</td>
          <td>{{userInfo.status}}</td><!--1.开启，0.关闭-->
        </tr>
        <tr>
          <td>会员类型：</td>
          <td>{{userInfo.type}}</td><!--1.开启，0.关闭-->
          <td>行业：</td>
          <td>{{userInfo.member_industry}}</td>
          <td>登录次数：</td>
          <td>{{userInfo.login_num}}</td>
          <td>提醒方式：</td>
          <td>{{userInfo.remind}}</td>
        </tr>
        <tr>
          <td>来源渠道(首次)：</td>
          <td>{{firstChannel.name}}</td>
          <td>会员住址：</td>
          <td colspan="5">{{userInfo.member_address}}</td>
        </tr>
        <tr>
          <td>创建时间：</td>
          <td>{{userInfo.create_time}}</td>
          <td>登录时间：</td>
          <td>{{userInfo.login_time}}</td>
          <td>更新时间：</td>
          <td>{{userInfo.update_time}}</td>
          <td>组织根id</td>
          <td>{{organization.organization_id}}</td>
        </tr>
      </table>
    </el-dialog>

    <!--编辑用户信息-->
    <el-dialog title="用户信息编辑" v-model="userEditVisible" size="tiny">
      <el-form :rules="editFormRules" ref="ruleForm" :model="editForm" label-width="100px">
        <el-form-item label="所属公司" prop="org_id">
          <el-select v-model="editForm.org_id" placeholder="选择所属公司">
            <el-option v-for="item in editForm.orgsInfo" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="姓名" prop="truename">
          <el-input v-model="editForm.truename" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="editForm.nickname" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="editForm.phone" style="width:62%"></el-input>
          <el-button type="info" @click="getCode" :disabled="vali">{{codeTxt}}</el-button>
        </el-form-item>
        <el-form-item label="验证码"><!--prop="code"--><!--@blur="codeValidate"-->
          <el-input v-model="editForm.code" style="width:90%" ></el-input>
          <span class="valiMsg">{{valiMsg}}</span>
        </el-form-item>
        <el-form-item label="电子邮箱" prop="email">
          <el-input v-model="editForm.email" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="联系地址" prop="area_info">
          <el-input v-model="editForm.area_info" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="password">
          <el-input type="password" v-model="editForm.password" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="new_password">
          <el-input type="password" v-model="editForm.new_password" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="editUser('ruleForm')">修改</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <!--添加新用户-->
    <el-dialog title="添加新用户" v-model="userAddVisible" size="tiny">
      <el-form :rules="addFormRules" ref="ruleForm" :model="addForm" label-width="100px">
        <i class="warning compPos"></i>
        <el-form-item label="所属公司" prop="org_id">
          <el-select v-model="addForm.org_id" placeholder="选择所属公司">
            <el-option v-for="item in addForm.orgsInfo" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="姓名" prop="truename">
          <el-input v-model="addForm.truename" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="addForm.nickname" style="width:90%"></el-input>
        </el-form-item>
        <i class="warning phonePos"></i>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="addForm.phone" style="width:62%"></el-input>
          <el-button type="info" @click="addUserGetCode" :disabled="addVali">{{addCodeTxt}}</el-button>
        </el-form-item>
        <!--<i class="warning codePos"></i>-->
        <el-form-item label="验证码"><!--prop="code"--><!--@blur="addUserCodeValidate"-->
          <el-input v-model="addForm.code" style="width:90%" ></el-input>
          <span class="valiMsg">{{addValiMsg}}</span>
        </el-form-item>
        <i class="warning emailPos"></i>
        <el-form-item label="电子邮箱" prop="email">
          <el-input v-model="addForm.email" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item label="联系地址" prop="area_info">
          <el-input v-model="addForm.area_info" style="width:90%"></el-input>
        </el-form-item>
         <i class="warning newPwdPos"></i>
        <el-form-item label="新密码" prop="password">
          <el-input type="password" v-model="addForm.password" style="width:90%"></el-input>
        </el-form-item>
        <i class="warning confirmPwdPos"></i>
        <el-form-item label="确认密码" prop="new_password">
          <el-input type="password" v-model="addForm.new_password" style="width:90%"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="addUser('ruleForm')">立即添加</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <!--会员升级-->
    <el-dialog title="会员升级" v-model="memberLevelUpdateVisible" size="tiny" >  
      <div style="text-align:center;">
        <el-select v-model="gradeId" placeholder="请选择">
        <el-option v-for="m in memberData" :label="m.memberGradeName" :value="m.memberGradeId">
        </el-option>
      </el-select>    
      <el-button type="info" @click="update(gradeId)">立即升级</el-button>
      </div>
    </el-dialog>

	</section>
</template>

<script>
  import axios from 'axios';
  import qs from 'qs';
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { getAllUsersInfo, getUserInfoDetail, addUserInfo, editUserInfo, chgUserState, getAllCompanyInfo,getPhoneCode,validatePhoneCode,valiFirstTime,getMemberLevel,memberUpdate } from '../../api/api';
  import filters from '../../api/filters'
  import URLSearchParams from 'url-search-params'
	export default {
		data(){
      //手机号码验证
      let checkPhone = (rule, value, callback) => {
        let reg = /^(13[0-9]|17[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|16[4]|18[0-9])\d{8}$/;
        if (!value) {
          return callback(new Error('手机号不能为空'));
        }
        setTimeout(() => {
          if (!reg.test(value)) {
            callback(new Error('手机号格式错误'));
          } else {
            callback();
          }
        }, 1000);
      };
      //验证码验证
      let checkCode = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('验证码不能为空'));
        }
        setTimeout(() => {  
          //var code = this.validateCode();
          //console.log(code);
          //返回Promise解析
          var code = '';
          Promise.resolve(this.validateCode()).then(function(onFulfilled, onRejected){
            //console.log(onFulfilled);
            code = onFulfilled;
            if(code == 200){
              callback(new Error('验证码错误'));
            }else if(code == 0){
              callback();
            }
          });
        }, 1000);
      };
      //邮箱验证
      let checkEmail = (rule, value, callback) =>{
        let emailReg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!value) {
          return callback(new Error('邮箱不能为空'));
        }
        setTimeout(() => {
          if (!emailReg.test(value)) {
            callback(new Error('邮箱格式错误'));
          } else {
            callback();
          }
        }, 1000);
      }
      //新密码验证
      var checkPass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.editForm.password !== '') {
            this.$refs.editForm.validateField('new_password');
          }else{
            callback();
          }        
        }
      };
      //确认密码验证
      var checkPass2 = (rule, value, callback) => {
        if (this.editForm.password !== '' && value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.editForm.password) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
      //添加新用户新密码验证
      var addUserCheckPass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.addForm.new_password !== '') {
            this.$refs.ruleForm.validateField('new_password');
          }
          callback();        
        }
      };
      //添加新用户确认密码验证
      var addUserCheckPass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.addForm.password) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };

			return{
        userInfoExistBtn:'show',
        listLoading:false,
				userListData: [],
				currentPage:1,
        totalPages:1,//总页数
        totalCount:null,//总条数
        listLoading:false,
        userInfoVisible:false,
        userEditVisible:false,
        userAddVisible:false,
        memberLevelUpdateVisible:false,
        userInfo:'',
        firstChannel:'',
        organization:'',
        addForm:{
          org_id:'',
          orgsInfo:[],
          truename:'',
          nickname:'',
          phone:'',
          code:'',
          email:'',
          area_info:'',
          password:'',
          new_password:'',
        },
        addFormRules:{
          org_id: [
            //{ required: true, message: '请选择所属公司', trigger: 'change' }
          ],
          truename:[
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          nickname:[
            { required: true, message: '请输入昵称', trigger: 'blur' }
          ],
          phone: [
            { validator:checkPhone, trigger: 'blur' }
          ],
          code: [
            { validator:checkCode, trigger: 'blur' }
          ],
          email:[
            { validator:checkEmail, trigger: 'blur' }
          ],
          area_info:[
            { required: true, message: '请输入联系地址', trigger: 'blur' }
          ],
          password:[
            { validator:addUserCheckPass, trigger: 'blur' }
          ],
          new_password:[
            { validator:addUserCheckPass2, trigger: 'blur' }
          ],
        },
        editForm:{
          org_id:'',
          member_id:'',
          orgsInfo:[],
          truename:'',
          nickname:'',
          phone:'',
          code:'',
          email:'',
          area_info:'',
          password:'',
          new_password:'',
        },
        editFormRules:{
          org_id: [
            //{ required: true, message: '请选择所属公司', trigger: 'change' }
          ],
          truename:[
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          nickname:[
            { required: true, message: '请输入昵称', trigger: 'blur' }
          ],
          phone: [
            { validator:checkPhone, trigger: 'blur' }
          ],
          code: [
            { validator:checkCode, trigger: 'blur' }
          ],
          email:[
            { validator:checkEmail, trigger: 'blur' }
          ],
          area_info:[
            { required: true, message: '请输入联系地址', trigger: 'blur' }
          ],
          password:[
            //{ validator:checkPass, trigger: 'blur' }
          ],
          new_password:[
            //{ validator:checkPass2, trigger: 'blur' }
          ],
        },
        code:'',
        codeTxt:'获取验证码',
        addCodeTxt:'获取验证码',
        addValiMsg:'',
        vali:false,
        addVali:false,
        valiMsg:'',
        valiCode:'',
        memberData:'',
        grade_id:'',
        member_id:'',
        gradeId:'',
        status:null
			}
		},
		methods:{
      //判断主子账号
      isParentAccount(){
        let user = JSON.parse(sessionStorage.getItem('user'));  
        if(user.parent.member_id==0){
          this.userInfoExistBtn='show';
        }else{
          this.userInfoExistBtn='';
        }
      },

			//查询所有用户(子账号)信息
      getUserListsData(){
				this.listLoading = true;
        /*let para = new URLSearchParams();
        para.append('pg_index',this.currentPage);
        para.append('pg_count',20); */

        let para = { 
          'pg_index': this.currentPage,
          'pg_count': 20,
        }    

				NProgress.start();
				getAllUsersInfo(qs.stringify(para)).then((res) => {
          //console.log(res);
					this.userListData = res.data.elements;
          this.totalPages = res.data.total_pages;//总页数
          this.totalCount = res.data.total_elements;//总条数
          this.currentPage = res.data.index;//当前页
          this.listLoading = false;
					NProgress.done();
		    });
      },

      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getUserListsData();
      },

      //查询单个用户(子账号)信息,详情
      seeUserInfo($index, row){
        this.userInfoVisible = true;
        let para = {
          member_id:row.member_id,
        };
        this.listLoading = true;
        NProgress.start();
        getUserInfoDetail(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.userInfo = res.data;
          this.firstChannel = res.data.firstChannel;
          this.organization = res.data.organization;
          this.listLoading = false;
          NProgress.done();
        });
      },

      //编辑用户(子账号)信息
      editUserInfo($index, row){
        this.userEditVisible = true;
        this.valiMsg = '';
        //所属公司
        getAllCompanyInfo().then((res) => {
          //console.log(res.data);
          this.editForm.orgsInfo = res.data.elements.map(function(item){
            return {
              id:item.organization_id,
              name:item.name
            }       
          });
          //console.log(JSON.stringify(this.addForm.orgsInfo));
        }); 
        //console.log(row);//organization.organization_id
        this.editForm.org_id = row.memberOrganizationId;
        this.editForm.member_id = row.member_id;
        this.editForm.truename = row.truename;
        this.editForm.nickname = row.nickname;
        this.editForm.phone = row.phone;
        this.editForm.email = row.email;
        this.editForm.area_info = row.area_info;
        //this.editForm.password = row.password;
        //this.editForm.new_password = row.password;
      },

      //获取验证码
      getCode(){
        /*let para = new URLSearchParams();
        para.append('phone',this.editForm.phone);*/

        let para = { 
          'phone': this.editForm.phone,
        }
        getPhoneCode(qs.stringify(para)).then((res) => {
          //console.log(res);
          let second = 60;
          let timePromise = setInterval(() =>{
            if(second<=0){
                clearInterval(timePromise);
                second = 60;
                this.codeTxt = "重发验证码";
                this.vali = false;
              }else{
                this.vali = true;
                this.codeTxt = second + "秒后可重发";
                second--;
              }
          },1000)
        })
      },

      //验证验证码(同步等待)
      async validateCode(){
          /*let para = new URLSearchParams();
          para.append('phone',this.editForm.phone);
          para.append('validate',this.editForm.code);*/

          let para = { 
            'phone': this.editForm.phone,
            'validate': this.editForm.code,
          }
          var promiseFunc = await validatePhoneCode(qs.stringify(para)).then((res) => {
            return res.code;
            //console.log("test1:" + this.code);
          });
          return promiseFunc;
          //console.log(promiseFunc);
          //console.log("test2:" + this.code);
          //return this.code;}    
      },

      //验证验证码(独立)
      codeValidate(){
        if(!this.editForm.code){
          this.valiMsg = "验证码不能为空";
        }else{
          /*let para = new URLSearchParams();
          para.append('phone',this.editForm.phone);
          para.append('validate',this.editForm.code);*/

          let para = { 
            'phone': this.editForm.phone,
            'validate': this.editForm.code,
          }
          validatePhoneCode(qs.stringify(para)).then((res) => {
            if(res.code = 0){
              this.valiMsg = '';
              this.valiCode = 0;
            }else{
              this.valiMsg = res.msg;
              this.valiCode = '';
            }
          });
        }
      },

      //修改
      editUser(formName){
        //if(this.valiCode === 0){
          this.$refs[formName].validate((valid) => {
            if (valid) {
            this.$confirm('确认修改该用户吗?', '提示', {
              type: 'warning'
            }).then(() => {
              //this.listLoading = true;
              NProgress.start();
              /*let para = new URLSearchParams();
                para.append('member_id', this.editForm.member_id);
                para.append('org_id', this.editForm.org_id);
                para.append('body', JSON.stringify({             
                    truename:this.editForm.truename,
                    nickname:this.editForm.nickname,
                    phone:this.editForm.phone,
                    email:this.editForm.email,
                    area_info:this.editForm.area_info,
                    password:this.editForm.password,
                    new_password:this.editForm.new_password,
                  })           
                );*/
              let para = { 
                'member_id': this.editForm.member_id,
                'org_id': this.editForm.org_id,
                'truename':this.editForm.truename,
                'nickname':this.editForm.nickname,
                'phone':this.editForm.phone,
                'validate':this.editForm.code,
                'email':this.editForm.email,
                'area_info':this.editForm.area_info,
                'password':this.editForm.password,
                'new_password':this.editForm.new_password,
              }

              editUserInfo(para).then((res) => {
                this.listLoading = false;
                NProgress.done();
                if(res.code==1010009 || res.code==1010010){
                  this.valiMsg = res.desc;
                  this.$notify({
                    title: '修改失败',
                    message: res.desc,
                    type: 'error'
                  });
                }else if(res.code != 0){
                  this.$notify({
                    title: '修改失败',
                    message: res.desc,
                    type: 'error'
                  });
                }else{
                  this.$notify({
                    title: '成功',
                    message: '修改成功',
                    type: 'success'
                  });
                  this.userEditVisible = false;
                }  
                this.getUserListsData();
              });
              
            }).catch(() => {
            });
            }
          });
        //}else{
        //  this.codeValidate();
        //}
      },

      //添加用户(子账号)
      showAddUser(){
        this.userAddVisible = true;
        this.addForm = {
          org_id:'',
          orgsInfo:[],
          truename:'',
          nickname:'',
          phone:'',
          code:'',
          email:'',
          area_info:'',
          password:'',
          new_password:'',
        }
        //获取所属公司id name
        getAllCompanyInfo().then((res) => {
          //console.log(res.data);
          this.addForm.orgsInfo = res.data.elements.map(function(item){
            return {
              id:item.organization_id,
              name:item.name
            }       
          });
          //console.log(JSON.stringify(this.addForm.orgsInfo));
        }); 
      },

      //添加用户获取验证码
      addUserGetCode(){
        /*let para = new URLSearchParams();
        para.append('phone',this.addForm.phone);*/

        let para = { 
          'phone': this.addForm.phone,
        }

        getPhoneCode(qs.stringify(para)).then((res) => {
          //console.log(res);
          let second = 60;
          let timePromise = setInterval(() =>{
            if(second<=0){
                clearInterval(timePromise);
                second = 60;
                this.addCodeTxt = "重发验证码";
                this.addVali = false;
              }else{
                this.addVali = true;
                this.addCodeTxt = second + "秒后可重发";
                second--;
              }
          },1000)
        })
      },

      //添加用户验证验证码(独立)
      addUserCodeValidate(){
        if(!this.addForm.code){
          this.addValiMsg = "验证码不能为空";
        }else{
          /*let para = new URLSearchParams();
          para.append('phone',this.addForm.phone);
          para.append('validate',this.addForm.code);*/

          let para = { 
            'phone': this.addForm.phone,
            'validate': this.addForm.code,
          }
          validatePhoneCode(qs.stringify(para)).then((res) => {
            if(res.code = 0){
              this.addValiMsg = '';
              this.valiCode = 0;
            }else{
              this.addValiMsg = res.msg;
              this.valiCode = '';
            }
          });
        }
      },

      //立即添加
      addUser(formName){   
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$confirm('确认添加该用户吗?', '提示', {
              type: 'warning'
            }).then(() => {
              this.listLoading = false;
              NProgress.start();
              let para = {
                'email': this.addForm.email,
                'phone': this.addForm.phone,
                'validate':this.addForm.code,
                'password':this.addForm.password,
                'truename':this.addForm.truename,
                'nickname':this.addForm.nickname,
                'area_info':this.addForm.area_info,
                'organization':{
                  'organization_id':this.addForm.org_id
                }
              };
              /*let para = new URLSearchParams();
              para.append('org_id', this.addForm.org_id);
              para.append('body', JSON.stringify({             
                truename:this.addForm.truename,
                nickname:this.addForm.nickname,
                phone:this.addForm.phone,
                email:this.addForm.email,
                area_info:this.addForm.area_info,
                password:this.addForm.password,
                new_password:this.addForm.new_password,
                })
              );*/           
              /*axios({
                  method:'post',
                  url: 'http://192.168.1.117:8080/UserController/addChild.do',
                  data:para,
                  //headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).then(function (response) {
                  console.log(response);
                }).catch(function (error) {
                  console.log(error);
              });*/
            addUserInfo(para).then((res) => {
              //this.listLoading = false;
              NProgress.done();
              if(res.code==1010009 || res.code==1010010 || res.code==10029 || res.code==10028){
                  this.valiMsg = res.desc;
                  this.$notify({
                    title: '添加失败',
                    message: res.desc,
                    type: 'error'
                  });
                }else if(res.code != 0){
                this.$notify({
                  title: '添加失败',
                  message: res.error,
                  type: 'error'
                });
              }else{
                this.$notify({
                  title: '成功',
                  message: '添加成功',
                  type: 'success'
                });
                this.userAddVisible = false;
              }  
              this.getUserListsData();
            });
            
            }).catch(() => {
            });
          }
        });
      },

      //设置会员状态
      chgState($index, row){
        //console.log(row);
        this.status = filters.formatStatus.format(row.status);
        this.listLoading = true;
          NProgress.start();
          /*let para = new URLSearchParams();
          para.append('member_id', row.member_id);
          para.append('status', this.status);*/

          let para = {
            'member_id': row.member_id,
            'status': this.status,
          };
          chgUserState(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '更改成功',
              type: 'success'
            });
            /*for(var i=0; i < this.userListData.length; i++){
              if(i == $index){
                this.userListData.splice(i,1);
                return;
              }
            }*/
          });
      },

      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },
     
      //删除指定项
      removeByValue:function(arr, val) {
        for(var i=0; i<arr.length; i++) {
          if(arr[i] == val) {
            arr.splice(i, 1);
            break;
          }
        }
      },

      //查询用户会员等级
      getUserMemberLevelData($index, row){
        //console.log(row);
        this.gradeId = row.grade_id;
        this.grade_id = row.grade_id;
        this.member_id = row.member_id;
        this.memberLevelUpdateVisible = true;
        /*let para = new URLSearchParams();
        para.append('grade_id', this.grade_id);*/
        let para = {
          'grade_id': this.grade_id,
        };
        getMemberLevel(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.memberData = res.data;
          //console.log(this.memberData);
        }); 
      },

      //会员升级
      update(gradeId){
        this.$confirm('确认要升级会员等级吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true;
          NProgress.start();
          /*let para = new URLSearchParams();
          para.append('grade_id', gradeId);
          para.append('member_id', this.member_id);*/

          let para = {
            'grade_id': gradeId,
            'member_id':this.member_id
          };
          memberUpdate(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '升级成功',
              type: 'success'
            });
            this.memberLevelUpdateVisible = false;
            this.getUserListsData();
          });
        }).catch(() => {
        });
      }

		},
		mounted(){
			this.getUserListsData();
      this.isParentAccount();
		}
	}

</script>

<style scoped lang="scss">
  .warning:before {content: '*';color: #ff4949;margin-right: 4px;}
  *>.compPos{position:absolute;left: 39px;top: 79px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.compPos{position:absolute;left: 40px;top: 78px;}}
  *>.phonePos{position:absolute;left: 51px;top: 294px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.phonePos{position:absolute;left: 52px;top: 253px;}}
  *>.codePos{position:absolute;left: 51px;top: 365px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.codePos{position:absolute;left: 52px;top: 311px;}}
  *>.emailPos{position:absolute;left: 39px;top: 435px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.emailPos{position:absolute;left: 39px;top: 368px;}}
  *>.newPwdPos{position:absolute;left: 50px;top: 579px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.newPwdPos{position:absolute;left: 52px;top: 484px;}}
  *>.confirmPwdPos{position:absolute;left: 38px;top: 650px;}
  @media screen and (-webkit-min-device-pixel-ratio:0) {.confirmPwdPos{position:absolute;left: 39px;top: 543px;}}

  .valiMsg{
    color: #ff4949;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
  }
  .userMg{
    padding:10px;
    .userMg-title{
      color: #48576a;
      line-height: 1;
      padding: 15px 12px 15px 0;
      vertical-align: middle;
      font-size: 18px;
      font-weight: 600;
    }
  }  
  .operate{
  	padding:10px;
    a{
			margin-right: 20px;
    	color: #20a0ff;
    	font-size: 14px;
  		cursor: pointer;
  	}
  }
  .user-list{
    padding:10px;
  }
  .userDetail{
    border: 1px solid #aeaeae;
    border-collapse: collapse;
    line-height: 26px;
    tr{
      width: 100%;
      td{
        font-size: 16px;
        color: #777;    
        text-align: right;
        padding-left: 15px;
        padding-right: 15px;
        border: 1px solid #aeaeae;
        padding: 10px 0
      }
    }
  }
  #pagenation{
    padding:20px 70px 50px;
    text-align: right;
  }

</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
