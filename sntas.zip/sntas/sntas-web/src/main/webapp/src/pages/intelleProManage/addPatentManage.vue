<template>
	<section>
		<div class="tab">
        <el-tabs v-model="searchType" @tab-click="chgSchType(searchType)">
          <el-tab-pane label="按专利名称添加" name="1"></el-tab-pane>
    			<el-tab-pane label="按申请号添加" name="2"></el-tab-pane>
    			<el-tab-pane label="按申请人添加" name="3"></el-tab-pane>
  			</el-tabs>
		</div>
		<div class="search-condition">
			<el-form :inline="true" :model="schCondition" class="demo-form-inline">
  				<el-form-item label="专利名称" v-if="searchType==1">
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入专利名称" @keyup.enter="getPatentListsData">
    				<!--<el-input v-model="schCondition.keyword" placeholder="专利名称"></el-input>-->
  				</el-form-item>
          <el-form-item label="专利申请号" v-if="searchType==2">
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入专利申请号" @keyup.enter="getPatentListsData">
            <!--<el-input v-model="schCondition.keyword" placeholder="专利申请号"></el-input>-->
          </el-form-item>
          <el-form-item label="申请人" v-if="searchType==3">
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入申请人" @keyup.enter="getPatentListsData">
            <!--<el-input v-model="schCondition.keyword" placeholder="申请人"></el-input>-->
          </el-form-item>
  				<el-form-item>
    				<el-button type="primary" @click="getPatentListsData">确定</el-button>
  				</el-form-item>
			</el-form>
		</div>
    <div class="operate">
      <a class="delete" @click="batchAdd"><i class="el-icon-plus"></i>批量添加管理</a>
    </div>
		<div class="patent-list">
			<el-table :data="patentAddListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;" >
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="patentName" label="专利名称"></el-table-column>
				<el-table-column prop="applyNo" label="申请号"></el-table-column>
				<el-table-column prop="applyTime" label="申请时间"></el-table-column>
				<el-table-column prop="publicNoticeNo" label="公开公告号"></el-table-column>
				<el-table-column prop="publicNoticeDate" label="公开公告日期"></el-table-column>
        <el-table-column prop="ipcType" label="IPC分类号"></el-table-column>
				<el-table-column prop="applyUser" label="申请人"></el-table-column>	
				<el-table-column prop="inventUser" label="发明人"></el-table-column>
        <!--<el-table-column prop="proxyUser" label="代理人" min-width="1" class-name="hideCol" ></el-table-column>-->
			</el-table>
		</div>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>
	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	import { getAddPatentLists, addPatent } from '../../api/api';
	export default {
		data(){
			return{
				searchType: '1',
        listLoading:false,
				//查询条件
				schCondition: {
          keyword:'',
    		},
				patentAddListData: [],
				currentPage:1,
        totalPages:1,//总页数
        totalCount:null,//总条数
        selecteds: [],//列表选中列
			}
		},
		methods:{
      //查询类型
			chgSchType(searchType) {
        //console.log(searchType);
        this.schCondition.keyword="";
      },

      //添加专利管理专利查询
      getPatentListsData(){
        if(!this.schCondition.keyword){
          this.$notify.info({
            title: '消息',
            message: '请填写专利名称'
          });
          return false;
        }else{

          /*let para = new URLSearchParams();
          para.append('searchType', this.searchType);
          para.append('keyword', this.schCondition.keyword);
          para.append('pageNo', this.currentPage);
          para.append('pageSize', 20);*/

          let para = { 
            'searchType': this.searchType,
            'keyword': this.schCondition.keyword,
            'pageNo':this.currentPage,
            'pageSize':20
          }

          this.listLoading = true;
          NProgress.start();
          getAddPatentLists(qs.stringify(para)).then((res) => {
            //console.log(res);
            this.patentAddListData = res.data.list;
            this.totalPages = res.data.total;//总页数
            this.totalCount = res.data.totalCount;//总条数
            this.currentPage = res.data.pageNo;//当前页
            this.listLoading = false;
            NProgress.done();
          });
        }
      },

      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getPatentListsData();
      },

      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },

      //批量添加管理
      batchAdd: function () {
        //console.log(this.selecteds);
        //var ids = this.selecteds.map(item => item.id).toString();
        if(this.selecteds.length === 0){
          this.$notify.info({
            title: '消息',
            message: '请选择需要添加项'
          });
          return false;
        }else{
          this.$confirm('确认添加选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            let para = this.selecteds;

            addPatent(para).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '添加成功',
                type: 'success'
              });
              setTimeout(this.$router.push({ path: '/patentManage' }),3000);
            });
          }).catch(() => {
          });
        }
      }
		},
		mounted(){
      
		}
	}

</script>

<style scoped lang="scss">
    .hideCol{
      display: none;
    }
    .tab{
    	padding:10px;
    }
    .search-condition{
    	padding:10px;
    }
    .operate{
    	padding:10px;
    	a{
			  margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
        cursor: pointer;
    	}
    }
    .patent-list{
    	padding:10px;
    }
    #pagenation{
      padding:20px 10px 50px;
      text-align: right;
    }
    .ipt{
      -webkit-appearance: none;
      -moz-appearance: none;
      appearance: none;
      background-color: #fff;
      background-image: none;
      border-radius: 4px;
      border: 1px solid #bfcbd9;
      box-sizing: border-box;
      color: #1f2d3d;
      display: block;
      font-size: inherit;
      height: 36px;
      line-height: 1;
      outline: 0;
      padding: 3px 10px;
      transition: border-color .2s cubic-bezier(.645,.045,.355,1);
      width: 100%;
    }
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
