<template>
	<section>
		<div class="tab">
        <el-tabs v-model="searchType" @tab-click="chgSchType(searchType)">
          <el-tab-pane label="按商标名称添加" name="1"></el-tab-pane>
    			<el-tab-pane label="按注册号添加" name="2"></el-tab-pane>
    			<el-tab-pane label="按企业名称添加" name="3"></el-tab-pane>
  			</el-tabs>
		</div>
		<div class="search-condition">
			<el-form :inline="true" :model="schCondition" class="demo-form-inline">
  				<el-form-item label="商标名称" v-if="searchType==1"><!--style="width:17%;"-->
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入商标名称" @keyup.enter="getTrademarkListsData">
    				<!--<el-input v-model="schCondition.keyword" placeholder="商标名称"></el-input>-->
  				</el-form-item>
          <el-form-item label="商标注册号" v-if="searchType==2">
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入商标注册号" @keyup.enter="getTrademarkListsData">
            <!--<el-input v-model="schCondition.keyword" placeholder="商标注册号"></el-input>-->
          </el-form-item>
          <el-form-item label="企业名称" v-if="searchType==3">
            <input class="ipt" v-model="schCondition.keyword" placeholder="请输入企业名称" @keyup.enter="getTrademarkListsData">
            <!--<el-input v-model="schCondition.keyword" placeholder="企业名称"></el-input>-->
          </el-form-item>
  				<el-form-item>
    				<el-button type="primary" @click="getTrademarkListsData" >确定</el-button>
  				</el-form-item>
			</el-form>
		</div>
    <div class="operate">
      <a class="delete" @click="batchAdd"><i class="el-icon-plus"></i>批量添加管理</a>
    </div>
		<div class="trademark-list">
			<el-table :data="trademarkAddListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;" >
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="intCls" label="分类号"></el-table-column>
				<el-table-column prop="regNo" label="商标注册号"></el-table-column>
				<el-table-column prop="tmImg"  label="商标图形">
          <template scope="scope">
            <img class="lazy" :src="'http://pic.tmkoo.com/pic.php?s=1&zch='+scope.row.tmImg" >
          </template>
        </el-table-column>
				<el-table-column prop="applicantCn" label="注册人"></el-table-column>
				<el-table-column prop="appDate" label="申请日期"></el-table-column>
				<el-table-column prop="regDate" label="注册日期"></el-table-column>
        <!--<el-table-column prop="" label="商品组别" min-width="200" sortable></el-table-column>
				<el-table-column prop="" label="使用商品" min-width="150" sortable></el-table-column>	
				<el-table-column prop="" label="法律状态" min-width="150" sortable></el-table-column>-->
			</el-table>
		</div>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>
	</section>
</template>

<script>
  import Vue from 'vue'
  import VueResource from 'vue-resource'
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
  import 'url-search-params'//URLSearchParams from 
  import qs from 'qs'
  import 'babel-polyfill';
  import 'promise-polyfill'; 
	import { getAddTrademarks, addTrademark } from '../../api/api';
	export default {
		data(){
			return{
				searchType: '1',
        listLoading:false,
				//查询条件
				schCondition: {
          keyword:'',
    		},
				trademarkAddListData: [],
				currentPage:1,
        totalPages:1,//总条数
        totalCount:null,//总页数
        selecteds: [],//列表选中列
			}
		},
		methods:{
      //查询类型
			chgSchType(searchType) {
        //console.log(searchType);
        this.schCondition.keyword="";
      },

      //添加商标管理商标查询
      getTrademarkListsData(){

        if(!this.schCondition.keyword){
          this.$notify.info({
            title: '消息',
            message: '请填写商标名称'
          });
          return false;
        }else{

          /*let para = new URLSearchParams();
          para.append('searchType', this.searchType);
          para.append('keyword', this.schCondition.keyword);
          para.append('pageNo', this.currentPage);
          para.append('pageSize',20);
          */
          
          //FormData IE9不兼容
          /*let para = new FormData();
          para.append('searchType', this.searchType);
          para.append('keyword', this.schCondition.keyword);
          para.append('pageNo', this.currentPage);
          para.append('pageSize',20);*/

          let para = { 
            'searchType': this.searchType,
            'keyword': this.schCondition.keyword,
            'pageNo':this.currentPage,
            'pageSize':20
          }

          this.listLoading = true;
          NProgress.start();
          getAddTrademarks(qs.stringify(para)).then((res) => {
            //console.log(res);
            this.trademarkAddListData = res.data.result;
            this.totalPages = res.data.total;//总页数
            this.totalCount = res.data.totalCount;//总条数
            this.currentPage = res.data.pageNo;//当前页
            this.listLoading = false;
            //console.log(this.trademarkAddListData);
            //console.log(this.total);
            //console.log(this.totalCount);
            NProgress.done();
          }).catch((error) =>{
            console.log(error);
          });

          /*this.$http.post('http://192.168.1.123:80/StewardTradeMarkInfo/queryStewardTrademarkByCondition.do', para, {
            headers: {
              //responseType: 'json'
            },
            emulateJSON: true
          }).then(function(response) {
            console.log(response);

          }, function(response) {
            // 这里是处理错误的回调
            console.log(response)
          });*/


        }
      },

      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getTrademarkListsData();
      },


      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },

      //批量添加管理
      batchAdd: function () {
        //console.log(this.selecteds);
        //var ids = this.selecteds.map(item => item.id).toString();
        //console.log(ids);
        if(this.selecteds.length === 0){
          this.$notify.info({
            title: '消息',
            message: '请选择需要添加项'
          });
          return false;
        }else{
          this.$confirm('确认添加选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            let para = this.selecteds;
            /*let para = new URLSearchParams();
            para.append('infos', JSON.stringify(this.selecteds));*/
            addTrademark(para).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '添加成功',
                type: 'success'
              });
              setTimeout(this.$router.push({ path: '/trademarkManage' }),3000);
            });
          }).catch(() => {
          });
        }
      }
		},
		mounted(){
      
		}
	}

</script>

<style scoped lang="scss">
    .tab{
    	padding:10px;
    }
    .search-condition{
    	padding:10px;
    }
    .operate{
    	padding:10px;
    	a{
			  margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
        cursor: pointer;
    	}
    }
    .trademark-list{
    	padding:10px;
    }
    #pagenation{
      padding:20px 10px 50px;
      text-align: right;
    }
    .ipt{
      -webkit-appearance: none;
      -moz-appearance: none;
      appearance: none;
      background-color: #fff;
      background-image: none;
      border-radius: 4px;
      border: 1px solid #bfcbd9;
      box-sizing: border-box;
      color: #1f2d3d;
      display: block;
      font-size: inherit;
      height: 36px;
      line-height: 1;
      outline: 0;
      padding: 3px 10px;
      transition: border-color .2s cubic-bezier(.645,.045,.355,1);
      width: 100%;
    }
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
