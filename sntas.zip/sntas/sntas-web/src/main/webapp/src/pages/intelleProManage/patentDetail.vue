<template>
	<section>
		<div class="trademark-content">
            <div class="td-main-info">
            	<div class="title">专利主要信息</div>
            	<div class="info-detail">
                    <div class="img">
                        <img class="td-img" :src="ptDetail.imgUrl">
                    </div>
            		<table>
            			<tr>
            				<td width="580" height="45">专利名称：{{ptDetail.patentName}}</td>
            				<td>申请号：{{ptDetail.applyNo}}</td>
            			</tr>
            			<tr>
                            <td height="45">专利类型：{{ptDetail.type | patentFormat}}</td>
                            <td>申请时间：{{ptDetail.applyTime}}</td>
                        </tr>
            			<tr>
                            <td height="45">公开公告号：{{ptDetail.publicNoticeNo}}</td>
                            <td>公开公告日期：{{ptDetail.publicNoticeDate}}</td>
                        </tr>
                        <tr>
                            <td height="45">分类号：{{ptDetail.ipcType}}</td>
                            <td>申请人：{{ptDetail.applyUser}}</td>
                        </tr>
                        <tr>
                            <td height="45">发明人：{{ptDetail.inventUser}}</td>
                            <td>代理人：{{ptDetail.proxyUser}}</td>
                        </tr>
                        <tr>
                            <td height="45"> 代理机构：{{ptDetail.agency}}</td>
                            <td>申请人地址：{{ptDetail.address}}</td>
                        </tr>
                        <tr>
                            <td height="45">邮编：{{ptDetail.postCode}}</td>
                            <td>申请（专利权）人所在国（省）：{{ptDetail.province}}</td>
                        </tr>
            		</table>
            	</div>
            </div>
            <div class="td-main-info">
                <el-table :data="lawStatusList">
                    <el-table-column property="nrdAn" label="申请号" ></el-table-column>
                    <el-table-column property="nrdPn" label="公开公告号"></el-table-column>
                    <el-table-column property="prsDate" label="法律状态生效日"></el-table-column>
                    <el-table-column property="lawStateCNMeaning" label="法律状态含义"></el-table-column>
                </el-table>
            	<!--<div class="title">法律状态</div>
            	<div class="project-info">
            		<div class="pro-info-detail">
            			<div class="info-title">
            				商品/服务
            			</div>
            			<ul class="info-item">
            				<li v-for="g in lawStatusList">{{g}}</li>
            			</ul>
            		</div>
            	</div>-->
            </div>
		</div>
	</section>
</template>

<script>
    import NProgress from 'nprogress'
    import { seePatentDetail } from '../../api/api';
    import filters from '../../api/filters'
    import URLSearchParams from 'url-search-params'
    import qs from 'qs'
	export default {
		data(){
			return{
                ptDetail:'',
                lawStatusList:[],
                listLoading:false,
			}
		},
		methods:{
            getDetailData(){
                this.listLoading = true;
                /*let para = new URLSearchParams();
                para.append('patentId', this.$route.params.id);*/
                let para = { 
                    'patentId': this.$route.params.id,
                }
                NProgress.start();
                seePatentDetail(qs.stringify(para)).then((res) => {
                    this.listLoading = false;
                    let { code } = res;
                    //console.log(code);
                    NProgress.done();
                    if(code != 0){
                        //alert("网络异常");
                    }else{  
                        this.ptDetail = res.data;
                        this.lawStatusList = res.data.lawStatusList;
                        //console.log(this.lawStatusList);
                    }    
                });
            }
		},
		mounted(){
            this.getDetailData();
		},
        filters: {
            patentFormat : filters.formatPatent.format
        },
	}

</script>

<style scoped lang="scss">
	.trademark-content{
		border:1px solid #dfe6ec;
		color:#48576a;
		.td-main-info{
			.title{
    			margin: 0 0 15px 0;
    			font-weight: bold;
				font-size:14px;
				height: 34px;
    			line-height: 34px;
                background-color:#f2f2f2;
                width: 100%;
			}
			.info-detail{
				padding:0px 20px 20px 20px;
                .img{
                    display:inline-block;
                    float:left;
                    margin-bottom:10px;
                }
				table{
					vertical-align: middle;
    				width: 100%;
    				border-collapse: collapse;
    				border-spacing: 0;
                    display:inherit;
				}
				.td-img{
    				border:1px solid #eaeaea; 
    				max-width:320px; 
    				max-height:320px;
                    margin-right: 25px;
   				}
			}
			.project-info{
				margin: 15px 20px 20px 20px;
				display: inline;
				.pro-info-detail{
					width: 30%;
					display: inline-block;
    				.info-title{
    					display: block;
    					text-align: center;
    					background: #324057;
    					font-size: 14px;
    					color: #fff;
    					padding: 6px 0;
    				}
    				.info-item{
    					padding: 0px 5px 10px 5px;
    					margin:0px;
    					border: 1px solid #e6e6e4;
    					list-style: none;
    					li{
    						list-style: none;
    						font-size: 12px;
    				        border-bottom: 1px solid #dfe6ec;
    						padding: 12px 15px 12px 40px;
    						//background: url(../images/user/dh_ico.png) 17px 9px no-repeat;
    					}
    				}
				}
			}
		}
	}
</style>
