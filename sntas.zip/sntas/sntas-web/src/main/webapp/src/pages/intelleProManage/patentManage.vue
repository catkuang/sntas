<template>
	<section>
		<div class="schCondition">
			<div class="patentKind">
				<div class="patent-keyword">专利类型：</div>
				<ul class="patent-valueList">
					<li v-for="p,$index in patentTypes" :class="{true: 'modalActive', false: 'modalInactive'}[p.checked]" @click="schPatentType(p,$index);">
						<a >{{p.value}}({{p.count}})<span></span></a>
					</li>
				</ul>
			</div>
      <!--<a class="statistc" style="position: absolute;top: 29px;left: 139px;text-decoration:none;color:red;cursor:pointer;">({{allPatentCount}})</a>-->
			<div class="patentKind">
				<div class="patent-keyword">申请时间：</div>
				<ul class="patent-valueList">
					<li v-for="a,$index in applyTimeTypes" :class="{true: 'modalActive', false: 'modalInactive'}[a.checked]" @click="schApplyTimeType(a,$index);">
						<a>{{a.value}}({{a.count}})<span></span></a>
					</li>
				</ul>
			</div>
			<!--<div class="patentKind">
				<div class="patent-keyword">法律状态：</div>
				<ul class="patent-valueList">
					<li v-for="l in legalStatus" @click="sch(l);">
						<a>{{l}}<span>（0）</span></a>
					</li>
				</ul>
			</div>-->
		</div>
		<div class="patent-sch">
			<div class="sch-box">
			    <select class="schTp" v-model="schTp">
    				<option>专利名称</option>
  				</select>
  				<input class="schInput" type="text" v-model="keyword" placeholder="请输入专利名称" @keyup.enter="getPatentListsData">
  				<input class="schBtn" type="button"  @click="getPatentListsData" value="搜索" >
			</div>
		</div>
		<div class="operate">
			<a class="delete" @click="batchRemove"><i class="el-icon-delete"></i>批量删除</a>
			<a class="add"><router-link to="/addPatentManage" style="text-decoration:none"><i class="el-icon-plus"></i>添加专利管理</router-link></a>
			<a class="export" @click="exportPts"><i class="el-icon-document"></i>EXCEL导出</a>
		</div>
		<div class="patent-list">
			<el-table :data="patentListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;">
				<el-table-column type="selection" width="55" sortable></el-table-column>
				<!--<el-table-column prop="type" label="专利类型" width="120" sortable></el-table-column>-->
        <el-table-column scope="scope" label="专利类型">
          <template scope="scope">
            <span>{{ scope.row.type | formatPatent}}</span>
          </template>
        </el-table-column>
				<el-table-column prop="publicNoticeNo" label="公告号"></el-table-column>
				<el-table-column prop="applyNo" label="申请号/专利号"></el-table-column>
				<el-table-column prop="patentName" label="发明名称"></el-table-column>
				<el-table-column prop="applyUser" label="申请人"></el-table-column>
				<el-table-column prop="applyTime" label="申请日"></el-table-column>
				<el-table-column prop="ipcType" label="主分类号"></el-table-column>
				<el-table-column label="操作" width="280">
					<template scope="scope">
            <el-button size="small" @click="seeDetail(scope.$index, scope.row)">查看</el-button>
						<el-button size="small" type="info" @click="seeLegalStatus(scope.$index, scope.row)">法律状态</el-button>
						<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>

		<!--法律状态界面-->
		<el-dialog title="法律状态" v-model="legalTableVisible" >
  			<el-table :data="legalStatusData">
    			<el-table-column property="nrdAn" label="申请号" width="250"></el-table-column>
    			<el-table-column property="prsDate" label="法律状态生效日" width="200"></el-table-column>
    			<el-table-column property="lawStateCNMeaning" label="法律状态含义"></el-table-column>
  			</el-table>
		</el-dialog>

	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { getPatentLists, getLegalStatus, deletePatent, addPatent, exportPatents, getPatentsNum } from '../../api/api';
  import filters from '../../api/filters'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data(){
			return{
				patentTypes:[],
				patentType:'0',
				applyTimeTypes:[],
				applyTimeType:'0',
        allPatentCount:'',//全部
        inventPatentCount:'',//发明专利
        parcticalNewPatentCount:'',//实用新型专利
        appearanceDesignPatentCount:'',//外观设计专利
        thisYearPatentCount:'',//今年申请
        halfYearPatentCount:'',//半年内
        oneYearPatentCount:'',//近一年
        ThreeYearPatentCount:'',//近三年
        fiveYearPatentCount:'',//近五年
        aboveFiveYearPatentCount:'',
				arr:[],//专利类型
				arr2:[],//申请时间
				schTp:'专利名称',
				keyword:'',
				patentListData: [],
				currentPage:1,
        totalPages:1,//总页数
        totalCount:null,//总条数
        selecteds: [],//列表选中列
        legalTableVisible:false,
        legalStatusData:[],
        listLoading:false,
			}
		},
    filters: {
      formatPatent : filters.formatPatent.format
    },
		methods:{
      //专利类型
			schPatentType(p,$index){
        this.patentTypes[0].checked = false;
        if(this.arr.length==0){
          this.arr.push($index);
          p.checked = true;
        }else if(this.arr.length > 0){
          var lastIndex = this.arr[0];
          this.patentTypes[lastIndex].checked = false;
          this.arr.length = 0;
          this.arr.push($index);
          p.checked = true;
        };
        this.patentType = p.id;
        //console.log(this.patentType);
        this.currentPage = 1;
        this.getPatentListsData();
			},
      //申请时间
			schApplyTimeType(a,$index){
        this.applyTimeTypes[0].checked = false;
				if(this.arr2.length==0){
          this.arr2.push($index);
          a.checked = true;
        }else if(this.arr2.length > 0){
          var lastIndex = this.arr2[0];
          this.applyTimeTypes[lastIndex].checked = false;
          this.arr2.length = 0;
          this.arr2.push($index);
          a.checked = true;
        };
        this.applyTimeType = a.id;
        this.currentPage = 1;
        this.getPatentListsData();
        //console.log(this.applyTimeType);
			},
			//根据条件查询专利列表信息
      getPatentListsData(){
        /*let para = new URLSearchParams();
        para.append('patentType', this.patentType);
        para.append('applyTimeType', this.applyTimeType);
        para.append('patentName', this.keyword);
        para.append('pageNo',this.currentPage);*/

        let para = { 
          'patentType': this.patentType,
          'applyTimeType': this.applyTimeType,
          'patentName':this.keyword,
          'pageNo':this.currentPage
        }
        this.listLoading = true;
        NProgress.start();
        getPatentLists(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.patentListData = res.data.result;
          this.totalPages = res.data.total;//总页数
          this.totalCount = res.data.totalCount;//总条数
          this.currentPage = res.data.pageNo;//当前页
          this.listLoading = false;
          //console.log(this.trademarkListData);
          //console.log(this.totalPages);
          //console.log(this.totalCount);
          NProgress.done();
        });
      },
      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getPatentListsData();
      },
      //查看法律状态
      seeLegalStatus: function (index, row) {
				this.legalTableVisible = true;
        /*let para = new URLSearchParams();
        para.append('publicNoticeNo', row.publicNoticeNo);*/

        let para = { 
          'publicNoticeNo': row.publicNoticeNo,
        }
				//this.listLoading = true;
				NProgress.start();
				getLegalStatus(qs.stringify(para)).then((res) => {
          //console.log(res);
					this.legalStatusData = res.data;
          //this.listLoading = false;
					NProgress.done();
		    });
			},
      //查看
      seeDetail($index, row){
        //console.log(row);
        this.$router.push({ name: 'patentDetail', params:{id:row.id} });
      },
			//单个删除
      handleDel($index, row){
      	//console.log($index);
        //console.log($index + " " + JSON.stringify(row));
        this.$confirm('确认删除该记录吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true;
          NProgress.start();
          /*let para = new URLSearchParams();
          para.append('patentIds', JSON.stringify(row.id));*/

          let para = { 
            'patentIds': row.id,
          }
          deletePatent(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success'
            });
            /*for(var i=0; i < this.patentListData.length; i++){
            	if(i == $index){
            		this.patentListData.splice(i,1);
            		return;
            	}
            }*/
            this.getPatentListsData();
            this.patentNumCount(); 
          });
        }).catch(() => {
        });
      },
      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },
      //待删除指定项
      removeByValue:function(arr, val) {
  			for(var i=0; i<arr.length; i++) {
    			if(arr[i] == val) {
      			arr.splice(i, 1);
      			break;
    			}
  			}
			},
      //批量删除
      batchRemove: function () {
        var ids = this.selecteds.map(item => item.id).toString();
        //var idsArr = [];
        //idsArr.push(this.selecteds.map(item => item.id));
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择删除项'
          });
          return false;
        }else{  
          this.$confirm('确认删除选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('patentIds', ids);*/

            let para = { 
              'patentIds': ids,
            }
            deletePatent(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '删除成功',
                type: 'success'
              });  
              /*for(var i=0; i < this.selecteds.length; i++){
                this.removeByValue(this.patentListData, this.selecteds[i]);
              }*/
              this.getPatentListsData();
              this.patentNumCount(); 
            });
          }).catch(() => {
          });
        }
      },
		  //EXCEL导出
      exportPts(){
        var ids = this.selecteds.map(item => item.id).toString();
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择导出项'
          });
          return false;
        }else{
          this.$confirm('确定导出选中项到EXCEL吗？', '提示', {
            type: 'warning'
          }).then(() => {
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('patentIds', ids);*/
            let para = { 
              'patentIds': ids,
            }
            location.href = `${exportPatents}` + qs.stringify(para);
          }).catch(() => {
          });
        }
      },
      //统计专利个数
      patentNumCount(){
        NProgress.start();
        getPatentsNum().then((res) => {
          let { code } = res;
          //console.log(code);
          NProgress.done();
          if(code != 0){
            //alert("网络异常");
          }else{  
            //console.log(res);
            this.allPatentCount = res.data.sumCount || 0;
            this.inventPatentCount = res.data.typeCount1 || 0;
            this.parcticalNewPatentCount = res.data.typeCount2 || 0;
            this.appearanceDesignPatentCount = res.data.typeCount3 || 0;
            this.thisYearPatentCount = res.data.timeCount1 || 0;
            this.halfYearPatentCount = res.data.timeCount2 || 0;
            this.oneYearPatentCount = res.data.timeCount3 || 0;
            this.ThreeYearPatentCount = res.data.timeCount4 || 0;
            this.fiveYearPatentCount = res.data.timeCount5 || 0;
            this.aboveFiveYearPatentCount = res.data.timeCount6 || 0;

            var patentTypesArr = [
              {
                id:'0',
                value:'全部',
                checked:true,
                count:this.allPatentCount
              },
              {
                id:'1',
                value:'发明专利',
                checked:false,
                count:this.inventPatentCount 
              },
              {
                id:'2',
                value:'实用新型专利',
                checked:false,
                count:this.parcticalNewPatentCount
              },
              {
                id:'3',
                value:'外观设计专利',
                checked:false,
                count:this.appearanceDesignPatentCount 
              }
            ];
            this.patentTypes = patentTypesArr;
            var applyTimeTypesArr = [
              {
                id:'0',
                value:'全部',
                checked:true,
                count:this.allPatentCount
              },
              {
                id:'1',
                value:'今年申请',
                checked:false,
                count:this.thisYearPatentCount
              },
              {
                id:'2',
                value:'半年内',
                checked:false,
                count:this.halfYearPatentCount
              },
              {
                id:'3',
                value:'近一年',
                checked:false,
                count:this.oneYearPatentCount
              },
              {
                id:'4',
                value:'近三年',
                checked:false,
                count:this.ThreeYearPatentCount
              },
              {
                id:'5',
                value:'近五年',
                checked:false,
                count:this.fiveYearPatentCount
              },
              {
                id:'6',
                value:'五年以上',
                checked:false,
                count:this.aboveFiveYearPatentCount
              }
            ];
            this.applyTimeTypes = applyTimeTypesArr;
          }    
        }); 
      },
		},
		mounted(){
      this.patentNumCount();
			this.getPatentListsData();
		}
	}

</script>

<style scoped lang="scss">
	input,select{
		outline: none;
	}
	.schCondition{
		border: 1px solid #dfe6ec;
		.patentKind{
		    position: relative;
    		line-height: 34px;
    		overflow: hidden;
    		border-bottom: 1px solid #dfe6ec;
    		.patent-keyword{
    			float: left;
    			width: 80px;
    			padding: 8px 0 10px 5px;
    			color: #48576a;
    			border-right:1px solid #dfe6ec;
    			background:#eef1f6;
    		}
    		.patent-valueList{
    			overflow: hidden;
    			zoom: 1;
    			position: relative;
    			background: #f2f2f2;
    			line-height: 21px;
    			padding: 6px 0 8px 5px;
    			margin: 0px;
    			li{
    				cursor: pointer;
    				list-style: none;
    			  float: left;
    			  margin-top: 5px;
    				margin-bottom: 5px;
    				margin-right: 23px;
    				height: 26px;
    				line-height: 26px;
    				a{
    					text-decoration: none;
              padding: 7px ;//30px 7px 7px
    				}
    				a:hover{
    					background: #20a0ff;
    					color: #fff;
    				}
    			}
    			.modalActive{
    				//border: 1px solid #20a0ff;
    				color: white;
    				background-color: #20a0ff;
            a{
              color: white;
            }
    			}
				.modalInactive{
					border:none;
				}
    		}
		}
	}
	.patent-sch{
		margin: 20px 10px 15px 0;
    	overflow: hidden;
    	line-height: 40px;
    	height: 40px;
		.sch-box{
			width: 540px;
    		float: left;
    		height: 30px;
    		line-height: 30px;
    		border: 1px solid #dfe6ec;
    		margin-left: 10px;
    		.schTp{
          background: #f2f2f2;
    			display: inline;
    			height: 25px;
    			border: none;
    			border-right: 1px solid #dfe6ec;
    			color: #48576a;
    		}
    		.schInput{
    			width: 372px;
    			height: 25px;
    			line-height: 25px;
    			border: none;
          background: #f2f2f2;
    		}
    		.schBtn{
    			float: right;
    			width: 70px;
    			height: 30px;
    			background-color:#20a0ff;
    			color: #fff;
    			cursor: pointer;
    			border: none;
    		}
		}
	}
    .operate{
    	padding:10px;
    	a{
			margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
    		cursor: pointer;
    	}
    }
    .patent-list{
    	padding:10px;
    }
    #pagenation{
      padding:20px 10px 50px;
      text-align: right;
    }
    /*a.statistc:hover{
      color: #fff;
    }*/
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
</style>
