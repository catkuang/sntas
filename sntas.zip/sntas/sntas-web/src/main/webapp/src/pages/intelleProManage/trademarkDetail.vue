<template>
	<section>
		<div class="trademark-content">
            <div class="td-main-info">
            	<div class="title">商标主要信息</div>
            	<div class="info-detail">
            		<table>
            			<tr>
            				<td width="160" rowspan="4">
                                <img class="td-img" :src="'http://pic.tmkoo.com/pic.php?s=1&zch=' + tmDetail.tmImg">            				
                            </td>
            				<td width="180" height="28">商标名称：{{tmDetail.tmName}}</td>
            				<td>注册号/申请号：{{tmDetail.regNo}}</td>
            			</tr>
            			<tr>
                            <!--<td height="28">商标类型：{{}}</td>-->
                            <td>申请日：{{tmDetail.appDate}}</td>
                        </tr>
            			<tr>
                            <td height="28">商标类别：{{tmDetail.intCls}}</td>
                            <td>注册公告日：{{tmDetail.regDate}}</td>
                        </tr>
            		</table>
            	</div>
            </div>
            <div class="td-main-info">
            	<div class="title">商标其它信息</div>
            	<div class="info-detail">
            		<table>
            			<tr>
                            <td width="350" height="28">申请人名称：{{tmDetail.applicantCn}}</td>
                            <td >申请人地址：{{tmDetail.addressCn}}</td>
                        </tr>
            			<tr>
                            <!--<td height="28">是否共有商标： </td>-->
                            <td>初审公告日期：{{tmDetail.announcementDate}}</td>
                        </tr>
                        <tr>
                            <td height="28">代理机构：{{tmDetail.agent}}</td>
                            <td>初审公告期号：{{tmDetail.announcementIssue}}</td>
                        </tr>
                        <tr>
                            <td height="28">注册公告日期：{{tmDetail.regDate}}</td>
                            <td>注册公告期号：{{tmDetail.regIssue}}</td>
                        </tr>
                        <tr>
                            <td height="28">
                            <span style="display:block;">商标状态：</span>
                                <ul>
                                    <li style="display: block;list-style-type: none;margin: 0px;padding: 0px;" v-for="f in flowList">
                                        {{f.flowDate }}-{{ f.flowName}}
                                    </li>
                                </ul>
                            </td>
                        </tr>
            		</table>
            	</div>
            </div>
            <div class="td-main-info">
            	<div class="title">使用项目信息</div>
            	<div class="project-info">
            		<div class="pro-info-detail">
            			<div class="info-title">
            				商品/服务
            			</div>
            			<ul class="info-item">
            				<li v-for="g in goodsList">{{g.goodsCode }}-{{ g.goodsName}}</li>
            			</ul>
            		</div>
            	</div>
            	<!--<div class="project-info">
            		<div class="pro-info-detail">
            			<div class="info-title">
            				商标涉及群组
            			</div>
            			<ul class="info-item">
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            			</ul>
            		</div>
            	</div>
            	<div class="project-info">
            		<div class="pro-info-detail">
            			<div class="info-title">
            				商标未涉及群组
            			</div>
            			<ul class="info-item">
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            				<li>书包</li>
            			</ul>
            		</div>
            	</div>-->
            </div>
		</div>
	</section>
</template>

<script>
    import NProgress from 'nprogress'
    import { seeTrademarkDetail } from '../../api/api';
    import URLSearchParams from 'url-search-params'
    import qs from 'qs'
	export default {
		data(){
			return{
                tmDetail:'',
                goodsList:'',
                flowList:'',
                listLoading:false
			}
		},
		methods:{
            getDetailData(){
                this.listLoading = true;
                /*let para = new URLSearchParams();
                para.append('intCls', this.$route.params.intCls);
                para.append('regNo', this.$route.params.regNo);*/

                let para = { 
                    'intCls': this.$route.params.intCls,
                    'regNo': this.$route.params.regNo,
                }

                NProgress.start();
                seeTrademarkDetail(qs.stringify(para)).then((res) => {
                    this.listLoading = false;
                    let { code } = res;
                    //console.log(code);
                    NProgress.done();
                    if(code != 0){
                        //alert("网络异常");
                    }else{  
                        this.tmDetail = res.data;
                        //console.log(this.trademarkDetail);
                        this.goodsList = res.data.goodsList;
                        this.flowList = res.data.flowList;
                    }    
                });
            }
		},
		mounted(){
            this.getDetailData();
		}
	}

</script>

<style scoped lang="scss">
	.trademark-content{
		border:1px solid #dfe6ec;
		margin:10px;
		color:#48576a;
		.td-main-info{
			.title{
                width: 200px;
    			margin: 0 10px 15px 10px;
    			font-weight: bold;
				font-size:14px;
				height: 34px;
    			line-height: 34px;
                background-color:#f2f2f2;
			}
			.info-detail{
				padding:0px 20px 20px 20px;
				table{
					vertical-align: middle;
    				width: 100%;
    				border-collapse: collapse;
    				border-spacing: 0
				}
				.td-img{
    				border:1px solid #eaeaea; 
    				max-width:120px; 
    				max-height:120px;
   				}
			}
			.project-info{
				margin: 15px 20px 20px 20px;
				display: inline;
				.pro-info-detail{
					width: 30%;
					display: inline-block;
    				.info-title{
    					display: block;
    					text-align: center;
    					background: #324057;
    					font-size: 14px;
    					color: #f2f2f2;
    					padding: 6px 0;
    				}
    				.info-item{
    					padding: 0px 5px 10px 5px;
    					margin:0px;
    					border: 1px solid #e6e6e4;
    					list-style: none;
    					li{
    						list-style: none;
    						font-size: 12px;
    				        border-bottom: 1px solid #dfe6ec;
    						padding: 12px 15px 12px 40px;
    						//background: url(../images/user/dh_ico.png) 17px 9px no-repeat;
    					}
    				}
				}
			}
		}
	}
</style>
