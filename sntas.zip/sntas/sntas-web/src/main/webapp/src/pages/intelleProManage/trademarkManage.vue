<template>
	<section>
		<div class="tab">
        <el-tabs v-model="searchType" @tab-click="chgSchType(searchType)">
    			<el-tab-pane label="全部" name="0"></el-tab-pane><!--{{allCount}}-->
    			<el-tab-pane label="续费提醒" name="1"></el-tab-pane><!--{{waitFeeCount}}-->
    			<el-tab-pane label="异议期" name="2"></el-tab-pane><!--{{objectionRiskCount}}-->
    			<el-tab-pane label="撤三风险" name="3"></el-tab-pane><!--{{threeRiskCount}}-->
  			</el-tabs>
        <span style="position: absolute;top: 41px;left: 303px;color:red;">({{allCount}})</span>
        <span style="position: absolute;top: 41px;left: 392px;color:red;">({{waitFeeCount}})</span>
        <span style="position: absolute;top: 41px;left: 466px;color:red;">({{objectionRiskCount}})</span>
        <span style="position: absolute;top: 41px;left: 554px;color:red;">({{threeRiskCount}})</span>
		</div>
		<div class="search-condition">
			<el-form :inline="true" :model="schCondition" class="demo-form-inline">
  				<el-form-item label="商标名称">
            <input class="ipt" v-model="schCondition.tmName" placeholder="商标名称" @keyup.enter="getTrademarkListsData">
    				<!--<el-input v-model="schCondition.tmName" placeholder="商标名称" @keyup.enter="getTrademarkListsData"></el-input>-->
  				</el-form-item>
  				<el-form-item label="注册号">
            <input class="ipt" v-model="schCondition.regNo" placeholder="注册号" @keyup.enter="getTrademarkListsData">
            <!--<el-input v-model="schCondition.regNo" placeholder="注册号"></el-input>-->
  				</el-form-item>
  				<el-form-item label="注册人">
    				<input class="ipt" v-model="schCondition.applicantCn" placeholder="注册人" @keyup.enter="getTrademarkListsData"></input>
  				</el-form-item>
  				<!--<el-form-item label="商品">
    				<el-input v-model="schCondition.goods" placeholder="商品"></el-input>
  				</el-form-item>-->
  				<el-form-item label="商标类别">
    				<el-select v-model="schCondition.selectedIntCls" placeholder="请选择商标类别">
              <el-option :label="intClsDefault" :value="intClsDefaultValue"></el-option>
      				<el-option v-for="item in schCondition.intCls" :label="'第' + item.id + '类' + ' ' +  item.goodsname" :value="item.id"></el-option>
    				</el-select>
  				</el-form-item>
  				<el-form-item label="申请时间">
    				<el-col :span="11">
      					<el-date-picker type="date" @change="dateChg" placeholder="选择日期" v-model="schCondition.appDateStart" style="width: 100%;"></el-date-picker>
    				</el-col>
    				<el-col class="inline" :span="1">至</el-col>
					<el-col :span="11">
      					<el-date-picker type="date" placeholder="选择日期" v-model="schCondition.appDateEnd" style="width: 100%;"></el-date-picker>
    				</el-col>
  				</el-form-item>
  				<el-form-item label="注册时间">
    				<el-col :span="11">
      					<el-date-picker type="date" placeholder="选择日期" v-model="schCondition.regDateStart" style="width: 100%;"></el-date-picker>
    				</el-col>
    				<el-col class="line" :span="1">至</el-col>
					<el-col :span="11">
      					<el-date-picker type="date" placeholder="选择日期" v-model="schCondition.regDateEnd" style="width: 100%;"></el-date-picker>
    				</el-col>
  				</el-form-item>
  				<el-form-item>
    				<el-button type="primary" @click="getTrademarkListsData">确定</el-button>
  				</el-form-item>
			</el-form>
		</div>
		<div class="operate">
			<a class="delete" @click="batchRemove" :disabled="this.selecteds.length===0"><i class="el-icon-delete"></i>批量删除</a>
			<a class="add"><router-link to="/addTrademarkManage" style="text-decoration:none"><i class="el-icon-plus"></i>添加商标管理</router-link></a>
			<a class="export" @click="exportTms"><i class="el-icon-document"></i>EXCEL导出</a>
		</div>
		<div class="trademark-list">
			<el-table :data="trademarkListData" highlight-current-row v-loading="listLoading" @selection-change="selectedsChange" style="width: 100%;" >
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="intCls" label="分类号" ></el-table-column>
				<el-table-column prop="regNo" label="商标注册号" ></el-table-column>
				<el-table-column prop="tmImg"  label="商标名称/图形">
          <template scope="scope">
            <img class="lazy" :src="'http://pic.tmkoo.com/pic.php?s=1&zch='+scope.row.tmImg" width="100" height="50">
          </template>
        </el-table-column>
				<el-table-column prop="applicantCn" label="注册人"></el-table-column>
				<el-table-column prop="appDate" label="申请日期"></el-table-column>
				<el-table-column prop="regDate" label="注册日期"></el-table-column>
        <el-table-column prop="currentStatus" label="当前状态" ></el-table-column>
				<!--<el-table-column prop="" label="使用商品" min-width="150" sortable></el-table-column>	
				<el-table-column prop="" label="法律状态" min-width="150" sortable></el-table-column>-->
				<el-table-column label="操作" width="200">
					<template scope="scope">
						<el-button size="small" @click="seeDetail(scope.$index, scope.row)">查看</el-button>
						<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
    <div class="resultFooter">
      <div id="pagenation">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="20"
          layout="total, prev, pager, next, jumper"
          :total="totalCount">
        </el-pagination>
      </div>
    </div>

	</section>
</template>

<script>
	import util from '../../common/js/util'
	import NProgress from 'nprogress'
	import { getIntCls, getTrademarkLists, deleteTrademark, exportTrademarks, getTrademarkNum, addTrademark, baseUrl_kjh } from '../../api/api';
  import filters from '../../api/filters'
  import URLSearchParams from 'url-search-params'
  import qs from 'qs'
	export default {
		data(){
			return{
				searchType: '0',
        allCount:'',
        waitFeeCount:'',
        objectionRiskCount:'',
        threeRiskCount:'',
        listLoading:false,
				//查询条件
				schCondition: {
          tmName: '',
    			regNo: '',
          applicantCn:'',
    			goods:'',
          selectedIntCls:'',
    			appDateStart: '',
          appDateEnd: '',
    			regDateStart: '',
        	regDateEnd: '',
          intCls:'',//45大类
    		},
        intClsDefault:'请选择商标类别',
        intClsDefaultValue:'',
				trademarkListData: [],
				currentPage:1,
        totalPages:1,//总页数
        totalCount:null,//总条数
        selecteds: [],//列表选中列
			}
		},
		methods:{
      //查询类型
			chgSchType(searchType) {
        //console.log(searchType);
        this.currentPage = 1;
        this.getTrademarkListsData();
      },

      //根据查询条件获取商标信息
      getTrademarkListsData(){
        //日期格式转换
        var appDateStart;
        if(this.schCondition.appDateStart){
          appDateStart = filters.formatDate.format(this.schCondition.appDateStart);
        }else{
          appDateStart = '';
        };
        var appDateEnd;
        if(this.schCondition.appDateEnd){
          appDateEnd = filters.formatDate.format(this.schCondition.appDateEnd);
        }else{
          appDateEnd = '';
        };
        var regDateStart;
        if(this.schCondition.regDateStart){
          regDateStart = filters.formatDate.format(this.schCondition.regDateStart);
        }else{
          regDateStart = '';
        };
        var regDateEnd;
        if(this.schCondition.regDateEnd){
          regDateEnd = filters.formatDate.format(this.schCondition.regDateEnd);
        }else{
          regDateEnd = '';
        }

        /*let para = new URLSearchParams();
        para.append('searchType', this.searchType);
        para.append('tmName', this.schCondition.tmName);
        para.append('regNo', this.schCondition.regNo);
        para.append('applicantCn', this.schCondition.applicantCn);
        para.append('goods', this.schCondition.goods);
        para.append('intCls', this.schCondition.selectedIntCls);
        para.append('appDateStart',appDateStart);
        para.append('appDateEnd', appDateEnd);
        para.append('regDateStart', regDateStart);
        para.append('regDateEnd', regDateEnd);
        para.append('pageNo',this.currentPage);*/

        let para = { 
          'searchType': this.searchType,
          'tmName':this.schCondition.tmName,
          'regNo':this.schCondition.regNo,
          'applicantCn':this.schCondition.applicantCn,
          'goods':this.schCondition.goods,
          'intCls':this.schCondition.selectedIntCls,
          'appDateStart':appDateStart,
          'appDateEnd':appDateEnd,
          'regDateStart':appDateStart,
          'regDateEnd':regDateEnd,
          'pageNo':this.currentPage
        }

        this.listLoading = true;
        NProgress.start();
        getTrademarkLists(qs.stringify(para)).then((res) => {
          //console.log(res);
          this.trademarkListData = res.data.result;
          this.totalPages = res.data.total;//总页数
          this.totalCount = res.data.totalCount;//总条数
          this.currentPage = res.data.pageNo;//当前页
          this.listLoading = false;
          //console.log(this.trademarkListData);
          //console.log(this.totalPages);
          //console.log(this.totalCount);
          NProgress.done();
        });
      },

      handleSizeChange(val) {
        //console.log(`每页 ${val} 条`);
      },
      //分页查询
      handleCurrentChange(currentPage) {
        if (currentPage == 'prev') {
          if(this.currentPage == 1) return;
            currentPage = this.currentPage - 1;
        } else if(currentPage == 'next') {
          if(this.currentPage == this.totalPages) return;
          currentPage = this.currentPage + 1;
        } 
        //console.log(currentPage)
        this.currentPage = currentPage;
        this.getTrademarkListsData();
      },

      //查看
      seeDetail($index, row){
        //console.log(row);
        this.$router.push({ name: 'trademarkDetail', params:{intCls:row.intCls,regNo:row.regNo} });
      },

      //统计商标个数
      tmNumCount(){
        NProgress.start();
        getTrademarkNum().then((res) => {
          let { code } = res;
          //console.log(code);
          NProgress.done();
          if(code != 0){
            //alert("网络异常");
          }else{  
            //console.log(res);
            this.allCount = res.data.sumCount || 0;
            this.waitFeeCount = res.data.typeCount1 || 0;
            this.objectionRiskCount = res.data.typeCount2 || 0;
            this.threeRiskCount = res.data.typeCount3 || 0;
          }    
        }); 
      },

      //单个删除
      handleDel($index, row){
        //console.log($index + " " + JSON.stringify(row));
        this.$confirm('确认删除该记录吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true;
          NProgress.start();
          /*let para = new URLSearchParams();
          para.append('trademarkIds', JSON.stringify(row.id));*/

          let para = { 
            'trademarkIds': row.id,
          }
          deleteTrademark(qs.stringify(para)).then((res) => {
            this.listLoading = false;
            NProgress.done();
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success'
            });
            /*for(var i=0; i < this.trademarkListData.length; i++){
              if(i == $index){
                this.trademarkListData.splice(i,1);
                return;
              }
            }*/
            this.getTrademarkListsData();
            this.tmNumCount();
          });
        }).catch(() => {

        });
      },

      //选中项
      selectedsChange: function (selection) {
        this.selecteds = selection;
        //console.log(this.selecteds);
      },

      //批量删除
      batchRemove: function () {
        var ids = this.selecteds.map(item => item.id).toString();
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择删除项'
          });
          return false;
        }else{          
          this.$confirm('确认删除选中记录吗？', '提示', {
            type: 'warning'
          }).then(() => {
            this.listLoading = true;
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('trademarkIds', ids);*/

            let para = { 
              'trademarkIds': ids,
            }
            deleteTrademark(qs.stringify(para)).then((res) => {
              this.listLoading = false;
              NProgress.done();
              this.$notify({
                title: '成功',
                message: '删除成功',
                type: 'success'
              });
              this.getTrademarkListsData();
              this.tmNumCount();
            });
          }).catch(() => {
          });
        }
      },

      //EXCEL导出
      exportTms(){
        var ids = this.selecteds.map(item => item.id).toString();
        if(!ids){
          this.$notify.info({
            title: '警告',
            message: '请选择导出项'
          });
          return false;
        }else{
          this.$confirm('确定导出选中项到EXCEL吗？', '提示', {
            type: 'warning'
          }).then(() => {
            NProgress.start();
            /*let para = new URLSearchParams();
            para.append('trademarkIds', ids);*/

            let para = { 
              'trademarkIds': ids,
            }
            //location.href = `${baseUrl_kjh}/cnsebe-steward-web/StewardTradeMarkInfo/reportStewardTrademark.do?` + para;
            location.href = `${exportTrademarks}` + qs.stringify(para);
          }).catch(() => {
          });
        }
      },

      //获取45大类
      get45IntCls(){
        NProgress.start();
        getIntCls().then((res) => {
          let { code } = res;
          //console.log(code);
          NProgress.done();
          if(code != 0){
            //alert("网络异常");
          }else{  
            this.schCondition.intCls = res.list;   
            //console.log(this.schCondition.intCls);
          }    
        }); 
      },

      dateChg(){
        
      }


		},
		mounted(){
      this.tmNumCount();
      this.get45IntCls();
      this.getTrademarkListsData();
		}
	}

</script>

<style scoped lang="scss">
    .tab{
    	padding:10px;
    }
    .search-condition{
    	padding:10px;
    }
    .operate{
    	padding:10px;
    	a{
			  margin-right: 20px;
    		color: #20a0ff;
    		font-size: 14px;
        cursor: pointer;
    	}
    }
    .trademark-list{
    	padding:10px;
    }
    #pagenation{
      padding:20px 10px 50px;
      text-align: right;
    }
    .ipt{
      -webkit-appearance: none;
      -moz-appearance: none;
      appearance: none;
      background-color: #fff;
      background-image: none;
      border-radius: 4px;
      border: 1px solid #bfcbd9;
      box-sizing: border-box;
      color: #1f2d3d;
      display: block;
      font-size: inherit;
      height: 36px;
      line-height: 1;
      outline: 0;
      padding: 3px 10px;
      transition: border-color .2s cubic-bezier(.645,.045,.355,1);
      width: 100%;
    }
</style>
<style>
	.el-form--inline .el-form-item__label{
		float: left;
	}
/*   .el-tabs__nav{
  width: 377px;
}
.el-tabs__item{
  width: 25%;
} */
</style>
