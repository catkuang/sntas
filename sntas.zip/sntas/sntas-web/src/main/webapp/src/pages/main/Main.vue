<template>
	<section>
		<div class="middle-column">
			<el-carousel :interval="5000" arrow="always">
    			<el-carousel-item ><!--v-for="item in lunbo"-->
					<!--<div style="background:url(../static/img/lunbo1.d95372e.png);">1</div>-->
      				<img src="../../assets/images/lunbo/lunbo1.png"/>
    			</el-carousel-item>
  			</el-carousel>
		</div>
        <!--<div class="intelle_pro_intro">
            <h2 class="title">知产概况:</h2>
            <div class="intelle_pro_list">

            </div>
        </div>-->
    	<div class="intelle-pro-intro">
			<h2 class="title">知产概况:</h2>
            <div class="intelle-pro-list" style="position:relative;">
                <ul style="text-align:center;">
                    <router-link to="/trademarkManage" style="text-decoration:none">
                        <li style="list-style-type:none;display:inline-block;position:absolute;left:1%">
                            <div style="position:relative;width:300px;">
                                <a>
                                    <img src="../../assets/images/cysb.png"/>
                                </a>
                                <div style="position:absolute;right:35px;top:20px;color: #fff;font-weight: 600;">
                                    <a style="color:#fff">持有商标</a>
                                    <p class="num" style="font-size: 20px;margin:0px;">{{trademarkCount}}个</p>
                                </div>
                            </div>
                        </li>
                    </router-link>
                    <router-link to="/patentManage" style="text-decoration:none">
                        <li style="list-style-type:none;display:inline-block;">
                            <div style="position:relative;width:300px;">
                                <a>
                                    <img src="../../assets/images/cyzl.png"/>
                                </a>
                                <div style="position:absolute;right:35px;top:20px;color: #fff;font-weight: 600;">
                                    <a style="color:#fff;">持有专利</a>
                                    <p class="num" style="font-size: 20px;margin:0px;">{{patentCount}}个</p>
                                </div>
                            </div>
                        </li>
                    </router-link>  
                    <router-link to="/" style="text-decoration:none">
                        <li style="list-style-type:none;display:inline-block;position:absolute;right:1%;">
                            <div style="position:relative;width:300px;">
                                <a>
                                    <img src="../../assets/images/cybq.png"/>
                                </a>
                                <div style="position:absolute;right:35px;top:20px;color: #fff;font-weight: 600;">
                                    <a style="color:#fff;">持有版权</a>
                                    <p class="num" style="font-size: 20px;margin:0px;">0个</p>
                                </div>
                            </div>
                        </li>
                    </router-link>              
                </ul>
            </div>
			<!--<div class="intelle-pro-list">
				<ul>
                    <router-link to="/trademarkManage" style="text-decoration:none">
					   <li class="intelle-pro-item">
						<div class="intelle-pro-img">
							<a>
								<img src="../../assets/images/cysb.png"/>
							</a>
						</div>
						<h3 class="intelle-pros">
							<a>持有商标</a>
							<p class="desc">这是一段描述性文字</p>
							<p class="num">{{trademarkCount}}个</p>
						</h3>
					   </li>
                    </router-link>
                    <router-link to="/patentManage" style="text-decoration:none">
					   <li class="intelle-pro-item">
						<div class="intelle-pro-img">
							<a>
								<img src="../../assets/images/cyzl.png"/>
							</a>
						</div>
						<h3 class="intelle-pros">
							<a>持有专利</a>
							<p class="desc">这是一段描述性文字</p>
							<p class="num">{{patentCount}}个</p>
						</h3>
					   </li>
                    </router-link>
					<!-.-<li class="intelle-pro-item">
						<div class="intelle-pro-img">
							<a>
								<img src="../../assets/images/cybq.png"/>
							</a>
						</div>
						<h3 class="intelle-pros">
							<a>持有版权</a>
							<p class="desc">这是一段描述性文字</p>
							<p class="num">3个</p>
						</h3>
					</li>-.->
				</ul>
				<!-.-<div class="sign-up">
					<div class="sing-up-img">
						<a>
							<img src="../../assets/images/zc.png"/>
						</a>
					</div>
				</div>-.->
			</div>-->
    	</div>
    	<div class="my-service">
            <h2 class="ser-title">我的服务:</h2>  
            <div class="ser-list">
                <ul>
                    <li class="ser-item" style="width:80px;margin-right:50px;">
                        <div class="ser-img">
                            <a href="http://www.pss-system.gov.cn/sipopublicsearch/patentsearch/searchHomeIndex-searchHomeIndex.shtml"  target="_Blank">
                                <img src="../../assets/images/zljs.png"/>
                                <!--<img :src="zljs"/>-->
                            </a>
                        </div>
                        <h3 class="ser-pros" style="margin:0px;">
                            <p class="ser-desc">专利检索</p>
                        </h3>
                    </li> 
                    <router-link to="/infoManage">
                        <li class="ser-item" >
                            <div class="ser-img">
                                <a>
                                    <img src="../../assets/images/xxgl.png"/>
                                </a>
                            </div>
                            <h3 class="ser-pros">
                                <p class="ser-desc">消息管理</p>
                            </h3>
                        </li>
                    </router-link>
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/zlsq.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">专利申请</p>
                        </h3>
                    </li>
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/gxrz.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">高新认证</p>
                        </h3>
                    </li>              
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/sbjc.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">商标检测</p>
                        </h3>
                    </li>       
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/sbjy.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">商标交易</p>
                        </h3>
                    </li>       
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/wsmj.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">我是卖家</p>
                        </h3>
                    </li>       
                    <li class="ser-item">
                        <div class="ser-img">
                            <a>
                                <img src="../../assets/images/wsmj2.png"/>
                            </a>
                        </div>
                        <h3 class="ser-pros">
                            <p class="ser-desc">我是买家</p>
                        </h3>
                    </li>                          
                </ul>
            </div> 
        </div>
    	<div class="my-company" >
            <h2 class="comp-title">我的公司:</h2> 
            <table cellspacing="0" cellpadding="0" border="0" class="el-table__header table_header">
                <thead class="table_thead">
                    <tr class="table_tr">
                        <th colspan="1" rowspan="1" class="table_th" style="width:12.5%;"><div class="cell">公司名称</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">知产分类</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">分类号</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">注册号/专利号</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">申请日期</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">注册日期</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">知产名称</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">当前状态</div></th>
                        <th colspan="1" rowspan="1" class="table_th"><div class="cell">操作</div></th>
                    </tr>
                </thead>
            </table>    
            <table class="table_content">
                <tr v-for="o in organizationList" class="cont_tr">
                    <td class="cont_td">
                        <div class="cell">{{o.name}}</div>
                    </td>
                    <table cellspacing="1" cellpadding="3"  border="0" bordercolor="#dfe6ec" class="table_asset">
                        <tr class="asset_tr" v-for="a in o.assetInfos">
                            <td class="asset_td"><div class="text">{{a.assetType | IPRFormat}}</div></td>
                            <td class="asset_td"><div class="text">{{a.intCls}}</div></td>
                            <td class="asset_td"><div class="text">{{a.regNo}}</div></td>
                            <td class="asset_td"><div class="text">{{a.appDate}}</div></td>
                            <td class="asset_td"><div class="text">{{a.regDate}}</div></td>
                            <td class="asset_td"><div class="text">{{a.tmName}}</div></td>
                            <td class="asset_td"><div class="text">{{a.currentStatus}}</div></td>
                            <td class="asset_td"><el-button @click="seeDetail(a)" type="text" size="small">查看</el-button></td>
                        </tr>
                    </table>
                </tr>
            </table>
            <!--<table style="position: relative;overflow: hidden;box-sizing: border-box;width: 100%;max-width: 100%;background-color: #fff;border: 1px solid #dfe6ec;font-size: 14px;color: #1f2d3d;">
                <tr style="background-color: #eef1f6;text-align: left;border: 1px solid #dfe6ec;height:40px;line-height:40px;">
                    <td style="display:inline-block;width:180px;text-align:center;">公司名称：</td>
                    <td style="display:inline-block;width:180px;text-align:center;">知产分类</td>
                    <td style="display:inline-block;width:180px;text-align:center;">分类号</td>
                    <td style="display:inline-block;width:180px;text-align:center;">注册号/专利号</td>
                    <td style="display:inline-block;width:180px;text-align:center;">申请日期</td>
                    <td style="display:inline-block;width:180px;text-align:center;">注册日期</td>
                    <td style="display:inline-block;width:180px;text-align:center;">知产名称</td>
                    <td style="display:inline-block;width:180px;text-align:center;">当前状态</td>
                    <td style="display:inline-block;width:180px;text-align:center;">操作</td>
                </tr>
                <tr v-for="o in organizationList" style="position:relative;">
                    <td style="float:left;text-align:center;padding:5px;">{{o.name}}</td>
                    <div v-for="a in o.assetInfos" style="margin-left:8%;padding:5px; border-bottom:1px solid #ccc;border-left:1px solid #ccc">
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.assetType}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.intCls}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.regNo}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.appDate}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.regDate}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.tmName}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;">{{a.currentStatus}}</span>
                        <span style="display:inline-block;width:180px;text-align:center;"><el-button @click="seeDetail(a)" type="text" size="small">查看</el-button></span>
                    </div>
                </tr>
            </table>-->
            <!--<el-table :data="organizationList" border style="width: 100%">
                <el-table-column prop="name" label="公司名称" width="250"></el-table-column>
                <el-table-column scope="scope" label="知产分类" width="120">
                    <template scope="scope">
                        <span>{{ scope.row.assetType | IPRFormat}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="intCls" label="分类号" width="120"></el-table-column>
                <el-table-column prop="regNo" label="注册号/专利号" width="130"></el-table-column>
                <el-table-column prop="appDate" label="申请日期" width="120"></el-table-column>
                <el-table-column prop="regDate" label="注册日期" width="120"></el-table-column>
                <el-table-column prop="tmName" label="知产名称" width="200"></el-table-column>
                <el-table-column prop="currentStatus" label="当前状态" width="300"></el-table-column>
                <el-table-column prop="" label="操作" width="300">
                    <template scope="scope">
                        <el-button @click="seeDetail(scope.$index, scope.row)" type="text" size="small">查看</el-button>
                    </template>
                </el-table-column>
            </el-table>-->
        </div>
	</section>
</template>

<script>
    import Vue from 'vue'
    import NProgress from 'nprogress'
    import 'nprogress/nprogress.css'
    import { getHomePageInfo } from '../../api/api'
    import filters from '../../api/filters'
	export default {
		data(){
			return{
				lunbo:[
					"lunbo1.png",
					"lunbo2.jpg"
				],
                trademarkCount:'',
                patentCount:'',
                organizationList:[
                    {
                        organizationId:'',
                        name:'',
                        assetInfos:[
                            {
                                assetType:'',
                                intCls:'',
                                appDate:'',
                                regDate:'',
                                regNo:'',
                                tmName:'',
                                currentStatus:'',
                                applicantCn:'',
                            }
                        ],
                    }
                ],
                zljs:'../../assets/images/zljs.png',
			}
		},
		methods:{
            getHomeData(){
                NProgress.start();
                getHomePageInfo().then((res) => {
                    let { code } = res;
                    this.trademarkCount = res.data.trademarkCount;
                    this.patentCount = res.data.patentCount;
                    this.organizationList = res.data.organizationList;
                    //console.log(res);
                    //console.log(this.organizationList);

                    NProgress.done();           

                });
            },
            seeDetail(row) {
                if(row.assetType == 0){
                    this.$router.push({ name: 'trademarkDetail', params:{intCls:row.intCls,regNo:row.regNo} });
                }else if(row.assetType == 1){
                    this.$router.push({ name: 'patentDetail', params:{id:row.id} });
                }
            },
            /*seeDetail($index,row) {
                if(row.assetType == 0){
                    this.$router.push({ name: 'trademarkDetail', params:{intCls:row.intCls,regNo:row.regNo} });
                }else if(row.assetType == 1){
                    this.$router.push({ name: 'patentDetail', params:{id:row.id} });
                }
            },*/
		},
		mounted(){
            this.getHomeData();
		},
        filters: {
            IPRFormat : filters.formatIPRClassify.format
        },
	}

</script>

<style scoped lang="scss">
    .middle-column{
    	width:100%;
        .el-carousel__item h3 {
            color: #475669;
            font-size: 18px;
            opacity: 0.75;
            line-height: 300px;
            margin: 0;
            .el-carousel__item:nth-child(2n) {
                background-color: #99a9bf;
            }
            .el-carousel__item:nth-child(2n+1) {
                background-color: #d3dce6;
            }
        }
    }
    .intelle-pro-intro{
    	width:100%;
    	height:160px;
        border-bottom: 1px solid rgb(223, 230, 236);
    	.title{
            width: 200px;
    		margin: 0;
    		color: #002651;
    		font-size: 20px;
    		font-weight: 600;
    		line-height: 45px;
    		padding-left:15px;
            background-color:#f2f2f2;
            height: 45px;
    	}
    	.intelle-pro-list{
    		padding: 0px 15px;
    		.intelle-pro-item{
    			list-style-type:none;
    			height: 230px;
    			padding: 20px 0;
    			position: relative;
    			z-index: 1;
    			float: left;
    			width: 234px;
    			margin:0px 60px;
    			background: #fff;
    			-webkit-transition: all .2s linear;
    			transition: all .2s linear;
    			background-color:#ccc;
    			.intelle-pro-img{
    				width: 160px;
    				height: 160px;
    				margin: 0 auto 18px;
    				img{
    					width: 160px;
    					height: 160px;
    				}
    			}
    			.intelle-pros{
    				margin: 0 10px 2px;
    				color: #333;
    				font-size: 14px;
    				font-weight: 400;
    				text-align: center;
    				.desc{
    					margin: 0 10px 10px;
    					height: 18px;
    					font-size: 12px;
    					text-align: center;
    					text-overflow: ellipsis;
    					white-space: nowrap;
    					overflow: hidden;
    					_zoom: 1;
    					color: #b0b0b0;
    				}
    				.num{
    					margin: 0 10px 14px;
    				    text-align: center;
    					color: #ff6700;
    				}
    			}
    		}
    		.sign-up{
    			margin: 0px 60px;
    			list-style-type: none;
    			height: 230px;
    			padding: 20px 0;
    			position: relative;
    			z-index: 1;
    			float: left;
    			width: 234px;
    			background: #D3DCE6;
    			transition: all .2s linear;
    			.sing-up-img{
					width: 160px;
    				height: 160px;
    				margin: 30px auto 18px;
    				img{
    					width: 160px;
    					height: 160px;
    				}
    			}
    		}
    	}
    }

    .my-service{
        width:100%;
        height: 170px;
        border-bottom: 1px solid rgb(223, 230, 236);
        .ser-title{
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            line-height: 45px;
            height: 45px;
            color: #002651;
            padding-left:15px;
        }
        .ser-list{
            padding: 0px 15px;
            height: 125px;
            ul{
                width: 100%;
                .ser-item{
                list-style-type:none;
                height: 100px;
                position: relative;
                z-index: 1;
                float: left;
                width: 12%;
                -webkit-transition: all .2s linear;
                transition: all .2s linear;
                .ser-img{
                    width: 80px;
                    height: 80px;
                    margin: 0 auto 18px;
                    img{
                        width: 80px;
                        height: 80px;
                    }
                }
                .ser-pros{
                    margin: 0 10px 2px;
                    color: #333;
                    font-size: 14px;
                    font-weight: 400;
                    text-align: center;
                    .ser-desc{
                        margin: 0 10px 10px;
                        height: 18px;
                        font-size: 12px;
                        text-align: center;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        overflow: hidden;
                        _zoom: 1;
                    }
                }
            }
            }

        }
    }
    .my-company{
        width:100%;
        .comp-title{
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            line-height: 35px;
            color: #002651;
            padding:5px 15px;
        }
        .table_header{
            width: 98%;text-align:left;margin:0px 1%;border:1px solid rgb(223, 230, 236);
            .table_thead{
                display: table-header-group;vertical-align: middle;border-color: inherit;
                .table_tr{
                    border-color:#fff;display: table-row;vertical-align: inherit;border-color: inherit;
                    .table_th{
                        white-space: nowrap;overflow: hidden;background-color: #eef1f6;text-align: center;height: 40px;min-width: 0;box-sizing: border-box;text-overflow: ellipsis;vertical-align: middle;position: relative;font-weight: bold;display: table-cell;
                            .cell{
                                position: relative;word-wrap: normal;text-overflow: ellipsis;display: inline-block;
                                line-height: 20px;vertical-align: middle;width: 100%;box-sizing: border-box;box-sizing: border-box;overflow: hidden;text-overflow: ellipsis;white-space: normal;word-break: break-all;line-height: 24px;padding-left: 18px;padding-right: 18px;background-color: #eef1f6;color: #1f2d3d;
                            }
                    }
                }
            }
        }
        .table_content{
            position: relative;overflow: hidden;box-sizing: border-box;width: 98%;max-width: 100%;background-color: #fff;font-size: 14px;color: #1f2d3d;margin:0px 1% 10px 1%;border: 1px solid #dfe6ec;font-size: 14px; color: #1f2d3d;
            .cont_tr{
                position:relative;display: table-row;vertical-align: inherit;border-color: inherit;background-color: #fff;
                .cont_td{
                    text-align:center;width:12%;transition: background-color .25s ease;height: 40px;min-width: 0;box-sizing: border-box;text-overflow: ellipsis;vertical-align: middle;position: relative;display: table-cell;border-right: 1px solid #dfe6ec;border-bottom: 1px solid #dfe6ec;
                    .cell{
                        box-sizing: border-box;overflow: hidden;text-overflow: ellipsis;white-space: normal;word-break: break-all;
                        line-height: 24px;padding-left: 18px;padding-right: 18px;
                    }
                }
                .table_asset{
                    position: relative;overflow: hidden;box-sizing: border-box;width: 100%;max-width: 100%;background-color: #fff;font-size: 14px;color: #1f2d3d;font-size: 14px; color: #1f2d3d;border-bottom: 1px solid #dfe6ec;
                    .asset_tr{
                        position:relative;display: table-row;vertical-align: inherit;border-color: inherit;background-color: #fff;
                        .asset_td{
                            text-align:center;width:12%;transition: background-color .25s ease;height: 40px;min-width: 0;box-sizing: border-box;text-overflow: ellipsis;vertical-align: middle;position: relative;display: table-cell;
                            .text{
                                box-sizing: border-box;overflow: hidden;text-overflow: ellipsis;white-space: normal;word-break: break-all;line-height: 24px;padding-left: 18px;padding-right: 18px;
                            }
                        }
                    }
                }
            }
        }
    }
</style>
