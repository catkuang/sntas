import NotFound from './pages/404.vue'
import Home from './pages/Home.vue'
//首页
import Main from './pages/main/Main.vue'
//账户管理
import basicInfo from './pages/accountManage/basicInfo.vue'
import companyInfo from './pages/accountManage/companyInfo.vue'
import addTmCompRely from './pages/accountManage/addTmCompRely.vue'
import addPtCompRely from './pages/accountManage/addPtCompRely.vue'
import accountSecurity from './pages/accountManage/accountSecurity.vue'
import userManage from './pages/accountManage/userManage.vue'
import infoManage from './pages/accountManage/infoManage.vue'
//知产管理
import trademarkManage from './pages/intelleProManage/trademarkManage.vue'
import trademarkDetail from './pages/intelleProManage/trademarkDetail.vue'
import addTrademarkManage from './pages/intelleProManage/addTrademarkManage.vue'
import patentManage from './pages/intelleProManage/patentManage.vue'
import patentDetail from './pages/intelleProManage/patentDetail.vue'
import addPatentManage from './pages/intelleProManage/addPatentManage.vue'

let routes = [
    //重定向到首页
    { 
        path: '/', 
        redirect: '/main',
        name:'首页默认',
        hidden:true 
    },
    {
        path: '/',
        component: Home,
        name: '首页',
        hidden: true,
        children: [
            { path: '/main', component: Main, name: 'main', hidden: true },
            //{ path: '/trademarkDetail', component: trademarkDetail, name: 'trademarkDetail', hidden: true }
        ]
    },
    {
        path: '/404',
        component: NotFound,
        name: '',
        hidden: true
    },
    {
        path: '/',
        component: Home,
        name: '账户管理',
        iconCls: 'el-icon-menu',//图标样式class
        children: [
            { path: '/basicInfo', component: basicInfo, name: '基本信息'},//hidden: true 
            { path: '/companyInfo', component: companyInfo, name: '公司信息' },
            { path: '/addTmCompRely/:organization_id', component: addTmCompRely, name: 'addTmCompRely', hidden:true },
            { path: '/addPtCompRely/:organization_id', component: addPtCompRely, name: 'addPtCompRely', hidden:true },
            { path: '/accountSecurity', component: accountSecurity, name: '账号安全',hidden:true },
            { path: '/userManage', component: userManage, name: '用户管理' },
            { path: '/infoManage', component: infoManage, name: '消息管理' }
        ]
    },
    {
        path: '/',
        component: Home,
        name: '知产管理',
        iconCls: 'el-icon-menu',
        children: [
            { path: '/trademarkManage', component: trademarkManage, name: '商标管理' },
            { path: '/trademarkDetail/:intCls/:regNo', component: trademarkDetail, name: 'trademarkDetail', hidden: true },
            { path: '/addTrademarkManage', component: addTrademarkManage, name: 'addTrademarkManage', hidden: true },
            { path: '/patentManage', component: patentManage, name: '专利管理' },
            { path: '/patentDetail/:id', component: patentDetail, name: 'patentDetail', hidden: true },
            { path: '/addPatentManage', component: addPatentManage, name: 'addPatentManage', hidden: true },
        ]
    },
    {
        path: '*',
        hidden: true,
        redirect: { path: '/404' }
    }
];

//export default routes;
export {routes};