package com.sntas;

import com.sntas.common.utils.MD5;
import com.sntas.common.utils.StringUtil;
import com.sntas.mybatis.bean.member.MemberEntity;
import com.sntas.mybatis.mapper.member.MemberEntityMapper;
import com.sntas.service.member.IMemberService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Exo on 2016/7/22.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/META-INF/spring/spring-context.xml")
@ActiveProfiles("production")
public class StewardTradeMarkInfoTest {
    @Resource
    public IMemberService memberService;

    @Resource
    private MemberEntityMapper memberEntityMapper;

    @Test
    public void addMember() {
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setMemberPhone("1366666666");
        memberEntity.setMemberPasswd(MD5.getMD5Str("123456"));
        memberEntity.setCreateTime(new Date());
        memberEntity.setUpdateTime(new Date());
        memberEntity.setMemberNickname("Ada");
        int count=memberEntityMapper.insert(memberEntity);
        assert count != 0;
    }



}